package com.aymankhattab.nateq.settings

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleOwner
import com.aymankhattab.nateq.feature.settings.R
import com.aymankhattab.nateq.util.LanguageCode
import com.aymankhattab.nateq.util.announceCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.util.Calendar
import java.util.Locale
import java.text.SimpleDateFormat
import com.aymankhattab.nateq.core.audio.engine.LatinLanguageDetector
import com.aymankhattab.nateq.core.audio.providers.EnginePicker
import com.aymankhattab.nateq.core.data.SettingsRepository
import com.aymankhattab.nateq.core.engine.AudioExpansionLevels

/** بطاقة قسم في القائمة الرئيسية: رأس + سهم + حالة + محتوى
 *  (يُفتح كشاشة فرعية). [group] هو فهرس المجموعة المنطقية للبطاقة —
 *  مستقل عن وعائها الفيزيائي في التخطيط. */
internal data class AccordionEntry(
    val header: View,
    val arrow: TextView,
    val status: TextView?,
    val content: View,
    val group: Int
)

/** مفاتيح حفظ حالة التنقّل في savedInstanceState (بند 4.6). */
private const val STATE_LEVEL = "accordion_level"
private const val STATE_GROUP = "accordion_group"
private const val STATE_SECTION_ID = "accordion_section_id"

/**
 * ضابط التنقّل على ثلاثة مستويات (الرئيسية ← المجموعة ← القسم):
 * القائمة الرئيسية تعرض المفتاح الرئيسي وأزرار المجموعات الأربع المستقلة
 * (المحرك والأصوات / الإعلانات والتنبيهات / النصوص والأرقام / النظام
 * والمساعدة)، والضغط على أي زر يدخل إلى شاشة مجموعته، ومنها تُفتح بطاقات
 * الأقسام كشاشات فرعية، مع زر رجوع تدريجي ومفتاح النظام.
 */
internal class SettingsAccordionController(
    private val fragment: Fragment,
    private val settings: SettingsRepository,
    private val voices: List<NateqVoice>,
    private val engineCatalog: EngineVoicesCatalog
) {

    private val accordionEntries = mutableListOf<AccordionEntry>()

    /** الفاصل بين عناصر الملخصات: «،» عربية لواجهة عربية و«, » إنجليزية
     *  لواجهة إنجليزية — كانت الفاصلة العربية تظهر حرفياً في نصوص إنجليزية. */
    private val listSeparator: String
        get() = if (LanguageCode.isEnglish(Locale.getDefault().language)) {
            ", "
        } else {
            "، "
        }

    // ===== المجموعات الأربع (محرك/إعلانات/نصوص/نظام) =====
    // التقسيم المنطقي مستقل عن الموضع الفيزيائي في التخطيط: كل بطاقة تحمل
    // `group` خاصة بمجموعتها، وشاشة المجموعة تُظهر بطاقاتها أياً كانت الأوعية
    // الحاوية لها (تُبقى كل الأوعية ظاهرة وتُخفى البطاقات غير المنتمية).
    private class GroupState(
        val headerId: Int,
        val arrowId: Int,
        val titleRes: Int,
        val group: Int
    )

    private val groupStates = listOf(
        GroupState(
            R.id.ll_group_special_header,
            R.id.tv_group_special_arrow,
            R.string.group_engine_voices_title,
            0
        ),
        GroupState(
            R.id.ll_group_general_header,
            R.id.tv_group_general_arrow,
            R.string.group_announcements_title,
            1
        ),
        GroupState(
            R.id.ll_group_advanced_header,
            R.id.tv_group_advanced_arrow,
            R.string.group_text_title,
            2
        ),
        GroupState(
            R.id.ll_group_system_header,
            R.id.tv_group_system_arrow,
            R.string.group_system_title,
            3
        )
    )

    /** أوعية محتوى المجموعات: تُبقيها كلها ظاهرة في شاشة المجموعة لأن بطاقات
     *  المجموعة الواحدة قد تعيش في أكثر من وعاء. */
    private val groupContentIds = listOf(
        R.id.ll_group_special_content,
        R.id.ll_group_general_content,
        R.id.ll_group_advanced_content,
        R.id.ll_group_system_content
    )

    /** مستويات التنقّل: الرئيسية / شاشة مجموعة / شاشة قسم فرعي */
    private enum class Level { HOME, GROUP, SECTION }

    private var level = Level.HOME

    /** المجموعة المفتوحة حالياً (شاشة مجموعتها أو قسمٌ داخلها) */
    private var currentGroup: GroupState? = null

    // ===== التنقّل بين المستويات: الرئيسية ومجموعة وقسم =====
    private var llDetailBack: android.widget.LinearLayout? = null
    private var llMasterSwitch: android.widget.LinearLayout? = null
    private var svSettingsScroll: NestedScrollView? = null
    private var tvSectionTitle: TextView? = null
    private var tvBackToList: MaterialButton? = null
    private var switchHome: SwitchMaterial? = null

    /** تحذير لمرة واحدة في الجلسة إذا كان إذن الإشعارات مرفوضاً
 *  (الأزرار لن تظهر). */
    private var notificationsHiddenWarned = false

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            goBack()
        }
    }

    /** يربط عروض التنقّل ويسجّل بطاقات الأقسام ومستمع زر العودة
 *  وأزرار المجموعات. */
    fun setup(view: View, owner: LifecycleOwner) {
        llDetailBack = view.findViewById(R.id.ll_detail_back)
        llMasterSwitch = view.findViewById(R.id.ll_master_switch)
        svSettingsScroll = view.findViewById(R.id.sv_settings_scroll)
        tvSectionTitle = view.findViewById(R.id.tv_detail_section_title)
        tvBackToList = view.findViewById(R.id.btn_back_to_list)
        switchHome = view.findViewById(R.id.switch_all_announcements)
        view.findViewById<View>(R.id.btn_back_to_list)
            .setOnClickListener { goBack() }
        fragment.requireActivity().onBackPressedDispatcher
            .addCallback(owner, backCallback)
        setupAccordionSections(view)
        setupGroupSections(view)
        showHome()
    }

    // ===== الأكورديون: بطاقات الأقسام والتنقّل لشاشة القسم =====
    private fun accordionEntry(
        root: View,
        headerId: Int,
        arrowId: Int,
        statusId: Int,
        contentId: Int,
        base: String,
        group: Int
    ) {
        val header = root.findViewById<View>(headerId) ?: return
        val arrow = root.findViewById<TextView>(arrowId) ?: return
        val status = root.findViewById<TextView>(statusId)
        val content = root.findViewById<View>(contentId) ?: return
        header.tag = base
        accordionEntries.add(
            AccordionEntry(header, arrow, status, content, group)
        )
        // داخل شاشة المجموعة: فتح شاشة القسم عند الضغط على البطاقة
        header.setOnClickListener { openSection(content) }
        content.visibility = View.GONE
        renderSectionArrow(arrow)
        refreshCardDesc(content)
    }

    /** سهم بطاقة القسم: سهم متجهي يشير لاتجاه التقدّم (يسار في RTL) —
     *  يُلوَّن بلون النص الحالي ويثبّت كعلامة نهاية مرتكزة النسبية
     *  (متوافقة RTL تلقائياً). */
    private fun renderSectionArrow(arrow: TextView) {
        arrow.text = ""
        val icon = androidx.core.content.ContextCompat.getDrawable(
            fragment.requireContext(),
            R.drawable.ic_chevron_right
        )?.apply { setTint(arrow.currentTextColor) }
        arrow.setCompoundDrawablesRelativeWithIntrinsicBounds(
            null, null, icon, null
        )
    }

    /** وصف وصول موحّد لبطاقة القسم: الأساس + الحالة */
    private fun refreshCardDesc(content: View) {
        val e = accordionEntries.firstOrNull {
            it.content === content
        } ?: return
        val base = e.header.tag as? String ?: ""
        val statusText = e.status?.text?.toString()?.trim().orEmpty()
        e.header.contentDescription = if (statusText.isNotEmpty()) {
            base + listSeparator + statusText
        } else {
            base
        }
    }

    private fun setSectionStatus(contentId: Int, text: String) {
        val e = accordionEntries.firstOrNull {
            it.content.id == contentId
        } ?: return
        e.status?.text = text
        refreshCardDesc(e.content)
    }

    /** فتح شاشة قسم فرعي: إخفاء كل شيء عدا القسم المطلوب + شريط العودة */
    private fun openSection(content: View) {
        val entry = accordionEntries.firstOrNull {
            it.content === content
        } ?: return
        val group = groupStates.firstOrNull {
            it.group == entry.group
        } ?: groupStates.first()
        level = Level.SECTION
        backCallback.isEnabled = true
        llDetailBack?.visibility = View.VISIBLE
        llMasterSwitch?.visibility = View.GONE
        currentGroup = group
        applyGroupVisibility(false)
        setSectionDividersVisible(false)
        svSettingsScroll?.scrollTo(0, 0)
        var sectionName = ""
        for (e in accordionEntries) {
            val target = e.content === content
            if (target) sectionName = e.header.tag as? String ?: ""
            // رأس القسم المفتوح يُخفى أيضاً: tvSectionTitle يعرض اسمه
            // أعلى الشاشة
            e.header.visibility = View.GONE
            e.status?.visibility = if (target) View.VISIBLE else View.GONE
            e.arrow.visibility = View.GONE
            e.content.visibility = if (target) View.VISIBLE else View.GONE
        }
        tvSectionTitle?.text = sectionName
        // زر العودة في مستوى القسم يعود إلى شاشته المجموعة
        // (وليس القائمة الرئيسية)
        tvBackToList?.text =
            fragment.getString(R.string.back_to_group, groupTitle(group))
        // بند 4.9: نعتمد على قراءة عنوان القسم كرأس Heading عند انتقال
        // قارئ الشاشة إليه — بلا announceCompat مسبق (كان يُبث إعلاناً
        // يوليه نقلُ التركيز اللحظي فيسكُته فلا يسمعه الكفيف).
        tvSectionTitle?.let { title ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // بند 4.9: يتصفّح عنوان القسم كرأس Heading يُعلنه قارئ
                // الشاشة عند انتقال التركيز إليه.
                title.setAccessibilityHeading(true)
            }
            focusForAccessibility(title)
        }
    }

    /** بند الأوامر 5: توجيه مباشر إلى قسمٍ ما (من رابط «إرشادات المصنّع»
     *  في صف إذن المنبهات الدقيقة) — يفتح قسمه كأن المستخدم فتح بطاقته. */
    fun navigateToSection(contentId: Int) {
        val content = fragment.view?.findViewById<View>(contentId) ?: return
        if (accordionEntries.none { it.content === content }) return
        openSection(content)
    }

    /** فتح شاشة مجموعة (المحرك والإصوات/الإعلانات/النصوص/النظام): بطاقات
 *  المجموعة فقط + شريط العودة */
    private fun openGroup(group: GroupState) {
        level = Level.GROUP
        currentGroup = group
        backCallback.isEnabled = true
        llDetailBack?.visibility = View.VISIBLE
        llMasterSwitch?.visibility = View.GONE
        applyGroupVisibility(false)
        svSettingsScroll?.scrollTo(0, 0)
        for (e in accordionEntries) {
            val inGroup = e.group == group.group
            e.header.visibility = if (inGroup) View.VISIBLE else View.GONE
            e.status?.visibility = if (inGroup) View.VISIBLE else View.GONE
            e.arrow.visibility = if (inGroup) View.VISIBLE else View.GONE
            renderSectionArrow(e.arrow)
            e.content.visibility = View.GONE
        }
        val groupTitle = groupTitle(group)
        tvSectionTitle?.text = groupTitle
        // زر العودة في مستوى المجموعة يعود للقائمة الرئيسية
        tvBackToList?.text = fragment.getString(R.string.back_label)
        tvSectionTitle?.let { title ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                title.setAccessibilityHeading(true)
            }
            focusForAccessibility(title)
        }
    }

    /** إظهار/إخفاء رؤوس وأوعية المجموعات: الرئيسية تُظهر الرؤوس فقط،
 *  وشاشات المجموعة/القسم تترك الأوعية كلها ظاهرة (تُخفى البطاقات
 *  غير المنتمية عبر حلقة كل بطاقة على حدة). */
    private fun applyGroupVisibility(home: Boolean) {
        groupStates.forEach { g ->
            fragment.view?.findViewById<View>(g.headerId)?.visibility =
                if (home) View.VISIBLE else View.GONE
        }
        groupContentIds.forEach { id ->
            fragment.view?.findViewById<View>(id)?.visibility =
                if (home) View.GONE else View.VISIBLE
        }
    }

    /** رجوع تدريجي: قسم ← مجموعة ← رئيسية (أو تسليم المفتاح
     *  للنظام فوق الرئيسية) */
    private fun goBack() {
        val group = currentGroup
        when {
            level == Level.SECTION && group != null -> openGroup(group)
            level == Level.GROUP -> showHome()
            level == Level.SECTION -> showHome()
            else -> {
                // في الرئيسية: يعالج مفتاح الرجوع النظامي الخروج من الشاشة
            }
        }
    }

    /** تحذير لمرة واحدة في الجلسة إذا كان إذن الإشعارات مرفوضاً
 *  (الأزرار لن تظهر). */
    fun warnIfNotificationsHidden() {
        if (notificationsHiddenWarned) return
        if (Build.VERSION.SDK_INT < 33) return
        val granted = ContextCompat.checkSelfPermission(
            fragment.requireContext(),
            android.Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) return
        notificationsHiddenWarned = true
        Toast.makeText(
            fragment.requireContext(),
            fragment.getString(
                R.string.notification_permission_actions_hidden
            ),
            Toast.LENGTH_LONG
        ).show()
        fragment.view?.announceCompat(
            fragment.getString(R.string.notification_permission_actions_hidden)
        )
    }

    /** العودة إلى القائمة الرئيسية: المفتاح الرئيسي + أزرار
 *  المجموعات الثلاث فقط */
    fun showHome() {
        val returning = level != Level.HOME
        level = Level.HOME
        currentGroup = null
        backCallback.isEnabled = false
        llDetailBack?.visibility = View.GONE
        llMasterSwitch?.visibility = View.VISIBLE
        applyGroupVisibility(true)
        setSectionDividersVisible(true)
        svSettingsScroll?.scrollTo(0, 0)
        // بطاقات الأقسام لا تظهر إلا داخل شاشات مجموعاتها
        for (e in accordionEntries) {
            e.header.visibility = View.GONE
            e.status?.visibility = View.GONE
            e.arrow.visibility = View.GONE
            e.content.visibility = View.GONE
        }
        // عند العودة من مستوى أعمق: نعيد تركيز المفتاح الرئيسي مع إعلان مسموع
        if (returning) {
            switchHome?.announceCompat(
                fragment.getString(R.string.back_to_home)
            )
            switchHome?.let { focusForAccessibility(it) }
        }
    }

    /** نقل تركيز الوصول إلى عرض معيّن عبر واجهات عامة */
    private fun focusForAccessibility(target: View) {
        target.post {
            target.requestFocus(View.FOCUS_FORWARD)
            target.sendAccessibilityEvent(
                android.view.accessibility.AccessibilityEvent
                    .TYPE_VIEW_ACCESSIBILITY_FOCUSED
            )
        }
    }

    /** إظهار/إخفاء الفواصل بين بطاقات القائمة (تُخفى داخل شاشات الأقسام) */
    private fun setSectionDividersVisible(visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.GONE
        val root = fragment.view ?: return
        forEachView(root) {
            if (it.tag == "section_divider") it.visibility = v
        }
    }

    /** تجوال الشجرة كاملة وتنفيذ إجراء على كل عرض (بديل findViewsWithTag) */
    private fun forEachView(current: View, action: (View) -> Unit) {
        action(current)
        if (current is android.view.ViewGroup) {
            for (i in 0 until current.childCount) {
                current.getChildAt(i).let { forEachView(it, action) }
            }
        }
    }

    /** تسجيل أقسام المجموعات الأربع كبطاقات تُفتح كلٌّ منها شاشةً فرعية.
     *  رقم المجموعة المنطقية لكل بطاقة مستقل عن وعائها الفيزيائي. */
    private fun setupAccordionSections(view: View) {
        accordionEntries.clear()
        val engine = fragment.getString(R.string.section_voice_selection)
        val dict = fragment.getString(R.string.section_pronunciation_dict)
        val tools = fragment.getString(R.string.tools_section)
        val help = fragment.getString(R.string.help_section)
        val emoji = fragment.getString(R.string.section_emoji_reading)
        val cats = fragment.getString(R.string.voice_category_default)
        val time = fragment.getString(R.string.section_time_announcement)
        val num = fragment.getString(R.string.section_number_reading)
        val battery = fragment.getString(R.string.section_battery_announcement)
        val notif = fragment.getString(R.string.section_notification_reading)
        val caller = fragment.getString(R.string.section_caller_announcement)
        val sms = fragment.getString(R.string.section_sms_reading)
        val general = fragment.getString(R.string.section_general_settings)
        val deviceHealth = fragment.getString(R.string.section_device_health)
        val textReading = fragment.getString(R.string.section_text_reading)
        val instantSilence =
            fragment.getString(R.string.section_instant_silence)
        val oem = fragment.getString(R.string.section_oem_guidance)

        // مجموعة «المحرك والأصوات»: صناديق اختيار المحرك/التحويل التلقائي
        // (إعدادات عامة) / فئات الأصوات
        accordionEntry(
            view, R.id.ll_engine_header, R.id.tv_engine_arrow,
            R.id.tv_engine_status, R.id.ll_engine_content,
            engine, 0
        )
        accordionEntry(
            view,
            R.id.ll_general_settings_header,
            R.id.tv_general_settings_arrow,
            R.id.tv_general_settings_status,
            R.id.ll_general_settings_content,
            general, 0
        )
        accordionEntry(
            view, R.id.ll_categories_header, R.id.tv_categories_arrow,
            R.id.tv_categories_status, R.id.ll_categories_content,
            cats, 0
        )

        // مجموعة «الإعلانات والتنبيهات»: الوقت / البطارية / نطق المتصل /
        // الرسائل / الإشعارات
        accordionEntry(
            view,
            R.id.ll_time_announcement_header,
            R.id.tv_time_announcement_arrow,
            R.id.tv_time_announcement_status,
            R.id.ll_time_announcement_settings,
            time, 1
        )
        accordionEntry(
            view,
            R.id.ll_battery_announcement_header,
            R.id.tv_battery_announcement_arrow,
            R.id.tv_battery_announcement_status,
            R.id.ll_battery_announcement_settings,
            battery, 1
        )
        accordionEntry(
            view,
            R.id.ll_caller_announcement_header,
            R.id.tv_caller_announcement_arrow,
            R.id.tv_caller_announcement_status,
            R.id.ll_caller_announcement_settings,
            caller, 1
        )
        accordionEntry(
            view, R.id.ll_sms_reading_header, R.id.tv_sms_reading_arrow,
            R.id.tv_sms_reading_status, R.id.ll_sms_reading_settings,
            sms, 1
        )
        accordionEntry(
            view,
            R.id.ll_notification_reading_header,
            R.id.tv_notification_reading_arrow,
            R.id.tv_notification_reading_status,
            R.id.ll_notification_reading_settings,
            notif, 1
        )
        accordionEntry(
            view,
            R.id.ll_instant_silence_header,
            R.id.tv_instant_silence_arrow,
            R.id.tv_instant_silence_status,
            R.id.ll_instant_silence_settings,
            instantSilence, 1
        )

        // مجموعة «النصوص والأرقام»: قراءة الأرقام / القاموس / نطق الإيموجي /
        // صحة الجهاز
        accordionEntry(
            view, R.id.ll_number_reading_header, R.id.tv_number_reading_arrow,
            R.id.tv_number_reading_status, R.id.ll_numbers_content,
            num, 2
        )
        accordionEntry(
            view, R.id.ll_text_reading_header, R.id.tv_text_reading_arrow,
            R.id.tv_text_reading_status, R.id.ll_text_reading_settings,
            textReading, 2
        )
        accordionEntry(
            view, R.id.ll_dict_header, R.id.tv_dict_arrow,
            0, R.id.ll_dict_content,
            dict, 2
        )
        accordionEntry(
            view, R.id.ll_emoji_header, R.id.tv_emoji_arrow,
            R.id.tv_emoji_status, R.id.ll_emoji_content,
            emoji, 2
        )
        accordionEntry(
            view, R.id.ll_device_health_header, R.id.tv_device_health_arrow,
            R.id.tv_device_health_status, R.id.ll_device_health_content,
            deviceHealth, 2
        )

        // مجموعة «النظام والمساعدة»: أدوات التطبيق / مساعدة
        accordionEntry(
            view, R.id.ll_tools_header, R.id.tv_tools_arrow,
            0, R.id.ll_tools_content,
            tools, 3
        )
        accordionEntry(
            view, R.id.ll_help_header, R.id.tv_help_arrow,
            0, R.id.ll_help_content,
            help, 3
        )
        accordionEntry(
            view,
            R.id.ll_oem_guidance_header,
            R.id.tv_oem_guidance_arrow,
            0, R.id.ll_oem_guidance_content,
            oem, 3
        )
    }

    /** تحديث أسطر الحالة لكل قسم (يُستدعى عند التهيئة وبعد كل تغيير أساسي) */
    fun updateSectionStatuses() {
        setSectionStatus(R.id.ll_engine_content, buildEngineStatus())
        setSectionStatus(R.id.ll_categories_content, buildCategoriesStatus())
        setSectionStatus(R.id.ll_time_announcement_settings, buildTimeStatus())
        setSectionStatus(R.id.ll_numbers_content, buildNumberStatus())
        setSectionStatus(
            R.id.ll_text_reading_settings,
            buildTextReadingStatus()
        )
        setSectionStatus(
            R.id.ll_instant_silence_settings,
            buildInstantSilenceStatus()
        )
        setSectionStatus(
            R.id.ll_battery_announcement_settings,
            buildBatteryStatus()
        )
        setSectionStatus(
            R.id.ll_notification_reading_settings,
            buildNotificationStatus()
        )
        setSectionStatus(
            R.id.ll_caller_announcement_settings,
            buildCallerStatus()
        )
        setSectionStatus(R.id.ll_sms_reading_settings, buildSmsStatus())
        setSectionStatus(
            R.id.ll_general_settings_content,
            buildGeneralStatus()
        )
        setSectionStatus(
            R.id.ll_device_health_content,
            buildDeviceHealthStatus()
        )
        setSectionStatus(R.id.ll_emoji_content, buildEmojiStatus())
    }

    private fun buildEngineStatus(): String {
        val auto = runCatching { settings.isAutoConvertEnabled() }
            .getOrDefault(false)
        if (!auto) {
            return fragment.getString(R.string.auto_convert_enabled) + ": " +
                fragment.getString(R.string.toggle_off)
        }
        val ctx = fragment.context ?: return fragment.getString(
            R.string.auto_convert_enabled
        ) + ": " + fragment.getString(R.string.toggle_on)
        val installed = EnginePicker.installedEnginePackages(ctx)
        val arEngine = runCatching {
            settings.getEngineForLanguage(LanguageCode.AR.tag)
        }.getOrNull()
        val enEngine = runCatching {
            settings.getEngineForLanguage(LanguageCode.EN.tag)
        }.getOrNull()
        val arStatus = EngineStatusResolver.resolveStatus(arEngine, installed)
        val enStatus = EngineStatusResolver.resolveStatus(enEngine, installed)
        val detail = when {
            arStatus == EngineStatus.DISABLED_OR_MISSING ||
                enStatus == EngineStatus.DISABLED_OR_MISSING ->
                fragment.getString(R.string.engine_disabled_or_missing)
            arStatus == EngineStatus.NOT_SELECTED ||
                enStatus == EngineStatus.NOT_SELECTED ->
                fragment.getString(R.string.engine_not_selected_short)
            else -> fragment.getString(R.string.toggle_on)
        }
        val prefix = fragment.getString(R.string.auto_convert_enabled)
        return "$prefix: $detail"
    }

    /** حالة قسم الفئات: اسم الصوت الفعلي المحفوظ لفئة الساعة الأولى — صوتُ
     *  لورد من قائمة الأصوات، أو صوتُ محركٍ مكتشفٍ بتسميته الكاملة
     *  (المحرك: الصوت)، أو السقوط الواضح عند غياب الحفظ. */
    private fun buildCategoriesStatus(): String {
        val saved = runCatching {
            settings.getPreferredVoiceIdForCategory(
                SettingsRepository.VOICE_CATEGORY_TIME
            )
        }.getOrNull().orEmpty()
        val label = when {
            voices.any { it.name == saved } ->
                voices.first { it.name == saved }.displayName
            saved.isEmpty() -> voices.firstOrNull()?.displayName
                ?: fragment.getString(R.string.no_voices_available)
            else -> engineVoiceLabel(saved)
        }
        return fragment.getString(R.string.voice_category_default) +
            ": " + label
    }

    /** تسمية صوتٍ محفوظٍ من محركٍ مكتشف (المحرك: الصوت) عبر لغته في
     *  الكتالوج، أو الاسم الفعلي الخام كسقوط أخير لما يستعصي بعد (اكتشافٌ
     *  خلفي لم يكتمل لحظة البناء) — فلا يُعرض اسمٌ عربيٌ منحولٌ أبداً. */
    private fun engineVoiceLabel(saved: String): String {
        val language = engineCatalog.languageOfVoice(saved) ?: return saved
        return engineCatalog.voicesFor(language, null)
            .firstOrNull { it.name == saved }
            ?.label
            ?: saved
    }

    private fun buildTimeStatus(): String {
        val enabled = runCatching { settings.isTimeAnnouncementEnabled() }
            .getOrDefault(true)
        val interval = runCatching { settings.getTimeAnnouncementInterval() }
            .getOrDefault(30)
        val intervalLabel = fragment.getString(
            R.string.time_interval_format,
            interval.coerceIn(5, 60)
        )
        // **بند 6.1:** اليومُ الحالي الفعلي — كان الثابت Calendar.DAY_OF_WEEK
        // (7 = السبت) يُمرَّر بدل اليوم الجاري، فكان الملخص يعرض ساعات هدوء
        // يوم السبت طوال أيام الأسبوع.
        val todayDayOfWeek = Calendar.getInstance()
            .get(Calendar.DAY_OF_WEEK)
        val quietEnabled = runCatching {
            settings.isDayQuietEnabled(todayDayOfWeek)
        }.getOrDefault(true)
        val quietStart =
            runCatching {
                settings.getQuietStartForDay(todayDayOfWeek)
            }.getOrDefault(23)
        val quietEnd =
            runCatching {
                settings.getQuietEndForDay(todayDayOfWeek)
            }.getOrDefault(7)
        return buildString {
            val on = if (enabled) fragment.getString(R.string.toggle_on)
            else fragment.getString(R.string.toggle_off)
            append(on)
            append(listSeparator).append(intervalLabel)
            if (quietEnabled) {
                append(listSeparator)
                append(
                    fragment.getString(R.string.time_quiet_schedule_title)
                )
                append(": ").append(formatQuietHour(quietStart))
                    .append("/").append(formatQuietHour(quietEnd))
            } else {
                append(listSeparator)
                append(
                    fragment.getString(R.string.time_quiet_schedule_title)
                )
                append(": ")
                append(fragment.getString(R.string.toggle_off))
            }
        }
    }

    /** ساعة الهدوء بصيغة عرضٍ احتراماً لإعداد النظام 12/24 — كانت تُعرض
     *  دائماً على 24 دون مبالاة بتفضيل المستخدم. */
    private fun formatQuietHour(hour: Int): String {
        return if (DateFormat.is24HourFormat(fragment.requireContext())) {
            hour.toString()
        } else {
            SimpleDateFormat("h a", Locale.getDefault()).format(
                java.util.Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                    set(Calendar.MINUTE, 0)
                }.time
            )
        }
    }

    private fun buildNumberStatus(): String {
        val mode = runCatching { settings.getNumberReadingMode() }
            .getOrDefault(1).coerceIn(1, 8)
        val label = fragment.getString(
            when (mode) {
                1 -> R.string.number_mode_single
                2 -> R.string.number_mode_pairs
                3 -> R.string.number_mode_triples
                4 -> R.string.number_mode_quadruples
                5 -> R.string.number_mode_quintuples
                6 -> R.string.number_mode_sextuples
                7 -> R.string.number_mode_septuples
                else -> R.string.number_mode_octuples
            }
        )
        return fragment.getString(R.string.number_reading_mode) + ": " + label
    }

    private fun buildTextReadingStatus(): String {
        val level = runCatching { settings.getPunctuationLevel() }
            .getOrDefault(1).coerceIn(0, 2)
        val label = fragment.getString(
            when (level) {
                0 -> R.string.punctuation_level_none
                1 -> R.string.punctuation_level_some
                else -> R.string.punctuation_level_all
            }
        )
        return buildString {
            append(fragment.getString(R.string.punctuation_reading_level))
                .append(": ").append(label)
            append(listSeparator)
                .append(fragment.getString(R.string.secondary_language_title))
            append(": ").append(secondaryLanguageLabel())
        }
    }

    /** لغة النطق الاحتياطية الحالية بملصقها المقروء (بند اللغة الثانية) —
     *  سقوطٌ على الاسم الإنجليزي عند قيمةٍ غير مدعومة من حدثٍ قديم. */
    private fun secondaryLanguageLabel(): String {
        val stored = runCatching { settings.getSecondaryLanguage() }
            .getOrDefault(LanguageCode.EN.tag)
        val language = LatinLanguageDetector.SUPPORTED_LANGUAGES
            .firstOrNull { it == stored } ?: LanguageCode.EN.tag
        return languageDisplayName(language)
    }

    /** الاسم المقروء للغة من الموارد — سقوطٌ على الوسام إن لم يُعرَف. */
    private fun languageDisplayName(language: String): String =
        when (language) {
            "en" -> fragment.getString(R.string.language_english)
            "fr" -> fragment.getString(R.string.language_french)
            "de" -> fragment.getString(R.string.language_german)
            "es" -> fragment.getString(R.string.language_spanish)
            else -> language
        }

    private fun buildInstantSilenceStatus(): String {
        val shake = runCatching { settings.isShakeToStopEnabled() }
            .getOrDefault(false)
        val proximity = runCatching {
            settings.isProximitySilenceEnabled()
        }.getOrDefault(false)
        val shakeLabel = if (shake) {
            fragment.getString(R.string.toggle_on)
        } else {
            fragment.getString(R.string.toggle_off)
        }
        val proximityLabel = if (proximity) {
            fragment.getString(R.string.toggle_on)
        } else {
            fragment.getString(R.string.toggle_off)
        }
        return buildString {
            append(fragment.getString(R.string.shake_to_stop_enabled))
                .append(": ").append(shakeLabel)
            append(listSeparator)
                .append(fragment.getString(R.string.proximity_silence_enabled))
            append(": ").append(proximityLabel)
        }
    }

    private fun buildBatteryStatus(): String {
        val enabled = runCatching { settings.isBatteryAnnouncementEnabled() }
            .getOrDefault(false)
        val levels = runCatching { settings.getBatteryAnnouncementLevels() }
            .getOrDefault(emptySet())
        val on = if (enabled) fragment.getString(R.string.toggle_on)
        else fragment.getString(R.string.toggle_off)
        val summary = levels.sortedDescending()
            .joinToString(listSeparator) { "$it%" }
        return buildString {
            append(on)
            if (summary.isNotEmpty()) append(listSeparator).append(summary)
        }
    }

    private fun buildNotificationStatus(): String {
        val enabled = runCatching { settings.isNotificationReadingEnabled() }
            .getOrDefault(false)
        val sel = runCatching { settings.getNotificationAppsSelection() }
            .getOrDefault(SettingsRepository.DEFAULT_NOTIFICATION_APPS)
        val on = if (enabled) fragment.getString(R.string.toggle_on)
        else fragment.getString(R.string.toggle_off)
        val apps = if (SettingsRepository.NOTIF_READ_ALL in sel) {
            fragment.getString(R.string.notification_apps_all)
        } else {
            sel.size.toString()
        }
        return buildString {
            append(on)
            append(listSeparator)
                .append(fragment.getString(R.string.notification_apps_title))
            append(": ").append(apps)
        }
    }

    private fun buildCallerStatus(): String {
        val enabled = runCatching { settings.isCallerAnnouncementEnabled() }
            .getOrDefault(false)
        val repeat = runCatching { settings.getCallerAnnouncementRepeat() }
            .getOrDefault(1)
            .coerceIn(
                SettingsRepository.CALLER_REPEAT_MIN,
                SettingsRepository.CALLER_REPEAT_MAX
            )
        val interval =
            runCatching {
                settings.getCallerAnnouncementIntervalSeconds()
            }.getOrDefault(3).coerceIn(1, 10)
        val on = if (enabled) fragment.getString(R.string.toggle_on)
        else fragment.getString(R.string.toggle_off)
        val label = fragment.resources.getQuantityString(
            R.plurals.caller_announcement_repeat_times, repeat, repeat
        )
        val intervalLabel = fragment.resources.getQuantityString(
            R.plurals.caller_announcement_interval_seconds, interval, interval
        )
        return listOf(on, label, intervalLabel).joinToString(listSeparator)
    }

    private fun buildEmojiStatus(): String {
        val enabled = runCatching { settings.isEmojiPronunciationEnabled() }
            .getOrDefault(true)
        val on = if (enabled) fragment.getString(R.string.toggle_on)
        else fragment.getString(R.string.toggle_off)
        return fragment.getString(R.string.emoji_reading_enabled) + ": " + on
    }

    private fun buildSmsStatus(): String {
        val mode =
            runCatching { settings.getSmsReadingMode() }
                .getOrDefault("off")
        val label = fragment.getString(
            when (mode) {
                "full" -> R.string.sms_mode_full
                "source" -> R.string.sms_mode_source
                else -> R.string.sms_mode_off
            }
        )
        return fragment.getString(R.string.sms_reading_mode) + ": " + label
    }

    private fun buildGeneralStatus(): String {
        val rate =
            runCatching { settings.getDefaultSpeechRate() }
                .getOrDefault(1.0f)
        val volume =
            runCatching { settings.getDefaultVolume() }
                .getOrDefault(1.0f)
        val followReader =
            runCatching { settings.isFollowReaderRateEnabled() }
                .getOrDefault(true)
        val rateText = RateLabel.of(fragment.requireContext(), rate)
        val volumeText = (volume * 100).toInt().toString() + "%"
        val followText = fragment.getString(
            if (followReader) R.string.toggle_on else R.string.toggle_off
        )
        val expansion = runCatching { settings.getAudioExpansionLevel() }
            .getOrDefault(AudioExpansionLevels.DEFAULT)
        val expansionText = fragment.getString(
            when (expansion) {
                AudioExpansionLevels.LIGHT -> R.string.audio_expansion_light
                AudioExpansionLevels.MEDIUM -> R.string.audio_expansion_medium
                else -> R.string.audio_expansion_off
            }
        )
        return buildString {
            append(fragment.getString(R.string.default_speech_rate_label))
                .append(": ").append(rateText)
            append(listSeparator).append(volumeText)
            append(listSeparator)
                .append(
                    fragment.getString(R.string.follow_reader_rate_enabled)
                )
                .append(": ").append(followText)
            append(listSeparator)
                .append(fragment.getString(R.string.audio_expansion_label))
                .append(": ").append(expansionText)
        }
    }

    private fun buildDeviceHealthStatus(): String {
        val items = runCatching { settings.getDeviceHealthItems() }
            .getOrDefault(SettingsRepository.DEFAULT_DEVICE_HEALTH_ITEMS)
        val labels = mutableListOf<String>()
        if (SettingsRepository.DEVICE_HEALTH_BATTERY in items) {
            labels.add(
                fragment.getString(R.string.device_health_battery_label)
            )
        }
        if (SettingsRepository.DEVICE_HEALTH_CHARGING in items) {
            labels.add(
                fragment.getString(R.string.device_health_charging_label)
            )
        }
        if (SettingsRepository.DEVICE_HEALTH_STORAGE in items) {
            labels.add(
                fragment.getString(R.string.device_health_storage_label)
            )
        }
        if (SettingsRepository.DEVICE_HEALTH_MEMORY in items) {
            labels.add(fragment.getString(R.string.device_health_memory_label))
        }
        return if (labels.isEmpty()) fragment.getString(R.string.toggle_off)
        else labels.joinToString(listSeparator)
    }

    /** تسجيل أزرار المجموعات الأربع كأزرار مستقلة: ضغطة تفتح شاشة المجموعة */
    private fun setupGroupSections(view: View) {
        groupStates.forEach { g ->
            val header = view.findViewById<View>(g.headerId) ?: return@forEach
            val arrow = view.findViewById<TextView>(g.arrowId)
            header.contentDescription = groupTitle(g)
            arrow?.let { renderSectionArrow(it) }
            header.setOnClickListener { openGroup(g) }
        }
    }

    /** عنوان المجموعة المقروء (المحرك والإصوات/الإعلانات/النصوص/النظام) */
    private fun groupTitle(group: GroupState): String =
        fragment.getString(group.titleRes)

    /** بند 4.6: حفظ حالة التنقّل (المستوى والمجموعة والقسم المفتوح) لاستعادتها
     *  بعد تدوير الشاشة — يُستدعى من onSaveInstanceState في الفصيل. */
    fun saveState(): Bundle {
        val bundle = Bundle()
        bundle.putInt(STATE_LEVEL, level.ordinal)
        currentGroup?.let { bundle.putInt(STATE_GROUP, it.group) }
        if (level == Level.SECTION) {
            val openId = accordionEntries.firstOrNull {
                it.content.visibility == View.VISIBLE
            }?.content?.id ?: View.NO_ID
            if (openId != View.NO_ID) {
                bundle.putInt(STATE_SECTION_ID, openId)
            }
        }
        return bundle
    }

    /** بند 4.6: استعادة التنقّل المحفوظ بعد إنشاء الأقسام.
     *  يجب استدعاؤها فوراً بعد [setup]. */
    fun restoreState(savedInstanceState: Bundle) {
        val groupInt = runCatching {
            savedInstanceState.getInt(STATE_GROUP)
        }.getOrDefault(-1)
        val savedGroup = groupStates.firstOrNull {
            it.group == groupInt
        }
        val levelOrdinal = runCatching {
            savedInstanceState.getInt(STATE_LEVEL)
        }.getOrDefault(Level.HOME.ordinal)
        val restoredLevel = try {
            Level.entries[levelOrdinal]
        } catch (_: Exception) {
            Level.HOME
        }
        when (restoredLevel) {
            Level.HOME -> {}
            Level.GROUP -> if (savedGroup != null) {
                openGroup(savedGroup)
            }
            Level.SECTION -> {
                val sectionId = runCatching {
                    savedInstanceState.getInt(STATE_SECTION_ID, View.NO_ID)
                }.getOrDefault(View.NO_ID)
                val entry = if (savedGroup != null && sectionId != View.NO_ID) {
                    accordionEntries.firstOrNull {
                        it.group == savedGroup.group &&
                            it.content.id == sectionId
                    }
                } else null
                if (entry != null) {
                    openSection(entry.content)
                } else if (savedGroup != null) {
                    openGroup(savedGroup)
                }
            }
        }
    }

    /** يصفّر كل مراجع العرض (بند 4.1) — يُستدعى من onDestroyView حتى لا
     *  تبقى شجرة العرض القديمة محتجزة عند بقاء الفصيل في الخلفية. */
    fun cleanup() {
        llDetailBack = null
        llMasterSwitch = null
        svSettingsScroll = null
        tvSectionTitle = null
        tvBackToList = null
        switchHome = null
        accordionEntries.clear()
        level = Level.HOME
        currentGroup = null
    }
}
