package com.aymankhattab.nateq.settings

import android.content.pm.PackageManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.SeekBar
import com.aymankhattab.nateq.util.setSeekStateDescription
import android.widget.Spinner
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.aymankhattab.nateq.feature.settings.R
import com.aymankhattab.nateq.core.audio.announcement.AnnouncementSchedulerService
import com.aymankhattab.nateq.core.audio.announcement.NateqNotificationListener
import com.aymankhattab.nateq.util.announceCompat
import com.aymankhattab.nateq.core.data.SettingsRepository

/** ضابط قسم «قراءة الرسائل الواردة»: وضع القراءة بالأذونات، الأصوات،
 *  السرعة والقالب. */
internal class SmsReadingController(
    private val fragment: VoiceSelectionFragment,
    private val settings: SettingsRepository,
    private val catalog: EngineVoicesCatalog,
    private val onStatusChanged: () -> Unit
) {

    // مراجع العرض قابلة للتصفير في cleanup() عند تدمير عرض الفصيل
    // (بند 4.1) حتى لا تبقى شجرة العرض القديمة محتجزة في الخلفية.
    private var spinnerSmsMode: Spinner? = null
    private var spinnerSmsLanguage: Spinner? = null
    private var spinnerSmsVoice: Spinner? = null
    private var seekSmsRate: SeekBar? = null
    private var tvSmsRateValue: TextView? = null
    private var seekSmsVolume: SeekBar? = null
    private var tvSmsVolumeValue: TextView? = null
    private var seekSmsPitch: SeekBar? = null
    private var tvSmsPitchValue: TextView? = null
    private var etSmsTemplate:
        com.google.android.material.textfield.TextInputEditText? = null
    private var templateWatcher: android.text.TextWatcher? = null

    /** الوضع المختار (full/source) لا يُحفظ إلا بعد المنح الفعلي حتى لا يبقى
     *  مفعّلاً زوراً عند رفض المستخدم الإذن (بند [9]). */
    private var pendingSmsMode: String? = null

    // **بند 6.3:** علمُ الربط البرمجي لشرائط السرعة/الصوت — إسنادُ
    // setProgress في setup ليس تعديلَ مستخدم، والحفظ في onProgressChanged
    // ضروري لأن تعديل TalkBack لا يمر بـ onStopTrackingTouch إطلاقاً.
    private var bindingSlider = false

    // لغة الصوت الحالية وخيارات سبنر الرسائل.
    private var smsLanguage: String = "ar"
    private var smsVoiceOptions: List<VoiceOption> = emptyList()
    private var bindingVoices = false

    fun setup(view: View) {
        spinnerSmsMode = view.findViewById(R.id.spinner_sms_reading_mode)
        spinnerSmsLanguage =
            view.findViewById(R.id.spinner_sms_reading_language)
        spinnerSmsVoice = view.findViewById(R.id.spinner_sms_reading_voice)
        seekSmsRate = view.findViewById(R.id.seek_sms_reading_rate)
        tvSmsRateValue = view.findViewById(R.id.tv_sms_reading_rate_value)
        seekSmsVolume = view.findViewById(R.id.seek_sms_reading_volume)
        tvSmsVolumeValue = view.findViewById(R.id.tv_sms_reading_volume_value)
        seekSmsPitch = view.findViewById(R.id.seek_sms_reading_pitch)
        tvSmsPitchValue = view.findViewById(R.id.tv_sms_reading_pitch_value)
        etSmsTemplate = view.findViewById(R.id.et_sms_template)

        // وضع القراءة: مفعّل / قراءة مصدر الرسالة فقط / معطّل
        val modes = listOf(
            fragment.getString(R.string.sms_mode_full),
            fragment.getString(R.string.sms_mode_source),
            fragment.getString(R.string.sms_mode_off)
        )
        spinnerSmsMode?.adapter = fragment.simpleAdapter(modes)
        val savedMode =
            runCatching { settings.getSmsReadingMode() }
                .getOrDefault("off")
        val modeIndex = when (savedMode) {
            "full" -> 0
            "source" -> 1
            else -> 2 // "off"
        }
        spinnerSmsMode?.setSelection(modeIndex)
        spinnerSmsMode?.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val mode = when (position) {
                    0 -> "full"
                    1 -> "source"
                    else -> "off"
                }
                if (mode == "off") {
                    // "off": يُحفظ فوراً (لا يتطلب إذناً) ويرفع أي وضع معلّق.
                    pendingSmsMode = null
                    runCatching { settings.setSmsReadingMode("off") }
                    AnnouncementSchedulerService.syncIfRunning(
                        fragment.requireContext()
                    )
                    onStatusChanged()
                    return
                }
                // وضع غير "off" (full/source):
                // يتطلب إحدى قناتي الاستقبال لكي يعمل فعلاً:
                // 1) إذن RECEIVE_SMS (المستقبل المباشر للبث SMS_RECEIVED)، أو
                // 2) خدمة الاستماع للإشعارات (NLS) كبديل بلا إذن قيود.
                if (ContextCompat.checkSelfPermission(
                        fragment.requireContext(),
                        android.Manifest.permission.RECEIVE_SMS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // RECEIVE_SMS غير ممنوح: إن كانت NLS مفعّلة (من قسم قراءة
                    // الإشعارات) نعتمد عليها مباشرة دون طلب الإذن المقيد.
                    if (NateqNotificationListener.isPermissionGranted(
                        fragment.requireContext()
                    ) &&
                        settings.isNotificationReadingEnabled()
                    ) {
                        pendingSmsMode = null
                        runCatching { settings.setSmsReadingMode(mode) }
                        AnnouncementSchedulerService.requestStart(
                            fragment.requireContext()
                        )
                        fragment.view?.announceCompat(
                            fragment.getString(R.string.sms_reading_via_nls)
                        )
                    } else {
                        pendingSmsMode = mode
                        runCatching {
                            fragment.smsPermLauncher.launch(
                                android.Manifest.permission.RECEIVE_SMS
                            )
                        }
                    }
                } else {
                    // الإذن ممنوح من قبل: نحفظ مباشرة.
                    pendingSmsMode = null
                    runCatching { settings.setSmsReadingMode(mode) }
                    AnnouncementSchedulerService.requestStart(
                        fragment.requireContext()
                    )
                }
                // تنبيه سياسة أندرويد 17: رسائل OTP تُحجب 3 ساعات أولى بعد
                // التفعيل.
                fragment.view?.announceCompat(
                    fragment.getString(R.string.sms_otp_block_hint)
                )
                onStatusChanged()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // لغة الصوت المقروءة: خياراتها من الكتالوج (عربية/إنجليزية
        // ثم المكتشفة)، وتبديلها يُجدد أصوات محرك الرسائل.
        val smsLanguages = catalog.languages()
        spinnerSmsLanguage?.adapter = fragment.simpleAdapter(
            smsLanguages.map { catalog.languageDisplayName(it) }
        )
        smsLanguage = runCatching { settings.getSmsReadingLanguage() }
            .getOrNull() ?: "ar"
        bindingVoices = true
        try {
            val langIdx = smsLanguages.indexOf(smsLanguage)
            spinnerSmsLanguage?.setSelection(
                if (langIdx >= 0) langIdx else 0
            )
        } finally {
            bindingVoices = false
        }
        spinnerSmsLanguage?.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (bindingVoices) return
                val lang = smsLanguages.getOrNull(position) ?: return
                if (lang == smsLanguage) return
                smsLanguage = lang
                runCatching { settings.setSmsReadingLanguage(lang) }
                refreshSmsVoices()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spinnerSmsVoice?.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (bindingVoices) return
                val name = smsVoiceOptions.getOrNull(position)?.name
                    ?: return
                runCatching { settings.setSmsReadingVoiceId(name) }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        refreshSmsVoices()

        // سرعة النطق
        val smsRate =
            runCatching { settings.getSmsReadingRate() }
                .getOrDefault(1.0f)
                .coerceAtLeast(MIN_SPEED_PITCH_FACTOR)
        tvSmsRateValue?.text = RateLabel.of(
            fragment.requireContext(), smsRate
        )
        bindingSlider = true
        try {
            seekSmsRate?.progress =
                (smsRate * 100).toInt().coerceIn(0, 200)
        } finally {
            bindingSlider = false
        }
        seekSmsRate?.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar,
                progress: Int,
                fromUser: Boolean
            ) {
                // الربط البرمجي ليس تعديلَ مستخدم — يُهمل بلا حفظ.
                if (bindingSlider) return
                val value = progress.speedFactor()
                tvSmsRateValue?.text = RateLabel.of(
                    fragment.requireContext(),
                    value
                )
                seekBar.setSeekStateDescription(tvSmsRateValue?.text ?: "")
                // **بند 6.3:** الحفظ عند كل تغيير — تعديل TalkBack لا تصل
                // نهايته إلى onStopTrackingTouch أبداً.
                runCatching { settings.setSmsReadingRate(value) }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                seekBar.snapSpeedMin()
                val value = seekBar.progress.speedFactor()
                runCatching { settings.setSmsReadingRate(value) }
                seekBar.announceCompat(
                    RateLabel.of(fragment.requireContext(), value)
                )
            }
        })

        // مستوى الصوت
        val smsVolume =
            runCatching { settings.getSmsReadingVolume() }
                .getOrDefault(1.0f)
        tvSmsVolumeValue?.text = "${(smsVolume * 100).toInt()}%"
        bindingSlider = true
        try {
            seekSmsVolume?.progress =
                (smsVolume * 100).toInt().coerceIn(0, 100)
        } finally {
            bindingSlider = false
        }
        seekSmsVolume?.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar,
                progress: Int,
                fromUser: Boolean
            ) {
                // الربط البرمجي ليس تعديلَ مستخدم — يُهمل بلا حفظ.
                if (bindingSlider) return
                tvSmsVolumeValue?.text = "$progress%"
                seekBar.setSeekStateDescription(tvSmsVolumeValue?.text ?: "")
                // **بند 6.3:** الحفظ عند كل تغيير — تعديل TalkBack لا تصل
                // نهايته إلى onStopTrackingTouch أبداً.
                runCatching {
                    settings.setSmsReadingVolume(progress / 100f)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                runCatching {
                    settings.setSmsReadingVolume(seekBar.progress / 100f)
                }
                seekBar.announceCompat("${seekBar.progress}%")
            }
        })

        // نبرة نطق الرسائل (بند 2.2) — مستقلة عن نبرة نطق اللغة؛
        // إن لم تُضبط تُعرض نبرةُ لغة التطبيق (ما سيُستعمل فعلاً).
        val smsAppLang = runCatching { settings.getAppLanguage() }
            .getOrNull() ?: "ar"
        val smsPitch =
            runCatching {
                settings.getSmsReadingPitchOrDefault(smsAppLang)
            }
                .getOrDefault(1.0f)
                .coerceAtLeast(MIN_SPEED_PITCH_FACTOR)
        tvSmsPitchValue?.text = RateLabel.of(
            fragment.requireContext(), smsPitch
        )
        bindingSlider = true
        try {
            seekSmsPitch?.progress =
                (smsPitch * 100).toInt().coerceIn(0, 200)
        } finally {
            bindingSlider = false
        }
        seekSmsPitch?.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar,
                progress: Int,
                fromUser: Boolean
            ) {
                // الربط البرمجي ليس تعديلَ مستخدم — يُهمل بلا حفظ.
                if (bindingSlider) return
                val value = progress.speedFactor()
                tvSmsPitchValue?.text = RateLabel.of(
                    fragment.requireContext(),
                    value
                )
                seekBar.setSeekStateDescription(
                    tvSmsPitchValue?.text ?: ""
                )
                // **بند 6.3:** الحفظ عند كل تغيير — تعديل TalkBack لا تصل
                // نهايته إلى onStopTrackingTouch أبداً.
                runCatching { settings.setSmsReadingPitch(value) }
                onStatusChanged()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                seekBar.snapSpeedMin()
                val value = seekBar.progress.speedFactor()
                runCatching { settings.setSmsReadingPitch(value) }
                seekBar.announceCompat(
                    RateLabel.of(fragment.requireContext(), value)
                )
                onStatusChanged()
            }
        })

        // قالب قراءة الرسائل: {name} للمرسل و{message} للرسالة
        etSmsTemplate?.setText(
            runCatching { settings.getSmsAnnouncementTemplate() }
                .getOrNull()
        )
        templateWatcher?.let { etSmsTemplate?.removeTextChangedListener(it) }
        val smsWatcher = object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) {}

            override fun onTextChanged(
                s: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {}
            override fun afterTextChanged(s: Editable?) {
                runCatching {
                    settings.setSmsAnnouncementTemplate(
                        s?.toString()?.trim()?.takeIf { it.isNotBlank() }
                    )
                }
            }
        }
        templateWatcher = smsWatcher
        etSmsTemplate?.addTextChangedListener(smsWatcher)

        // بند الأوامر 4: معاينة قراءة رسالة بالقيم المعروضة حالياً.
        view.findViewById<View>(R.id.btnPreviewSms)
            ?.setOnClickListener { previewSms() }
    }

    /** إعادة بناء سبنر أصوات الرسائل واختيار الصوت المحفوظ
     *  برمجياً تحت عَلَم الربط — عند بدء الإعداد وعند اكتمال
     *  اكتشاف المحركات خلفياً ([VoiceSelectionFragment]). */
    fun refreshSmsVoices() {
        val engine = runCatching {
            settings.getEngineForCategory(
                SettingsRepository.ANNOUNCE_CATEGORY_SMS
            )
        }.getOrNull()
        smsVoiceOptions = catalog.voicesFor(smsLanguage, engine)
        val saved = runCatching { settings.getSmsReadingVoiceId() }
            .getOrNull()
        bindingVoices = true
        try {
            spinnerSmsVoice?.adapter = fragment.simpleAdapter(
                smsVoiceOptions.map { it.label }
            )
            val idx = smsVoiceOptions.indexOfFirst { it.name == saved }
            spinnerSmsVoice?.setSelection(if (idx >= 0) idx else 0)
        } finally {
            bindingVoices = false
        }
    }

    /** معاينة رسالة تجريبية بموضع صوت السبنرا وتقدم شرائط العرض الحالية
     *  (لا القيم المحفوظة القديمة). */
    private fun previewSms() {
        val engine = runCatching {
            settings.getEngineForCategory(
                SettingsRepository.ANNOUNCE_CATEGORY_SMS
            )
        }.getOrNull()
        val sample = fragment.getString(R.string.sample_text_sms_preview)
        fragment.previewSpeech(
            buildPreviewParamsFrom(
                voiceName = smsVoiceOptions
                    .getOrNull(spinnerSmsVoice?.selectedItemPosition ?: 0)
                    ?.name.orEmpty(),
                languageTag = smsLanguage,
                enginePkg = engine,
                rateProgress = seekSmsRate?.progress ?: 100,
                pitchProgress = seekSmsPitch?.progress ?: 100,
                volumePercent = seekSmsVolume?.progress ?: 100,
                sampleText = sample
            )
        )
    }

    /** نتيجة طلب إذن قراءة الرسائل: الوضع المعلّق يُثبَّت فقط عند
     *  المنح الفعلي. */
    fun onSmsPermissionResult(granted: Boolean) {
        val ctx = fragment.context ?: return
        val pending = pendingSmsMode
        pendingSmsMode = null
        if (granted) {
            // مُنح الإذن: الآن فقط نُثبّت الوضع المعلّق المطلوب (full/source).
            if (pending != null) {
                runCatching { settings.setSmsReadingMode(pending) }
            }
            if (fragment.isAdded) {
                fragment.view?.announceCompat(
                    fragment.getString(R.string.permission_sms_granted)
                )
            }
            AnnouncementSchedulerService.requestStart(ctx)
        } else {
            // رُفض: نعيد المفتاح إلى "off" (لم يكن قد حُفظ) ونعلن السبب.
            if (pending != null) {
                runCatching { settings.setSmsReadingMode("off") }
                AnnouncementSchedulerService.syncIfRunning(ctx)
                spinnerSmsMode?.setSelection(2)
            }
            if (fragment.isAdded) {
                fragment.view?.announceCompat(
                    fragment.getString(R.string.sms_permission_needed)
                )
            }
        }
        // بند 4.11: تحديث ملخص بطاقة القسم بعد المنح أو الرفض (كان يبقى
        // يعرض الحالة القديمة حتى تدوير الشاشة).
        onStatusChanged()
    }

    /** يصفّر مراجع العرض (بند 4.1) — يُستدعى من onDestroyView. */
    fun cleanup() {
        spinnerSmsMode = null
        spinnerSmsLanguage = null
        spinnerSmsVoice = null
        seekSmsRate = null
        tvSmsRateValue = null
        seekSmsVolume = null
        tvSmsVolumeValue = null
        seekSmsPitch = null
        tvSmsPitchValue = null
        templateWatcher?.let { etSmsTemplate?.removeTextChangedListener(it) }
        templateWatcher = null
        etSmsTemplate = null
    }
}
