package com.aymankhattab.nateq.settings

import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.app.Dialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Trace
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import java.io.File
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.aymankhattab.nateq.core.common.AppDispatchers
import com.aymankhattab.nateq.core.data.UpdateChecker
import androidx.recyclerview.widget.RecyclerView
import com.aymankhattab.nateq.feature.settings.R
import com.aymankhattab.nateq.core.audio.announcement.AnnouncementSchedulerService
import com.aymankhattab.nateq.engine.NumberSpeech
import com.aymankhattab.nateq.engine.PronunciationDictionary
import com.aymankhattab.nateq.core.audio.announcement.AnnouncementSpeaker
import com.aymankhattab.nateq.util.announceCompat
import com.aymankhattab.nateq.util.LanguageCode
import com.aymankhattab.nateq.util.NetworkMetering
import dagger.hilt.android.AndroidEntryPoint
import java.util.Locale
import com.aymankhattab.nateq.core.audio.providers.EnginePicker
import com.aymankhattab.nateq.core.audio.providers.EnginePicker.InstalledEngine
import com.aymankhattab.nateq.core.audio.engine.VoiceCatalog
import com.aymankhattab.nateq.core.audio.engine.EngineWithVoices
import com.aymankhattab.nateq.core.data.SettingsRepository
import com.aymankhattab.nateq.settings.OemVendor
import com.aymankhattab.nateq.settings.SettingsViewModel.SettingsOperation

/**
 * شاشة الإعدادات الرئيسية - تتضمن:
 * 1. اختيار المحرك ثم اللغة ثم الصوت (هرمية)
 * 2. إعدادات الفئات (صوت، سرعة، نبرة، مستوى صوت)
 * 3. إعدادات إعلان الوقت
 * 4. قاموس النطق الشخصي
 */
@AndroidEntryPoint
class VoiceSelectionFragment : Fragment(R.layout.fragment_voice_selection) {

    companion object {
        // رابط تواصل المطوّر الرسمي — يُفتح خارجياً في المتصفح فلا يحتاج
        // أي إذن.
        // المعرّف الرسمي لبوت الدعم: @LordTTSBot (أنشئ عبر @BotFather).
        const val DEVELOPER_SUPPORT_URL = "https://t.me/LordTTSBot"

        /**
         * سقفُ أسطر «بصمة التطبيق» في رأس التقرير — يحمي القارئ من
         تقريرٍ ضخمٍ ويكفي كلَّ ما يهمّ التشخيص.
         */
        private const val MAX_DIAGNOSTIC_LINES = 800

        /** اسم ملف تصدير القاموس (بقرار المدير: `LOR_dictionary` لا
         *  `nateq_dictionary`) — مع امتداد JSON الذي يفرضه نوعُ
         *  `CreateDocument`، وقد يضيف النظام رقماً عند التصدير مرتين. */
        private const val DICT_EXPORT_FILE_NAME = "LOR_dictionary.json"
    }

    // طبقة الحالة المحقونة عبر Hilt (تحوي مصدرَي الإعدادات والقاموس).
    private val vm: SettingsViewModel by viewModels()

    private val settings: SettingsRepository
        get() = vm.settings

    private val pronunciationDict: PronunciationDictionary
        get() = vm.pronunciationDict

    private lateinit var categoryVoicePanel: CategoryVoicePanelController
    private lateinit var rvPronunciationDict: RecyclerView

    /** محركات TTS المثبتة (اكتشاف فقط بلا اختيار عام — لا محرك افتراضي). */
    private val engines = mutableListOf<EngineInfo>()
    private lateinit var engineSection: EngineSectionController

    /** معاينة النطق المشتركة لكل أقسام الشاشة (بند الأوامر 4) — تُغلق
     *  في [onDestroyView] عبر [VoicePreviewHelper.release]. */
    private lateinit var voicePreview: VoicePreviewHelper

    /** مستقبل اكتمال تنزيل التحديث — يُحتفظ بمرجعه ليُلغى تسجيله في
     *  [onDestroyView] (بند 6.6) حتى لا يتسرب الفصيل عند تدوير الشاشة
     *  أو مغادرتها أثناء التنزيل. */
    private var updateReceiver: android.content.BroadcastReceiver? = null

    // قسم المحرك والتحويل التلقائي (الاكتشاف/setupAutoConvertUI/
    // قائمة اللغات المكتشفة لكل المحركات...) انتقل بالكامل إلى
    // EngineSectionController.

    // ضابطات أقسام الشاشة (نقل منطق الإعدادات إليها — المرحلة ج من التفكيك)
    private lateinit var timeSection: TimeAnnouncementController
    private lateinit var batterySection: BatteryAnnouncementController
    private lateinit var notificationSection: NotificationReadingController
    private lateinit var callerSection: CallerAnnouncementController

/** إرشادات توافق الجهاز — تضمّ أيضاً مسار النطق الفوري لاسم المتصل،
 *  فيُنعش حالته في [onResume] لأنّها تتبع إعدادات النظام لا بيانات
     *  التطبيق. */
    private lateinit var oemGuidance: OemGuidanceController
    private lateinit var smsSection: SmsReadingController
    private lateinit var generalSection: GeneralSettingsController
    private lateinit var numberSection: NumberReadingController
    private lateinit var deviceHealthSection: DeviceHealthController
    private lateinit var textReadingSection: TextReadingController
    private lateinit var instantSilenceSection: InstantSilenceController

    // مفتاح تبديل لغة التطبيق (أسفل الشاشة)
    private lateinit var btnToggleLanguage:
        com.google.android.material.button.MaterialButton

    // زر التواصل مع المطوّر (يُفتح خارجياً بلا أذونات)
    private lateinit var btnContactDeveloper:
        com.google.android.material.button.MaterialButton

    // زر الإبلاغ عن خطأ (يجمع الأخطاء من سجل التطبيق ويشاركها)
    private lateinit var btnReportError:
        com.google.android.material.button.MaterialButton

    /** باب منع تكرار جمع تقرير الأخطاء (ملاحظة مراجعة السجل): ضغطتان
     *  سريعتان كانتا تشغّلان كوروتينين متوازيين يبنيان التقرير ويكتبان
     *  نفس ملف الكاش — الضغط الثاني يُرفض حتى تكتمل الرحلة الأولى. */
    private val errorReportGate = ErrorReportGate()

    // زر آخر التحديثات (يعرض ملخص الإصدار الحالي وتغييراته في حوار)
    private lateinit var btnChangelog:
        com.google.android.material.button.MaterialButton

    // المفتاح الرئيسي لكل الإعلانات
    private lateinit var switchAllAnnouncements: SwitchMaterial

    private lateinit var switchLockScreenPrivacy: SwitchMaterial
    private lateinit var btnSetDefaultEngine:
        com.google.android.material.button.MaterialButton

    // معاينة نطق رقم
    private lateinit var etNumberPreview: TextView
    private lateinit var btnPreviewNumber:
        com.google.android.material.button.MaterialButton
    private lateinit var btnStopNumberPreview:
        com.google.android.material.button.MaterialButton

    // أسماء المتصلين المخصصة
    private lateinit var btnCallerNames:
        com.google.android.material.button.MaterialButton

    // استيراد/تصدير القاموس عبر شاشة الوثائق (SAF)
    private lateinit var btnImportDict:
        com.google.android.material.button.MaterialButton
    private lateinit var btnExportDict:
        com.google.android.material.button.MaterialButton
    // نص ملف القاموس المُختار من SAF لحين اختيار طريقة الاستيراد (دمج/استبدال)
    private var pendingImportJson: String? = null

    // نوافذ حوارية مفتوحة: تُغلق كلها عند تدمير العرض حتى لا يتسرب
    // مرجع الواجهة (WindowLeaked) عند تدوير الشاشة.
    private val activeDialogs =
        java.util.Collections.synchronizedSet(mutableSetOf<Dialog>())

    /** يسجّل حواراً مفتوحاً ليُغلق تلقائياً مع تدمير عرض الشاشة، ويزيله
     *  من السجل عند إغلاقه يدوياً. */
    internal fun trackDialog(dialog: Dialog) {
        activeDialogs.add(dialog)
        dialog.setOnDismissListener { activeDialogs.remove(dialog) }
    }

    /**
     * استيراد القاموس: **`.json` فقط** (بقرار المدير) — لا تُعرض كل
     * الملفات ولا تُقبل إلا JSON.
     *
     * **لماذا ثلاثة أنواع MIME لا واحد؟** فلتر SAF يستثني ما لا يطابق
     * نوعه، وكثيرٌ من مزوّدي الملفات يُبلّغ عن `.json` بصفة `text/plain`
     * أو `application/octet-stream` لا `application/json` — فيختفي الملف
     * الصحيح من القائمة ولا يراه المستخدم. فالمفلتر يعرض الثلاثة، ثم
     * يُتحقَّق من الامتداد أدناه فيُرفض غيرُ `.json` صراحةً. فالنتيجة
     * المطلوبة محققة: **لا يُعرض إلا JSON ولا يُقبل إلا JSON**.
     */
    private val jsonOnlyMimeTypes = arrayOf(
        "application/json",
        "text/json",
        "text/plain"
    )

    private val openDictLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val resolver =
                context?.contentResolver ?: return@registerForActivityResult
            // التحقق من الامتداد: يُقبل ما ينتهي بـ `.json` فقط، وما
            // لا اسمَ له (بعض المزوّدين) يُحمل على أنه JSON ويُخضعه
            // لفشل التجزئة لاحقاً — فلا يدخل إلا ما يمكن قراءته.
            val name = runCatching {
                resolver.query(uri, null, null, null, null)?.use { cur ->
                    val idx = cur.getColumnIndex(
                        android.provider.OpenableColumns.DISPLAY_NAME
                    )
                    if (idx >= 0 && cur.moveToFirst()) cur.getString(idx)
                    else null
                }
            }.getOrNull()
            if (name != null &&
                !name.endsWith(".json", ignoreCase = true)
            ) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.dict_import_failed),
                    Toast.LENGTH_SHORT
                ).show()
                return@registerForActivityResult
            }
            // نقرأ الملف على خيط IO ثم نعرض حوار طريقة الاستيراد (دمج/استبدال)
            lifecycleScope.launch(AppDispatchers.io) {
                val result = runCatching { readJsonWithinLimit(resolver, uri) }
                    .getOrDefault(DictReadResult.Unreadable)
                withContext(AppDispatchers.main) {
                    if (!isAdded) return@withContext
                    when (result) {
                        is DictReadResult.Ok -> {
                            pendingImportJson = result.json
                            showImportModeDialog()
                        }
                        // سببان مختلفان ورسالتان: «الكبير» ليس «الفاسد».
                        DictReadResult.TooLarge -> toast(
                            getString(R.string.dict_import_too_large)
                        )
                        DictReadResult.Unreadable -> toast(
                            getString(R.string.dict_import_failed)
                        )
                    }
                }
            }
        }
    }

    private fun toast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    /** نتيجة قراءة ملف القاموس — تُميّز سببَ الرفض ليُقال للمستخدم. */
    private sealed interface DictReadResult {
        data class Ok(val json: String) : DictReadResult
        data object TooLarge : DictReadResult
        data object Unreadable : DictReadResult
    }

    /**
     * قراءةٌ **محدودةٌ بالبايت** لا `readText()` المفتوح.
     *
     * **لماذا؟** `readText()` يقرأ الملف كلَّه ثم نُفحص الحجم بعده — فسقفُ
     * 8 ميغابايت لا يمنع شيئاً، بل يكتشف الخسارة بعد وقوعها: ملفٌ
     * بمئة ميغابايت يُحمَّل كاملاً فيُOOM التطبيق قبل أن تُقال «رُفض».
     * فنتوقّف عند تجاوز السقف أثناء القراءة، فلا يُحمَّل إلا ما يُسمح.
     */
    private fun readJsonWithinLimit(
        resolver: android.content.ContentResolver,
        uri: android.net.Uri
    ): DictReadResult {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        val max = PronunciationDictionary.MAX_IMPORT_BYTES
        val stream = resolver.openInputStream(uri)
            ?: return DictReadResult.Unreadable
        stream.use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                // لا نقرأ أكثر من السقف أبداً: الملفُ الزائد يُرفض
                // وهو لم يُحمَّل بعد.
                if (out.size() + read > max) return DictReadResult.TooLarge
                out.write(buffer, 0, read)
            }
        }
        return DictReadResult.Ok(String(out.toByteArray(), Charsets.UTF_8))
    }

    private val createDictLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val resolver =
                context?.contentResolver ?: return@registerForActivityResult
            // التصدير كاملاً على خيط IO عبر الفي إم (لا تجميد في Main)
            vm.exportDict(uri, resolver)
        }
    }

    /** حوار طريقة الاستيراد: دمج مع الإدخالات الحالية أو استبدال كامل، ثم
     *  تطبيق ملف القاموس المُختار من SAF بالطريقة المختارة (يُحفظ نصه في
     *  [pendingImportJson] كي لا يقفز حوار الطريقة خارج سياق النتيجة). */
    private fun showImportModeDialog() {
        val json = pendingImportJson ?: return
        val currentContext = context ?: return
        val options = arrayOf(
            getString(R.string.dict_import_merge),
            getString(R.string.dict_import_replace)
        )
        MaterialAlertDialogBuilder(currentContext)
            .setTitle(R.string.dict_import_mode_title)
            .setItems(options) { _, which ->
                pendingImportJson = null
                // الاستيراد كاملاً على خيط IO عبر الفي إم
                vm.importDict(json, merge = which == 0)
            }
            .setNegativeButton(getString(R.string.cancel)) { _, _ ->
                pendingImportJson = null
            }
            .setOnCancelListener { pendingImportJson = null }
            .create().also(::trackDialog).show()
    }

    // ===== النسخ الاحتياطي / الاستعادة الكاملان
    // (إعدادات + قاموس + أسماء متصلين) =====
    private val createBackupLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val resolver =
                context?.contentResolver ?: return@registerForActivityResult
            // التصدير كاملاً على خيط IO عبر الفي إم
            vm.exportBackup(uri, resolver)
        }
    }

    private val openRestoreLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val resolver =
                context?.contentResolver ?: return@registerForActivityResult
            // القراءة والتفكيك والاستعادة كلها على خيط IO عبر الفي إم
            vm.restoreBackup(uri, resolver)
        }
    }

    private var announcementSpeaker: AnnouncementSpeaker? = null

    // كتالوج صريح للأصوات المدعومة في ناطق (يتطابق مع onGetVoices)
    // مبسّطة إلى لغتين فقط: "العربية" و"الإنجليزية"
    private lateinit var nateqVoices: List<NateqVoice>

    // كتالوج متدرج (لغة ← محرك ← أصوات) لصفوف الفئات والرسائل
    // والمتصل والبطارية — يُملأ من اكتشاف المحركات الخلفي.
    private lateinit var engineCatalog: EngineVoicesCatalog

    // طلب إذنَي القراءة عند تفعيل إعلان المتصل (READ_PHONE_STATE لاستقبال
    // بث PHONE_STATE المحمي، وREAD_CALL_LOG للوصول إلى الرقم على أندرويد 12+
    // والاسم من سجل المكالمات، وREAD_CONTACTS للبحث عن الاسم في دفتر
    // الاتصالات).
    // يبقى المُطلِق في الفصيل (يحتاج registerForActivityResult) ونتيجتُه
    // تُحمَّل إلى ضابط قسم المتصل الذي يملك المفتاح والحارس.
    internal val callerPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (::callerSection.isInitialized) {
            callerSection.onPermissionsResult(granted)
        }
    }

    /** منتقي ملف نغمة الساعة المخصصة (ACTION_OPEN_DOCUMENT). */
    internal val customChimeLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (::timeSection.isInitialized) {
            timeSection.onCustomChimeResult(result)
        }
    }

    // طلب إذن قراءة الرسائل الواردة لحظة تفعيل قراءة الرسائل فقط (لا عند
    // أول تشغيل). الوضع المختار (full/source) لا يُحفظ إلا بعد المنح الفعلي —
    // مسؤولية الضابط (بند [9]).
    internal val smsPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (::smsSection.isInitialized) {
            smsSection.onSmsPermissionResult(granted)
        }
    }

    // ===== ضابط الأكورديون والتنقّل: بطاقات الأقسام وبناء أسطر الحالة =====
    private lateinit var accordion: SettingsAccordionController

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        Trace.beginSection("VoiceSelectionFragment.onViewCreated")
        try {
            super.onViewCreated(view, savedInstanceState)
        // لا إنشاء مباشر للإعدادات/القاموس: كلاهما محقون عبر
        // SettingsViewModel.

        // edge-to-edge (إلزامي من targetSdk 35+): نطبّق الوسائد يدوياً عبر
        // ViewCompat.setOnApplyWindowInsetsListener
        // بدل android:fitsSystemWindows
        // (الحل المهمل) حتى لا تُغطى أي عناصر تفاعلية تحت شريط الحالة/التنقل.
        // تُعاد الوسائد عند كل تغيير (إظهار/إخفاء الأشرطة) فتنزلق العبارة
        // العليا والملاحة السفلية تحت النظام تلقائياً.
        ViewCompat.setOnApplyWindowInsetsListener(
            view.findViewById(R.id.sv_settings_scroll)
        ) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        // تهيئة الأصوات هنا بعد الانضمام للسياق (لا يجوز في مُنشئ/خاصية
        // تستدعي getString())
        nateqVoices = listOf(
            NateqVoice(
                "ar-EG",
                LanguageCode.AR.tag,
                getString(R.string.voice_name_arabic),
                Locale.forLanguageTag(LanguageCode.AR.tag)
            ),
            NateqVoice(
                "en-US",
                LanguageCode.EN.tag,
                getString(R.string.voice_name_english),
                Locale.forLanguageTag(LanguageCode.EN.tag)
            )
        )

        // كتالوج متدرج — يبدأ فارغاً فيعتمد على الأصوات الاحتياطية
        // (العربية/الإنجليزية) ثم يُملأ من الاكتشاف الخلفي.
        engineCatalog = EngineVoicesCatalog(
            emptyMap(),
            getString(R.string.voice_name_arabic),
            getString(R.string.voice_name_english)
        )

        // قسم المحركات: اكتشاف المحركات المثبتة فقط (لا صندوق اختيار عام —
        // لا محرك افتراضي؛ محرك كل لغة/فئة يُحسم وقت النطق)
        voicePreview = VoicePreviewHelper(requireContext().applicationContext)
        accordion = SettingsAccordionController(
            this,
            settings,
            nateqVoices,
            engineCatalog
        ).apply {
            setup(view, viewLifecycleOwner)
        }
        engineSection = EngineSectionController(
            this, settings, engines, voicePreview
        ).apply {
                onStatusChanged = { accordion.updateSectionStatuses() }
            }
        engineSection.setupEngineDiscovery()

        // لوحة فئات الأصوات بعد إعادة التصميم: فئة واحدة معروضة في كل
        // مرة (لغة/محرك/صوت/أشرطة) تختارها من سبnner علوي واحد، أو لوحة
        // إعلان المتصل — والتعديلات لا تُحفظ إلا بضغط زر الحفظ أسفل
        // الشاشة (مع تأكيدٍ عند مغادرة فئة بتعديلات غير محفوظة).
        categoryVoicePanel = CategoryVoicePanelController(
            this,
            settings,
            engineCatalog,
            // معاينة المتصل باللغة المختارة (عربي/إنجليزي). الضابط يُنشأ
            // قبل callerSection فيُحال النداء إليه متى جُهّز.
            onPreviewCaller = { langTag ->
                if (::callerSection.isInitialized) {
                    callerSection.previewCaller(langTag)
                }
            }
        ).apply { setup(view) }

        // زر الحفظ الصريح: يكتب الفئة المعروضة فقط (لا كل الفئات دفعة),
        // فيستقر الصوت المحفوظ بلا اعتماد على الاستدلال اللغوي.
        val btnSaveCategories:
            com.google.android.material.button.MaterialButton =
            view.findViewById(R.id.btn_save_categories)
        btnSaveCategories.setOnClickListener {
            categoryVoicePanel.saveCurrent()
            view.announceCompat(getString(R.string.categories_saved))
            accordion.updateSectionStatuses()
        }

        // Pronunciation dictionary RecyclerView
        rvPronunciationDict = view.findViewById(R.id.rv_pronunciation_dict)
        rvPronunciationDict.layoutManager = LinearLayoutManager(
            requireContext()
        )
        rvPronunciationDict.adapter = null
        // التمرير الداخلي مفعّل ليتدحرج القاموس المحدود الارتفاع داخل الصفحة
        rvPronunciationDict.isNestedScrollingEnabled = true
        refreshDictAdapter()

        // Add dictionary entry button
        val btnAddDictEntry = view.findViewById(
            R.id.btn_add_dict_entry
        ) as com.google.android.material.button.MaterialButton
        btnAddDictEntry.setOnClickListener { showDictEditDialog() }

        btnImportDict = view.findViewById(R.id.btn_import_dict)
        btnImportDict.setOnClickListener {
            runCatching {
                openDictLauncher.launch(jsonOnlyMimeTypes)
            }
        }
        btnExportDict = view.findViewById(R.id.btn_export_dict)
        btnExportDict.setOnClickListener {
            runCatching { createDictLauncher.launch(DICT_EXPORT_FILE_NAME) }
        }
        val btnClearDict = view.findViewById<MaterialButton>(R.id.btn_clear_dict)
        btnClearDict.setOnClickListener { showClearDictConfirmDialog() }

        // المفتاح الرئيسي لكل الإعلانات
        switchAllAnnouncements =
            view.findViewById(R.id.switch_all_announcements)
        switchAllAnnouncements.isChecked =
            runCatching { settings.isAllAnnouncementsEnabled() }
                .getOrDefault(true)
        switchAllAnnouncements.setOnCheckedChangeListener { _, checked ->
            runCatching { settings.setAllAnnouncementsEnabled(checked) }
            if (checked) {
                AnnouncementSchedulerService.requestStart(requireContext())
                accordion.warnIfNotificationsHidden()
            } else {
                runCatching {
                    requireContext().stopService(
                        Intent(
                            requireContext(),
                            AnnouncementSchedulerService::class.java
                        )
                    )
                }
            }
            accordion.updateSectionStatuses()
            view?.announceCompat(
                getString(
                    if (checked) R.string.announcement_turned_on
                    else R.string.announcement_turned_off
                )
            )
        }

        // حماية خصوصية قفل الشاشة: حجب تفاصيل الرسائل/الإشعارات/المتصل
        // عند القفل
        switchLockScreenPrivacy =
            view.findViewById(R.id.switch_lock_screen_privacy)
        switchLockScreenPrivacy.isChecked =
            runCatching { settings.isLockScreenPrivacyEnabled() }
                .getOrDefault(true)
        switchLockScreenPrivacy.setOnCheckedChangeListener { _, checked ->
            runCatching { settings.setLockScreenPrivacyEnabled(checked) }
            view?.announceCompat(
                getString(
                    if (checked) R.string.announcement_turned_on
                    else R.string.announcement_turned_off
                )
            )
        }

        // نطق الإيموجي ورموز المشاعر: تُنطق الأسماء بدل حذف الرموز من النطق
        val switchEmojiReading: SwitchMaterial =
            view.findViewById(R.id.switch_emoji_reading)
        switchEmojiReading.isChecked =
            runCatching { settings.isEmojiPronunciationEnabled() }
                .getOrDefault(true)
        switchEmojiReading.setOnCheckedChangeListener { _, checked ->
            runCatching { settings.setEmojiPronunciationEnabled(checked) }
            accordion.updateSectionStatuses()
            view?.announceCompat(
                getString(
                    if (checked) R.string.announcement_turned_on
                    else R.string.announcement_turned_off
                )
            )
        }

        // زر جعل ناطق المحرك الافتراضي (يفتح شاشة TTS النظامية لاختياره
        // يدوياً)
        btnSetDefaultEngine = view.findViewById(R.id.btn_set_default_engine)
        btnSetDefaultEngine.setOnClickListener {
            runCatching {
                startActivity(
                    // الثابت الرسمي لنافذة إعدادات TTS غير متاح في كل مستويات
                    // SDK، لذا نستخدم الإجراء النصي الثابت نفسه.
                    Intent("com.android.settings.TTS_SETTINGS")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            Toast.makeText(
                requireContext(),
                R.string.set_default_engine_hint,
                Toast.LENGTH_LONG
            ).show()
            view?.announceCompat(getString(R.string.set_default_engine_hint))
        }

        // معاينة نطق رقم
        etNumberPreview = view.findViewById(R.id.et_number_preview)
        btnPreviewNumber = view.findViewById(R.id.btn_preview_number)
        btnStopNumberPreview = view.findViewById(R.id.btn_stop_number_preview)
        btnPreviewNumber.setOnClickListener { previewNumber() }
        btnStopNumberPreview.setOnClickListener {
            announcementSpeaker?.stop()
        }

        // أسماء المتصلين المخصصة
        btnCallerNames = view.findViewById(R.id.btn_caller_names)
        btnCallerNames.setOnClickListener { showCallerNamesDialog() }

        // مفتاح تبديل لغة التطبيق (أسفل الشاشة)
        btnToggleLanguage = view.findViewById(R.id.btn_toggle_language)

        // زر التواصل مع المطوّر: يفتح رابط الدعم خارجياً دون كشف وسيلة التواصل
        btnContactDeveloper = view.findViewById(R.id.btn_contact_developer)
        btnContactDeveloper.setOnClickListener { openDeveloperSupport() }

        // زر الإبلاغ عن خطأ: الضغطة الأولى تبدأ مراقبة السجل التقني ثم
        // «تم» تجمع التقرير من نافذة الالتقاط الحية وتشاركه (مراجعة
        // تقرير «أبو أحمد»: التقاط لحظة الضغط فقط كان يُفرغ التقرير).
        btnReportError = view.findViewById(R.id.btn_report_error)
        btnReportError.setOnClickListener { onReportErrorClicked() }
        syncReportErrorButtonText()

        // زر آخر التحديثات: يعرض ملخص أحدث إصدار وتغييراته في حوار
        btnChangelog = view.findViewById(R.id.btn_changelog)
        btnChangelog.setOnClickListener { showChangelogDialog() }

        // زر التشخيص: يعرض معلومات شاملة عن حالة التطبيق والمحركات والأذونات
        // مع إمكانية النسخ إلى الحافظة
        val btnDiagnostics = view.findViewById<View>(R.id.btn_diagnostics)
        btnDiagnostics.setOnClickListener { showDiagnosticsDialog() }

        // إنشاء ضابطات الأقسام وربطها (المرحلة ج): كل ضابط يسحب عناصره
        // ويبني مستمعيه عند setup()، وonStatusChanged تُحدّث أسطر حالة
        // الأكورديون.
        timeSection = TimeAnnouncementController(
            this, settings, nateqVoices,
            { accordion.navigateToSection(R.id.ll_oem_guidance_content) },
            { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        batterySection = BatteryAnnouncementController(
            this, settings,
            { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        notificationSection = NotificationReadingController(
            this, settings, nateqVoices, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        callerSection = CallerAnnouncementController(
            this, settings, engineCatalog,
            onStatusChanged = { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        smsSection = SmsReadingController(
            this, settings, engineCatalog,
            { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        generalSection = GeneralSettingsController(
            this, settings, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        numberSection = NumberReadingController(
            this, settings, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        deviceHealthSection = DeviceHealthController(
            this, settings, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        textReadingSection = TextReadingController(
            this, settings, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        instantSilenceSection = InstantSilenceController(
            this, settings, { accordion.updateSectionStatuses() }
        ).apply { setup(view) }
        oemGuidance = OemGuidanceController(this).apply { setup(view) }
        setupLanguageToggle()
        setupCheckUpdates()
        engineSection.setupAutoConvertUI(view)
        setupSaveAndResetButtons()
        setupBackupRestoreButtons()
        accordion.updateSectionStatuses()
        // اكتشاف متدرج (لغة ← محرك ← أصوات): يُملأ الكتالوج خلفياً ثم تُنعش
        // قوائم الفئات والرسائل/المتصل/البطارية. كتالوج فارغ = الأصوات
        // الاحتياطية (العربية/الإنجليزية).
        viewLifecycleOwner.lifecycleScope.launch {
            val discovery = withContext(AppDispatchers.io) {
                try {
                    VoiceCatalog.discoverAllLanguagesAcrossEngines(
                        requireContext()
                    )
                } catch (_: Throwable) {
                    emptyMap<String, List<EngineWithVoices>>()
                }
            }
            engineCatalog.update(
                discovery.mapValues { (_, engines) ->
                    engines.map { row ->
                        EngineVoicesRow(
                            row.enginePackage,
                            row.engineLabel,
                            row.voices.map { voice ->
                                VoiceOption(voice.name, voice.name)
                            }
                        )
                    }
                }
            )
            if (!isAdded) return@launch
            categoryVoicePanel.refreshLanguages()
            smsSection.refreshSmsVoices()
            callerSection.refreshCallerVoices()
        }
        // بند 4.6: إعادة فتح الشاشة (مجموعة/قسم) التي كان يعدّلها المستخدم
        // قبل تدوير الجهاز بدل طردِه إلى الصفحة الرئيسية.
        if (savedInstanceState != null) {
            accordion.restoreState(savedInstanceState)
            if (::timeSection.isInitialized) {
                timeSection.restoreInstanceState(savedInstanceState)
            }
        }

        // التحديث التفاعلي: المراجعة الابتدائية (0) لا تُحدّث شيئاً،
        // وأي مراجعة لاحقة (استعادة/إعادة ضبط) تُعيد بناء كل أقسام
        // الواجهة تلقائياً.
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vm.settingsRevision.collect { revision ->
                        if (revision > 0) refreshAllSettingsUi()
                    }
                }
                launch {
                    vm.operationEvents.collect(::handleOperationEvent)
                }
            }
        }

            // فحص تلقائي عند فتح التطبيق: يُنبه بوجود تحديث (صامت إن لم يوجد)
            checkForUpdatesOnStart()
        } finally {
            Trace.endSection()
        }
    }

    /** بند 4.7: عند العودة من شاشات النظام (منح إذن المنبهات الدقيقة /
     *  إشعارات) تُعاد حالة صفوف طلب الإذن ومُلخّصات الأقسام فوراً بدل
     *  الانتظار حتى يعود الفصيل من الخلفية. */
    override fun onResume() {
        super.onResume()
        if (::timeSection.isInitialized) timeSection.refreshExactAlarmRow()
        if (::oemGuidance.isInitialized) {
            oemGuidance.refreshInstantIdentityStatus()
        }
        if (::accordion.isInitialized) accordion.updateSectionStatuses()
    }

    /** بند 4.6: حفظ موضع التنقّل في الأكورديون لاستعادته بعد التدوير. */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::accordion.isInitialized) {
            outState.putAll(accordion.saveState())
        }
        if (::timeSection.isInitialized) {
            timeSection.saveInstanceState(outState)
        }
    }

    override fun onDestroyView() {
        // تفريغ مساند القوائم لمنع تسريب المراجع والواجهات
        if (::rvPronunciationDict.isInitialized) {
            rvPronunciationDict.adapter = null
        }
        pronunciationDictAdapter = null

        // إغلاق المتحدث المستقل الخاص بالمعاينة (إن أُنشئ) حتى لا يبقى محرك
        // TTS مفتوحاً بعد مغادرة الشاشة. المثيل هنا خاص بالشاشة وليس المشترك
        // (getInstance) الذي تُدار حياته في مستقبلات الإعلانات التلقائية.
        // **بند 4.4:** shutdown() لا stop() — المعاينة الخاصة تُغلَق تاماً
        // (محرك TTS نفسه) عند مغادرة الشاشة بدل بقائها قيد الحياة حتى
        // تحرر المحرك وتتوقف تسريبات مؤقتات الاسترداد.
        announcementSpeaker?.shutdown()
        announcementSpeaker = null
        // إغلاق معاينة النطق المشتركة (بند 4.2) — أي محرك TTS مؤقت فُتح
        // للمعاينة يُغلق تماماً عند مغادرة الشاشة.
        if (::voicePreview.isInitialized) voicePreview.release()
        if (::oemGuidance.isInitialized) oemGuidance.release()
        // إغلاق كل النوافذ المفتوحة حتى لا تتسرب مراجع الواجهة (WindowLeaked)
        // عند تدوير الشاشة أو مغادرتها.
        val open = activeDialogs.toList()
        activeDialogs.clear()
        open.forEach { runCatching { it.dismiss() } }
        // تصفير مراجع العرض في كل الضوابط (بند 4.1) وحتى لا تبقى شجرة العرض
        // القديمة محتجزة عبر أي ضابط بعد تدوير الشاشة أو مغادرتها.
        if (::categoryVoicePanel.isInitialized) categoryVoicePanel.cleanup()
        if (::engineSection.isInitialized) engineSection.cleanup()
        if (::timeSection.isInitialized) timeSection.cleanup()
        if (::batterySection.isInitialized) batterySection.cleanup()
        if (::notificationSection.isInitialized) notificationSection.cleanup()
        if (::callerSection.isInitialized) callerSection.cleanup()
        if (::smsSection.isInitialized) smsSection.cleanup()
        if (::generalSection.isInitialized) generalSection.cleanup()
        if (::numberSection.isInitialized) numberSection.cleanup()
        if (::deviceHealthSection.isInitialized) deviceHealthSection.cleanup()
        if (::textReadingSection.isInitialized) textReadingSection.cleanup()
        if (::instantSilenceSection.isInitialized) {
            instantSilenceSection.cleanup()
        }
        updateReceiver?.let { receiver ->
            runCatching {
                requireContext().applicationContext.unregisterReceiver(receiver)
            }
            updateReceiver = null
        }
        if (::accordion.isInitialized) accordion.cleanup()
        super.onDestroyView()
    }

    /** يعالج أحداث العمليات غير المتزامنة القادمة من الفي إم (تجري كلها على
     *  خيط IO في الفي إم): يعرض النتيجة ويعيد رسكلة القاموس عند الحاجة. */
    private fun handleOperationEvent(event: SettingsOperation) {
        val stats = when (event) {
            is SettingsOperation.DictImported -> {
                if (event.ok) refreshDictAdapter()
                if (event.ok) R.string.dict_imported_ok
                else R.string.dict_import_failed
            }
            is SettingsOperation.DictExported -> if (event.ok)
                R.string.dict_exported_ok else R.string.dict_export_failed
            is SettingsOperation.BackedUp -> if (event.ok)
                R.string.backup_saved else R.string.backup_failed
            is SettingsOperation.Restored -> {
                if (event.ok) {
                    // إعادة عرض الأقسام تتم تلقائياً
                    // عبر مراجعة settingsRevision
                    AnnouncementSchedulerService.requestStart(requireContext())
                    if (event.callersOnly) R.string.restore_done_callers_only
                    else R.string.restore_done
                } else {
                    R.string.restore_failed
                }
            }
        }
        val duration = if (event is SettingsOperation.Restored)
            Toast.LENGTH_LONG else Toast.LENGTH_SHORT
        Toast.makeText(requireContext(), stats, duration).show()
        view?.announceCompat(getString(stats))
    }

    // ===== اختيار المحرك وحوار التحويل التلقائي: انتقلا إلى
    // EngineSectionController =====
    /** نسخة حصرية للفصيل من محلّل الـ Spinner الأساسي (المنفَّذ في
     *  EngineSectionController). */
    internal fun simpleAdapter(items: List<String>): ArrayAdapter<String> =
        simpleAdapter(requireContext(), items)

    // ===== قاموس النطق =====
    private fun showDictEditDialog(existing: Pair<String, String>? = null) {
        val builder = MaterialAlertDialogBuilder(requireContext())
        val inflater = LayoutInflater.from(requireContext())
        val dialogView = inflater.inflate(R.layout.dialog_dict_entry, null)
        val etWord = dialogView.findViewById<EditText>(R.id.et_dict_word)
        val etPhonetic =
            dialogView.findViewById<EditText>(R.id.et_dict_phonetic)
        if (existing != null) {
            etWord.setText(existing.first)
            etPhonetic.setText(existing.second)
        }
        builder.setView(dialogView)
            .setTitle(
                if (existing == null) getString(R.string.dict_add_title)
                else getString(R.string.dict_edit_entry)
            )
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                val word = etWord.text.toString().trim()
                val phonetic = etPhonetic.text.toString().trim()
                if (word.isNotEmpty() && phonetic.isNotEmpty()) {
                    if (existing != null && existing.first != word) {
                        runCatching {
                            pronunciationDict.removeEntry(existing.first)
                        }
                    }
                    runCatching { pronunciationDict.addEntry(word, phonetic) }
                    refreshDictAdapter()
                } else {
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.enter_word_and_pronunciation),
                        Toast.LENGTH_SHORT
                    ).show()
                    view?.announceCompat(
                        getString(R.string.enter_word_and_pronunciation)
                    )
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .create().also(::trackDialog).show()
    }

    /** مربع تأكيد لمسح القاموس بالكامل */
    private fun showClearDictConfirmDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.dict_clear_all))
            .setMessage(getString(R.string.dict_clear_confirm))
            .setPositiveButton(getString(R.string.dict_clear_all)) { _, _ ->
                runCatching { pronunciationDict.clearAll() }
                refreshDictAdapter()
                Toast.makeText(
                    requireContext(),
                    getString(R.string.dict_cleared_ok),
                    Toast.LENGTH_SHORT
                ).show()
                view?.announceCompat(getString(R.string.dict_cleared_ok))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .create().also(::trackDialog).show()
    }

    /** المثيل الوحيد لمسند القاموس — يُعاد استخدامه عبر submitList بدل
     *  بناء مسند جديد وإعادة تسنيده بالكامل مع كل تغيير. */
    private var pronunciationDictAdapter: PronunciationDictAdapter? = null

    /** إعادة رسم قائمة إدخالات القاموس بعد أي تغيير
     *  (إضافة/تعديل/حذف/استيراد) — يحسب المسند الفرق فيحدّث الصفوف المتغيّرة
     *  فقط ويحافظ على موضع التمرير. */
    private fun refreshDictAdapter() {
        val entries = runCatching { pronunciationDict.getAllEntries() }
            .getOrDefault(emptyMap())
            .toList()
        val adapter = pronunciationDictAdapter
            ?: PronunciationDictAdapter(::showDictRowOptions).also {
                pronunciationDictAdapter = it
                rvPronunciationDict.adapter = it
            }
        adapter.submitList(entries)
    }

    /** نطق الرقم المدخل في حقل المعاينة بنفس منطق النطق الفعلي للإعلانات */
    private fun previewNumber() {
        // نقبل الأرقام الهندية/الشرقية في الحقل (٠١٢٣...) مع الغربية
        val raw = com.aymankhattab.nateq.util.LocaleUtils.normalizeIndicDigits(
            etNumberPreview.text.toString().trim()
        )
        // نقبل الأرقام الصحيحة والعشرية والسالبة
        val isValid = raw.isNotEmpty() && raw.matches(
            Regex("""^-?\d+(\.\d+)?$""")
        )
        if (!isValid) {
            Toast.makeText(
                requireContext(),
                R.string.number_preview_invalid,
                Toast.LENGTH_SHORT
            ).show()
            view?.announceCompat(getString(R.string.number_preview_invalid))
            return
        }
        val forced =
            runCatching { settings.getAnnouncementSpeechLanguage() }
                .getOrNull()
        val appLang = runCatching { settings.getAppLanguage() }.getOrNull()
            ?: Locale.getDefault().language
        val isEnglish = if (forced != null) LanguageCode.isEnglish(forced)
            else LanguageCode.isEnglish(appLang)
        val mode = runCatching { settings.getNumberReadingMode() }
            .getOrDefault(1).coerceIn(1, 8)
        val text = NumberSpeech.formatByMode(mode, raw, isEnglish)
        val langTag =
            if (isEnglish) LanguageCode.EN.tag else LanguageCode.AR.tag
        // يمر عبر مسار فئة الأرقام (speakWithCategory) لا speakWithVoice:
        // تحترم المعاينة محركَ/سرعةَ/صوتَ فئة الأرقام المحفوظة — كانت تُنطق
        // دائماً بمحرك اللغة/النظام (جوجل غالباً) وتتجاهل اختيار فئة الأرقام.
        speakWithCategory(
            SettingsRepository.VOICE_CATEGORY_NUMBERS, langTag, text
        )
    }

    /** حوار إدارة أسماء المتصلين المخصصة (رقم → اسم يُنطق به) */
    private fun showCallerNamesDialog() {
        val names = runCatching { settings.getCustomCallerNames() }
            .getOrDefault(emptyMap()).toMutableMap()
        val rows = names.toList().toMutableList()
        val root = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            // هوامش بمعامل الكثافة حتى لا تتضخم على الشاشات عالية الدقة
            val density = resources.displayMetrics.density
            setPadding(
                (48 * density).toInt(),
                (24 * density).toInt(),
                (48 * density).toInt(),
                0
            )
        }
        val listContainer = android.widget.LinearLayout(
            requireContext()
        ).apply {
            orientation = android.widget.LinearLayout.VERTICAL
        }

        fun addRow(number: String = "", name: String = "") {
            val numberPicker =
                com.google.android.material.textfield.TextInputEditText(
                    requireContext()
                ).apply {
                hint = getString(R.string.caller_names_number_hint)
                inputType = android.text.InputType.TYPE_CLASS_PHONE
                setText(number)
            }
            val namePicker =
                com.google.android.material.textfield.TextInputEditText(
                    requireContext()
                ).apply {
                hint = getString(R.string.caller_names_name_hint)
                setText(name)
            }
            val removeBtn = com.google.android.material.button.MaterialButton(
                requireContext(),
                null,
                com.google.android.material.R.style
                    .Widget_MaterialComponents_Button_TextButton
            ).apply {
                text = getString(R.string.caller_names_delete)
                textSize = 13f
                // وصولية (بند 4.5): زرُ الحذف يعرّف نفسه باسم أو رقم
                // الجهة المستهدفة حتى لا تُقرأ «حذف، زر» متكررة مجهولة
                // لقارئ الشاشة عند وجود عدة أرقام.
                contentDescription = when {
                    name.isNotBlank() -> getString(
                        R.string.caller_names_delete_for, name
                    )
                    number.isNotBlank() -> getString(
                        R.string.caller_names_delete_for, number
                    )
                    else -> getString(R.string.caller_names_delete)
                }
                // أهداف لمس لا تقل عن 48dp لقارئ الشاشة
                minHeight = (48 * resources.displayMetrics.density).toInt()
            }
            val numberInputLayout =
                com.google.android.material.textfield.TextInputLayout(
                    requireContext()
                ).apply {
                    addView(numberPicker)
                }
            val nameInputLayout =
                com.google.android.material.textfield.TextInputLayout(
                    requireContext()
                ).apply {
                    addView(namePicker)
                }
            val rowLayout =
                android.widget.LinearLayout(requireContext()).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    addView(
                        numberInputLayout,
                        android.widget.LinearLayout.LayoutParams(0, -2, 2f)
                    )
                    addView(
                        nameInputLayout,
                        android.widget.LinearLayout.LayoutParams(0, -2, 2f)
                    )
                    addView(
                        removeBtn,
                        android.widget.LinearLayout.LayoutParams(-2, -2)
                    )
                }
            removeBtn.setOnClickListener {
                listContainer.removeView(rowLayout)
                val key = numberPicker.text.toString().trim()
                rows.removeAll { it.first == key }
            }
            listContainer.addView(rowLayout)
            rows.add(number to name)
        }

        names.forEach { (n, nm) -> addRow(n, nm) }
        if (rows.isEmpty()) {
            val emptyHint = TextView(requireContext()).apply {
                text = getString(R.string.caller_names_empty)
                textSize = 13f
                val pad = (16 * resources.displayMetrics.density).toInt()
                setPadding(0, pad, 0, pad)
            }
            listContainer.addView(emptyHint)
        }
        val addBtn = com.google.android.material.button.MaterialButton(
            requireContext(),
            null,
            com.google.android.material.R.style
                    .Widget_MaterialComponents_Button_TextButton
        ).apply {
            text = getString(R.string.caller_names_add)
            minHeight = (48 * resources.displayMetrics.density).toInt()
        }
        addBtn.setOnClickListener { addRow() }

        val scroll = android.widget.ScrollView(requireContext()).apply {
            addView(listContainer)
        }
        root.addView(
            scroll,
            android.widget.LinearLayout.LayoutParams(-1, 0, 1f)
        )
        root.addView(addBtn)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.caller_names_title))
            .setView(root)
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                val newNames = mutableMapOf<String, String>()
                var duplicate = false
                for (i in 0 until listContainer.childCount) {
                    val rowLayout = listContainer.getChildAt(i)
                        as? android.widget.LinearLayout ?: continue
                    if (rowLayout.childCount < 2) continue
                    val numLayout = rowLayout.getChildAt(0)
                        as? com.google.android.material.textfield
                            .TextInputLayout ?: continue
                    val nameLayout = rowLayout.getChildAt(1)
                        as? com.google.android.material.textfield
                            .TextInputLayout ?: continue
                    val num = numLayout.editText?.text?.toString()
                        ?.trim().orEmpty()
                    val nm = nameLayout.editText?.text?.toString()
                        ?.trim().orEmpty()
                    if (num.isEmpty() || nm.isEmpty()) continue
                    if (newNames.containsKey(num)) {
                        duplicate = true
                        continue
                    }
                    newNames[num] = nm
                }
                if (duplicate) {
                    Toast.makeText(
                        requireContext(),
                        R.string.caller_names_duplicate,
                        Toast.LENGTH_LONG
                    ).show()
                    view?.announceCompat(
                        getString(R.string.caller_names_duplicate)
                    )
                }
                runCatching { settings.setCustomCallerNames(newNames) }
                if (!duplicate) {
                    Toast.makeText(
                        requireContext(),
                        R.string.caller_names_saved,
                        Toast.LENGTH_SHORT
                    ).show()
                    view?.announceCompat(
                        getString(R.string.caller_names_saved)
                    )
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .create().also(::trackDialog).show()
    }

    /** توسيع/طي قسم قابل للطي، ويُحدّث السهم (▼/▲) ووصف الأب بحالة الطي.
 *  internal لأن ضابط البطارية يستخدمه للعنوان القابل للطي. */
    internal fun toggleCollapsible(
        content: View,
        arrow: TextView,
        header: View
    ) {
        val collapsed =
            content.visibility == View.GONE ||
                content.visibility == View.INVISIBLE
        val willExpand = collapsed
        content.visibility = if (willExpand) View.VISIBLE else View.GONE
        // سهم متجهي يلون بلون النص (مطوّي → للأسفل، موسّع → للأعلى)
        arrow.text = ""
        val res = if (willExpand) R.drawable.ic_expand_less
        else R.drawable.ic_expand_more
        val icon = androidx.core.content.ContextCompat.getDrawable(
            requireContext(), res
        )?.apply { setTint(arrow.currentTextColor) }
        arrow.setCompoundDrawablesRelativeWithIntrinsicBounds(
            null, null, icon, null
        )
        // يقرأ قارئ الشاشة نصاً واحداً: العنوان الأساسي + حالة (موسّع/مطوي)
        val stateLabel =
            if (willExpand) getString(R.string.collapse)
            else getString(R.string.expand)
        val base = header.getTag() as? String
        if (base != null) {
            header.contentDescription = base + " — " + stateLabel
        } else {
            header.contentDescription = stateLabel
        }
    }

    private fun showDictRowOptions(entry: Pair<String, String>) {
        val options = arrayOf(
            getString(R.string.dict_edit_entry),
            getString(R.string.dict_delete_entry)
        )
        MaterialAlertDialogBuilder(requireContext())
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showDictEditDialog(entry)
                    1 -> {
                        runCatching {
                            pronunciationDict.removeEntry(entry.first)
                        }
                        // إعلان مسموع بنتيجة الحذف لتوفير تغذية راجعة لقارئ
                        // الشاشة
                        announcementSpeaker?.speak(
                            getString(R.string.dict_removed),
                            if (com.aymankhattab.nateq.util.LocaleUtils
                                    .containsArabic(entry.second)
                            ) {
                                Locale.forLanguageTag(LanguageCode.AR.tag)
                            } else {
                                Locale.forLanguageTag(LanguageCode.EN.tag)
                            },
                            1.0f, 1.0f, 1.0f
                        )
                        refreshDictAdapter()
                    }
                }
            }
            .create().also(::trackDialog).show()
    }

    /** إيقاف النطق الجاري للمتحدث الخاص بمعاينات الأقسام (يُستخدمه ضابط
     *  صحة الجهاز وزر إيقاف معاينة الأرقام). */
    internal fun stopPreviewSpeech() {
        announcementSpeaker?.stop()
    }

    internal fun speakWithVoice(languageTag: String, text: String) {
        // نستخدم نفس مسار الإعلانات الصوتية التلقائية (AnnouncementSpeaker)
        // الذي يربط المحرك المختار فعليا عبر setEngineByPackageName —
        // لا نعتمد على المحرك الافتراضي للنظام حتى لا يكون "نحن" أنفسنا.
        val speaker = announcementSpeaker
            ?: AnnouncementSpeaker(requireContext())
                .also { announcementSpeaker = it }
        speaker.speak(
            text,
            Locale.forLanguageTag(languageTag),
            runCatching { settings.getSpeechRate(languageTag) }
                .getOrDefault(1.0f),
            1.0f,
            1.0f,
        )
    }

    /** معاينة صوت زر فئة (بند 4.3): تحسم محرك الفئة المخصص وسرعتها
     *  فيُسمع الصوت كما سيُعلن فعلاً في تلك الفئة (لا الصوت العام). */
    internal fun speakWithCategory(
        category: String,
        languageTag: String,
        text: String
    ) {
        val speaker = announcementSpeaker
            ?: AnnouncementSpeaker(requireContext())
                .also { announcementSpeaker = it }
        val engine = runCatching {
            settings.getEngineForCategory(category)
        }.getOrNull()
        val rate = runCatching {
            settings.getSpeechRateForCategory(category)
        }.getOrDefault(1.0f)
        // يُحترم صوت الفئة المحفوظ (قد يكون من محرك خارجي) فيُمرَّر
        // name المطابق إلى voiceId — resetVoice قصير الدارة بلا
        // إعادة تهيئة غير ضرورية.
        runCatching {
            settings.getPreferredVoiceIdForCategory(category)
        }.getOrNull()?.let { speaker.resetVoice(it) }
        speaker.speak(
            text,
            Locale.forLanguageTag(languageTag),
            rate,
            1.0f,
            1.0f,
            engineOverride = engine
        )
    }

    /**
     * يعرض معاينة نطق عبر المساعد المشترك ويُعلن بدايتها ونهايتها لقارئ
     * الشاشة (بند الأوامر 4) — يُستدعى من أزرار المعاينة في الأقسام.
     */
    internal fun previewSpeech(params: PreviewParams) {
        val startMsg = getString(R.string.sample_preview_starting)
        view?.announceCompat(startMsg)
        voicePreview.play(params) {
            runCatching {
                if (isAdded) {
                    view?.announceCompat(
                        getString(R.string.sample_preview_done)
                    )
                }
            }
        }
    }

    // ===== تبديل لغة التطبيق (أسفل الشاشة) =====
    private fun setupLanguageToggle() {
        val current = runCatching { settings.getAppLanguage() }
            .getOrNull()
            ?: Locale.getDefault().language

        val isArabic = LanguageCode.isArabic(current)
        // يعرض اللغة الحالية ثم الإجراء نحو اللغة الأخرى
        btnToggleLanguage.text = if (isArabic) {
            getString(R.string.language_current_label) + " " +
                getString(R.string.language_arabic) + " — " +
                getString(R.string.language_change_to_en)
        } else {
            getString(R.string.language_current_label) + " " +
                getString(R.string.language_english) + " — " +
                getString(R.string.language_change_to_ar)
        }

        btnToggleLanguage.setOnClickListener {
            val newLang =
            if (isArabic) LanguageCode.EN.tag else LanguageCode.AR.tag
            runCatching { settings.setAppLanguage(newLang) }
            // تطبيق اللغة على مستوى التطبيق (AppCompatDelegate) قبل إعادة
            // إنشاء النشاط حتى تُنشأ موارد النشاط الجديد باللغة الجديدة
            // فعلياً.
            runCatching {
                AppCompatDelegate.setApplicationLocales(
                    androidx.core.os.LocaleListCompat.forLanguageTags(newLang)
                )
            }
            // بند 4.12: تحديث أداة الساعة بلغة الواجهة الجديدة فوراً —
            // الودجت updatePeriodMillis="0" ولا يُحدَّث لوحده.
            // إعادة إنشاء النشاط لتطبيق اللغة فورياً (UI + افتراضيات)
            requireActivity().recreate()
        }
    }

    // ===== زر التواصل مع المطوّر =====
    private fun openDeveloperSupport() {
        runCatching {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    android.net.Uri.parse(DEVELOPER_SUPPORT_URL)
                )
            )
        }.onFailure {
            Toast.makeText(
                requireContext(),
                R.string.contact_developer_no_handler,
                Toast.LENGTH_SHORT
            ).show()
            view?.announceCompat(
                getString(R.string.contact_developer_no_handler)
            )
        }
    }

    // ===== جمع سطور الأخطاء من سجل التطبيق ومشاركتها مع المطور =====
    private fun onReportErrorClicked() {
        if (DiagnosticLogRecorder.isRecording()) {
            finishErrorReportCollection()
        } else {
            startErrorReportCollection()
        }
    }

    private fun syncReportErrorButtonText() {
        btnReportError?.text = getString(
            if (DiagnosticLogRecorder.isRecording()) {
                R.string.report_error_finish
            } else {
                R.string.report_error
            }
        )
    }

    /** الضغطة الأولى: إطلاق مراقبة السجل (يستمر عبر كل الشاشات حتى
     *  يضغط المستخدم «تم» بعد إعادة إنتاج المشكلة). */
    private fun startErrorReportCollection() {
        if (!DiagnosticLogRecorder.start()) return
        syncReportErrorButtonText()
        val msg = getString(R.string.report_error_started)
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        view?.announceCompat(msg)
    }

    /** الضغطة الثانية: إيقاف المراقبة وحصاد لقطة السجل الحية وبناء
     *  التقرير الكامل منها (يصرّف عبر الحارس لئلا يكتب كوروتينان
     *  نفس ملف الكاش). */
    private fun finishErrorReportCollection() {
        val captured = DiagnosticLogRecorder.stop()
        val currentContext = context ?: return
        // حارس منع التكرار: ضغطة «تم» المتتالية أثناء جمعٍ جارٍ تُرفض
        // حتى لا يتوازى كوروتينان على نفس ملف الكاش.
        if (!errorReportGate.tryBegin()) return
        Toast.makeText(
            currentContext,
            R.string.report_error_collecting,
            Toast.LENGTH_SHORT
        ).show()
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val report = runCatching {
                    buildErrorReport(currentContext, captured)
                }.getOrNull()
                if (!isAdded ||
                    activity == null ||
                    activity?.isFinishing == true
                ) {
                    return@launch
                }
                val ctx = context ?: return@launch
                if (report.isNullOrBlank()) {
                    Toast.makeText(
                        ctx,
                        R.string.report_error_empty,
                        Toast.LENGTH_SHORT
                    ).show()
                    view?.announceCompat(
                        getString(R.string.report_error_empty)
                    )
                    return@launch
                }
                val logFile = writeLogToCacheFile(ctx, report)
                showErrorReportDialog(ctx, report, logFile)
            } finally {
                // يُفتح الباب مجدداً بعد اكتمال/فشل/إلغاء رحلة الجمع (ينفذ
                // هذا الحظر حتى عند إلغاء النطاق أو الإرجاع المبكر أعلاه).
                errorReportGate.finish()
                if (isAdded) {
                    syncReportErrorButtonText()
                }
            }
        }
    }

    /**
     * يبني تقريراً شاملاً يجمع بين معلومات التشخيص وحالة المحركات والأجهزة
     * وأحدث سطور logcat لعملية التطبيق (أخطاء وتحذيرات ونشاط حديث).
     */
    private suspend fun buildErrorReport(
        context: android.content.Context,
        capturedLines: List<String>
    ): String =
        kotlinx.coroutines.withContext(AppDispatchers.io) {
            val diagnostics = buildDiagnosticsInfo(context)
            val logLines = capturedLines.toMutableList()
            if (logLines.isEmpty()) {
                // احتياط: لم تطلق المراقبة الحية أسطراً — سحب لحظة
                // مباشر لأحدث 600 سطر (السلوك السابق).
                try {
                    val process = Runtime.getRuntime().exec(
                        arrayOf(
                            "logcat", "-d",
                            "-t", "600",
                            "--pid", android.os.Process.myPid().toString()
                        )
                    )
                    process.inputStream.bufferedReader().useLines { lines ->
                        for (line in lines) {
                            logLines.add(line)
                        }
                    }
                    process.waitFor()
                } catch (e: Exception) {
                    android.util.Log.e(
                        "NATEQ_APP", "logcat collect failed", e
                    )
                }
            }

            buildString {
                appendLine(
                    context.getString(R.string.error_report_header_title)
                )
                appendLine(
                    context.getString(
                        R.string.error_report_time,
                        java.text.SimpleDateFormat(
                            "yyyy-MM-dd HH:mm:ss", java.util.Locale.US
                        ).format(java.util.Date())
                    )
                )
                appendLine("==========================================")
                appendLine("")
                appendLine(diagnostics)
                appendLine("")
                appendLine("==========================================")
                appendLine("=== أحدث أسطر السجل التقني (Logcat) ===")
                if (logLines.isEmpty()) {
                    appendLine("(لم يُسجَّل نشاط في logcat للعملية الحالية)")
                } else {
                    // **بصمةُ التطبيق أولاً:** أسطرُه التشخيصية هي كل ما
                    // يهمّ التشخيص، وقد تغرق في ضجيج النظام ضمن آلاف
                    // الأسطر. تُوضع في المقدمة فلا يحتاج القارئ أن يبحث عنها.
                    val diagnostic = logLines.filter {
                        DiagnosticLogRecorder.isDiagnosticLine(it)
                    }
                    if (diagnostic.isNotEmpty()) {
                        appendLine(
                            "--- أسطر Lord TTS التشخيصية" +
                                " (${diagnostic.size}) ---"
                        )
                        diagnostic.takeLast(MAX_DIAGNOSTIC_LINES)
                            .forEach { appendLine(it) }
                        appendLine("")
                    }
                    val errors = logLines.filter {
                        val level = DiagnosticLogRecorder.severityOf(it)
                        level == 'E' || level == 'F'
                    }
                    val warnings = logLines.filter {
                        DiagnosticLogRecorder.severityOf(it) == 'W'
                    }
                    if (errors.isNotEmpty()) {
                        appendLine(
                            "--- أسطر الأخطاء الحرجة (${errors.size}) ---"
                        )
                        errors.takeLast(300).forEach { appendLine(it) }
                        appendLine("")
                    }
                    if (warnings.isNotEmpty()) {
                        appendLine(
                            "--- أسطر التحذيرات (${warnings.size}) ---"
                        )
                        warnings.takeLast(200).forEach { appendLine(it) }
                        appendLine("")
                    }
                    // **كان `takeLast(150)`** يطبع التقرير آخر 150 سطراً فقط
                    // مهما بلغ ما التقطه الجامع (20 ألف سطر)، فتضيع
                    // الأسطرُ المفيدة وسط الصمت. الآن يُطبع المخزنُ كلُّه
                    // وقد حُدَّت سعته بسقفٍ آمن في ذاكرة الجهاز.
                    appendLine(
                        "--- سجل نشاط التطبيق (${logLines.size} سطر) ---"
                    )
                    logLines.forEach { appendLine(it) }
                }
            }
        }

    private fun writeLogToCacheFile(
        context: android.content.Context,
        content: String
    ): File? =
        runCatching {
            val logsDir = File(context.cacheDir, "logs").apply { mkdirs() }
            val logFile = File(logsDir, "nateq_diagnostic_log.txt")
            logFile.writeText(content, Charsets.UTF_8)
            logFile
        }.getOrNull()

    private fun showErrorReportDialog(
        context: android.content.Context,
        reportText: String,
        logFile: File?
    ) {
        val dialog = MaterialAlertDialogBuilder(context)
            .setTitle(R.string.error_report_dialog_title)
            .setMessage(R.string.error_report_dialog_message)
            .setPositiveButton(R.string.error_report_send_telegram) { _, _ ->
                sendReportToTelegram(context, reportText)
            }
            .setNeutralButton(R.string.error_report_share_file) { _, _ ->
                shareErrorReport(context, reportText, logFile)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
            .also(::trackDialog)
        dialog.show()
        view?.announceCompat(getString(R.string.error_report_dialog_title))
    }

    private fun sendReportToTelegram(
        context: android.content.Context,
        reportText: String
    ) {
        copyToClipboard(reportText)
        Toast.makeText(
            context,
            R.string.error_report_copied_telegram_hint,
            Toast.LENGTH_LONG
        ).show()
        view?.announceCompat(
            getString(R.string.error_report_copied_telegram_hint)
        )
        openDeveloperSupport()
    }

    /** يفتح وسائل المشاركة (اقتراح نصوص، بريد…) بالمحتوى المجمّع. */
    private fun shareErrorReport(
        context: android.content.Context,
        body: String,
        logFile: File?
    ) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_SUBJECT, getString(R.string.report_error_subject)
            )
            putExtra(Intent.EXTRA_TEXT, body)
            if (logFile != null && logFile.exists()) {
                val uri = runCatching {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        logFile
                    )
                }.getOrNull()
                if (uri != null) {
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
        }
        val chooser = Intent.createChooser(
            send, getString(R.string.report_error)
        )
        runCatching {
            startActivity(chooser)
        }.onFailure {
            Toast.makeText(
                context, R.string.report_error_no_handler, Toast.LENGTH_SHORT
            ).show()
            view?.announceCompat(getString(R.string.report_error_no_handler))
        }
    }

    // ===== آخر التحديثات =====
    private fun showChangelogDialog() {
        val versionName = runCatching {
            requireContext().packageManager.getPackageInfo(
                requireContext().packageName, 0
            ).versionName
        }.getOrNull() ?: "?"
        val body = getString(R.string.changelog_text, versionName)
        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.changelog_title)
            .setMessage(body)
            .setPositiveButton(android.R.string.ok, null)
            .create()
            .also(::trackDialog)
        dialog.show()
        view?.announceCompat(getString(R.string.changelog_title))
    }

    // ===== التشخيص =====
    private fun showDiagnosticsDialog() {
        val currentContext = context ?: return
        viewLifecycleOwner.lifecycleScope.launch {
            val info = buildDiagnosticsInfo(currentContext)
            if (!isAdded || activity == null || activity?.isFinishing == true) {
                return@launch
            }
            val ctx = context ?: return@launch
            val dialog = MaterialAlertDialogBuilder(ctx)
                .setTitle(R.string.diagnostics_title)
                .setMessage(info)
                .setPositiveButton(R.string.diagnostics_copy) { _, _ ->
                    copyToClipboard(info)
                    Toast.makeText(
                        ctx, R.string.diagnostics_copied,
                        Toast.LENGTH_SHORT
                    ).show()
                    view?.announceCompat(
                        getString(R.string.diagnostics_copied)
                    )
                }
                .setNegativeButton(android.R.string.cancel, null)
                .create()
                .also(::trackDialog)
            dialog.show()
            view?.announceCompat(getString(R.string.diagnostics_title))
        }
    }

    /**
     * يبني نص التشخيص الشامل — يعمل على خيط IO لأنه يستدعي بعض
     * واجهات النظام (مثل getInstalledEngines) ويمكن أن يبطئ الواجهة.
     *
     * الأقسام المُغطاة (بحسب بند د.6.2 + بند د.1 + بند د.2):
     * - إصدار التطبيق والجهاز
     * - محركات TTS المثبَّتة
     * - المحرك/الصوت المختار لكل فئة (مع سرعة/نبرة/مستوى)
     * - آخر فشل تراجع (يُعرض إن أمكن)
     * - حالة الأذونات الحرجة
     * - تصنيف OEM
     * - سجل تركيز الصوت (إرشاد جمع Logcat — بند د.1)
     * - حالة إعلان المتصل (إرشاد اختبار — بند د.2)
     */
    private suspend fun buildDiagnosticsInfo(
        context: android.content.Context
    ): String =
        kotlinx.coroutines.withContext(AppDispatchers.io) {
            val sb = StringBuilder()
            val info = context.packageManager.getPackageInfo(
                context.packageName, 0
            )
            val versionName = info.versionName ?: "?"
            val versionCode = if (
                android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.P
            ) {
                info.longVersionCode
            } else {
                @Suppress("DEPRECATION") info.versionCode.toLong()
            }

            sb.appendLine("=== Lord TTS — التشخيص ===")
            sb.appendLine(
                getString(
                    R.string.error_report_version,
                    versionName,
                    versionCode
                )
            )
            sb.appendLine(
                getString(
                    R.string.error_report_device,
                    android.os.Build.MANUFACTURER,
                    android.os.Build.MODEL
                )
            )
            sb.appendLine(
                getString(
                    R.string.error_report_android_os,
                    android.os.Build.VERSION.RELEASE,
                    android.os.Build.VERSION.SDK_INT
                )
            )
            sb.appendLine("")

            // ── محركات TTS المثبَّتة ──────────────────────────────────
            sb.appendLine("--- محركات TTS المثبَّتة ---")
            val engines = EnginePicker.installedEngines(context)
            if (engines.isEmpty()) {
                sb.appendLine("• لم يُعثر على محركات TTS")
            } else {
                engines.forEach { engine: InstalledEngine ->
                    val rms = runCatching {
                        settings.getEngineRmsCalibration(
                            engine.packageName
                        )
                    }.getOrNull()
                    val rmsText = when {
                        rms != null -> "RMS=${"%.3f".format(rms)}"
                        else -> "RMS=غير معايَر"
                    }
                    sb.appendLine(
                        "• ${engine.label} " +
                            "(${engine.packageName})  $rmsText"
                    )
                }
            }
            sb.appendLine("")

            // ── المحرك/الصوت المختار لكل فئة ─────────────────────────
            sb.appendLine("--- الاختيار النشط لكل فئة ---")
            val categories = listOf(
                "time" to "إعلان الوقت",
                "battery" to "إعلان البطارية",
                "notifications" to "قراءة الإشعارات",
                "caller" to "إعلان المتصل",
                "sms" to "قراءة الرسائل",
                "numbers" to "الأرقام",
                "default" to "الافتراضي",
                "emoji" to "الإيموجي"
            )
            categories.forEach { (key, label) ->
                val engine = runCatching {
                    settings.getEngineForCategory(key)
                }.getOrNull()
                val voice = runCatching {
                    settings.getPreferredVoiceIdForCategory(key)
                }.getOrNull()
                val rate = runCatching {
                    settings.getSpeechRateForCategory(key)
                }.getOrNull()
                val pitch = runCatching {
                    settings.getPitchForCategory(key)
                }.getOrNull()
                sb.appendLine(
                    "$label: " +
                        "محرك=${engine ?: "افتراضي"}  " +
                        "صوت=${voice ?: "افتراضي"}  " +
                        "سرعة=${"%.1f".format(rate ?: 1f)}  " +
                        "نبرة=${"%.1f".format(pitch ?: 1f)}"
                )
            }
            // فاصل إعلان الوقت واللغة الثانية
            val interval = runCatching {
                settings.getTimeAnnouncementInterval()
            }.getOrNull()
            val secondLang = runCatching {
                settings.getSecondaryLanguage()
            }.getOrNull()
            if (interval != null) {
                sb.appendLine("فاصل إعلان الوقت: $interval دقيقة")
            }
            if (secondLang != null) {
                sb.appendLine("اللغة الثانية: $secondLang")
            }
            sb.appendLine("")

            // ── آخر فشل تراجع ────────────────────────────────────────
            sb.appendLine("--- آخر فشل تراجع ---")
            // قيمة مُقرأة من SharedPreferences إن سُجّل سابقاً
            val lastFallback = runCatching {
                settings.getLastFallbackFailureInfo()
            }.getOrNull()
            if (lastFallback.isNullOrBlank()) {
                sb.appendLine("لا يوجد فشل تراجع مُسجَّل")
            } else {
                sb.appendLine(lastFallback)
            }
            sb.appendLine("")

            // ── حالة الأذونات ─────────────────────────────────────────
            sb.appendLine("--- حالة الأذونات ---")
            val am =
                context.getSystemService(
                    android.app.AlarmManager::class.java
                )
            val exactAlarm = if (
                android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.S
            ) {
                am.canScheduleExactAlarms()
            } else {
                true
            }
            sb.appendLine(
                "التنبيهات الدقيقة: " +
                    if (exactAlarm) "مُمنوح ✓" else "محجوب ✗"
            )

            val nm =
                context.getSystemService(
                    android.app.NotificationManager::class.java
                )
            val notificationListener = try {
                val enabled =
                    android.provider.Settings
                        .Secure.getString(
                            context.contentResolver,
                            "enabled_notification_listeners"
                        ) ?: ""
                enabled.contains(context.packageName)
            } catch (e: Exception) {
                false
            }
            sb.appendLine(
                "الوصول للإشعارات: " +
                    if (notificationListener) "مُمنوح ✓" else "محجوب ✗"
            )

            val powerManager =
                context.getSystemService(
                    android.os.PowerManager::class.java
                )
            val isIgnoring = if (
                android.os.Build.VERSION.SDK_INT >=
                android.os.Build.VERSION_CODES.M
            ) {
                powerManager.isIgnoringBatteryOptimizations(
                    context.packageName
                )
            } else {
                true
            }
            sb.appendLine(
                "الإعفاء من تحسين البطارية: " +
                    if (isIgnoring) "مُمنوح ✓" else "محجوب ✗"
            )

            // فحص READ_PHONE_STATE (لإعلان المتصل)
            val phoneState = context.checkSelfPermission(
                android.Manifest.permission.READ_PHONE_STATE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            sb.appendLine(
                "READ_PHONE_STATE (المتصل): " +
                    if (phoneState) "مُمنوح ✓" else "محجوب ✗"
            )

            val oemVendor =
                OemVendor.detect(android.os.Build.MANUFACTURER)
            sb.appendLine("تصنيف OEM: $oemVendor")
            sb.appendLine("")

            // ── سجل تركيز الصوت (بند د.1) ────────────────────────────
            sb.appendLine("--- سجل تركيز الصوت (بند د.1) ---")
            sb.appendLine(
                "عند حدوث انخفاض مفاجئ في الصوت، أرسل Logcat بتصفية:"
            )
            sb.appendLine("  adb logcat -s NATEQ_TTS:V *:S")
            sb.appendLine(
                "أو استخدم زر «إعادة ضبط تركيز الصوت» في هذه الشاشة"
            )
            sb.appendLine("")

            // ── حالة اختبار إعلان المتصل (بند د.2) ───────────────────
            sb.appendLine("--- إعلان المتصل (بند د.2) ---")
            sb.appendLine(
                "READ_PHONE_STATE: " +
                    if (phoneState) "مُمنوح ✓" else "محجوب ✗"
            )
            sb.appendLine(
                "تصنيف OEM: $oemVendor " +
                    if (oemVendor.name != "GENERIC") {
                        "← قد يحتاج «التشغيل التلقائي» مفعَّلاً"
                    } else {
                        ""
                    }
            )
            sb.appendLine(
                "لاختبار مسار النطق مباشرةً: " +
                    "استخدم «اختبر إعلان المتصل» في قسم إعلان المتصل"
            )

            sb.toString()
        }

    private fun copyToClipboard(text: String) {
        val clipboard = requireContext().getSystemService(
            android.content.Context.CLIPBOARD_SERVICE
        ) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText(
            "Lord TTS Diagnostics", text
        )
        clipboard.setPrimaryClip(clip)
    }

    // ===== البحث عن تحديثات =====
    private fun setupCheckUpdates() {
        val btn = view?.findViewById<View>(R.id.btn_check_updates) ?: return
        btn.setOnClickListener { onCheckUpdatesClicked() }
    }

    /** فحص تلقائي عند بدء الشاشة (صامت عند عدم وجود تحديث). */
    internal fun checkForUpdatesOnStart() {
        performUpdateCheck(showFeedback = false)
    }

    /** فحص عند ضغط زر «البحث عن تحديثات» (مع رسائل واضحة). */
    private fun onCheckUpdatesClicked() {
        performUpdateCheck(showFeedback = true)
    }

    /** منطق الفحص المشترك: إن وُجد تحديث يعرض حوار «نعم/لا» قبل التنزيل. */
    private fun performUpdateCheck(showFeedback: Boolean) {
        val context = requireContext()
        val currentName = runCatching {
            val info = context.packageManager.getPackageInfo(
                context.packageName, 0
            )
            info.versionName
        }.getOrNull() ?: ""

        if (showFeedback) {
            Toast.makeText(
                context, getString(R.string.check_updates), Toast.LENGTH_SHORT
            ).show()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            val pat = settings.getGitHubUpdatePat()
            // الفحص التلقائي يفضّل الكاش (لا يضغط GitHub عند كل فتح شاشة)؛
            // الفحص اليدوي يلتفّ عليه دائماً ليُجيب فوراً عن «هل من جديد؟».
            when (
                val res = UpdateChecker.check(
                    currentName, preferCache = !showFeedback, githubPat = pat
                )
            ) {
                is UpdateChecker.CheckResult.UpdateAvailable -> {
                    promptDownloadUpdate(
                        context, res.apkUrl, res.expectedSha256Hex
                    )
                }
                is UpdateChecker.CheckResult.UpToDate -> {
                    if (showFeedback) {
                        Toast.makeText(
                            context,
                            getString(R.string.check_updates_up_to_date),
                            Toast.LENGTH_SHORT
                        ).show()
                        view?.announceCompat(
                            getString(R.string.check_updates_up_to_date)
                        )
                    }
                }
                is UpdateChecker.CheckResult.NetworkError -> {
                    if (showFeedback) {
                        Toast.makeText(
                            context,
                            getString(R.string.check_updates_network_error),
                            Toast.LENGTH_SHORT
                        ).show()
                        view?.announceCompat(
                            getString(R.string.check_updates_network_error)
                        )
                    }
                }
            }
        }
    }

    /** حوار تأكيد قبل التنزيل: يسأل المستخدم إن كان يريد تنزيل التحديث
     *  (نعم/لا). على الشبكات المدفوعة يُحذَّر أن التنزيل سيستهلك بياناته،
     *  وموافقته عليه صراحةً تسمح بالتنزيل فوقها. */
    private fun promptDownloadUpdate(
        context: android.content.Context,
        apkUrl: String,
        expectedSha256Hex: String?
    ) {
        val base = getString(R.string.check_updates_confirm_message)
        // إن لم يوفّر الناشر بصمة SHA-256 (غياب digest) يُحذَّر المستخدم
        // بصراحة قبل التثبيت بلا تحقق (القرار يبقى له).
        val warnings = buildList {
            if (expectedSha256Hex == null) {
                add(getString(R.string.check_updates_no_digest_warning))
            }
            if (NetworkMetering.isMetered(requireContext())) {
                add(getString(R.string.check_updates_metered_warning))
            }
        }
        val message = if (warnings.isEmpty()) base
        else base + "\n" + warnings.joinToString("\n")
        MaterialAlertDialogBuilder(context)
            .setTitle(R.string.check_updates_confirm_title)
            .setMessage(message)
            .setPositiveButton(R.string.check_updates_confirm_yes) { _, _ ->
                startApkDownload(
                    context,
                    apkUrl,
                    expectedSha256Hex,
                    allowMetered = NetworkMetering.isMetered(context)
                )
            }
            .setNegativeButton(R.string.check_updates_confirm_no, null)
            .create().also(::trackDialog).show()
    }

    /** ينزّل الـ APK ويعرض إشعاراً بأن التنزيل بدأ — يُستدعى بعد موافقة
     *  المستخدم. [expectedSha256Hex] (إن وُجدت) تُفحص قبل فتح شاشة
     *  التثبيت: بصمة متوقعة محلّياً تساوي بصمة التنزيل = نثبّت؛ غير ذلك
     *  يُحذف الملف ويُبلغ المستخدم. */
    private fun startApkDownload(
        context: android.content.Context,
        apkUrl: String,
        expectedSha256Hex: String?,
        allowMetered: Boolean
    ) {
        Toast.makeText(
            context,
            getString(R.string.check_updates_downloading_title),
            Toast.LENGTH_SHORT
        ).show()
        val downloadId = UpdateChecker.enqueueDownload(
            context, apkUrl, allowMetered
        )

        val appContext = context.applicationContext
        val fragmentRef = java.lang.ref.WeakReference(this)
        // مستمع مؤقت مشترك يفتح شاشة التثبيت عند اكتمال تنزيل الـ APK.
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(
                ctx: android.content.Context,
                intent: Intent
            ) {
                val id = intent.getLongExtra(
                    android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1L
                )
                if (id != downloadId) return
                try {
                    ctx.applicationContext.unregisterReceiver(this)
                    updateReceiver = null
                } catch (_: IllegalArgumentException) {
                    /* سبق تسجيله أو فُكّ */
                }
                // معالجة التنزيل والتحقق من سلامة البصمة على خيط خلفي
                // لمنع تجميد واجهة المستخدم (onReceive) أثناء قراءة الملف.
                Thread {
                    val result = UpdateChecker.processCompletedDownload(
                        ctx, id, expectedSha256Hex
                    )
                    Handler(Looper.getMainLooper()).post {
                        val frag = fragmentRef.get()
                        when (result) {
                            is UpdateChecker.DownloadResult.Success -> {
                                UpdateChecker.promptInstall(
                                    ctx, result.apkFile
                                )
                            }
                            is UpdateChecker.DownloadResult
                                .ChecksumMismatch -> {
                                val msg = ctx.getString(
                                    R.string.check_updates_checksum_failed
                                )
                                Toast.makeText(
                                    ctx,
                                    msg,
                                    Toast.LENGTH_LONG
                                ).show()
                                if (frag?.isAdded == true) {
                                    frag.view?.announceCompat(msg)
                                }
                            }
                            is UpdateChecker.DownloadResult.Failed -> {
                                val msg = ctx.getString(
                                    R.string.check_updates_download_failed
                                )
                                Toast.makeText(
                                    ctx,
                                    msg,
                                    Toast.LENGTH_LONG
                                ).show()
                                if (frag?.isAdded == true) {
                                    frag.view?.announceCompat(msg)
                                }
                            }
                        }
                    }
                }.start()
            }
        }
        ContextCompat.registerReceiver(
            appContext,
            receiver,
            android.content.IntentFilter(
                android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE
            ),
            // **بند 2.20 (اكتمال تنزيلات الصوت على Android 14+ — P0):**
            // بثُّ DownloadManager.ACTION_DOWNLOAD_COMPLETE بثٌّ نظاميٌّ من
            // «مديرِ التنزيلاتِ» (تطبيقُ نظامٍ بامتيازاتٍ رفيعةٍ) غيرُ محميٍّ؛
            // والمستقبِلُ غيرُ المُصدَّرِ (RECEIVER_NOT_EXPORTED) لا يستقبلُه
            // على Android 14+ فيفشلُ تحديثُ حالةِ التنزيلِ عندَ اكتمالِ صوتٍ؛
            // يُصدَّرُ المستقبِلُ هنا (RECEIVER_EXPORTED) فيتلقّى البثَّ
            // الوحيدَ الذي يهمُّه (محمياً بحراسةِ اتساقِ الحالةِ والوصولِ
            // الآمنِ) بلا مخاطرةِ واجهةٍ خارجيةٍ.
            ContextCompat.RECEIVER_EXPORTED
        )
        updateReceiver = receiver
    }

    // ===== زر الحفظ + زر استعادة الافتراضيات =====
    private fun setupSaveAndResetButtons() {
        val btnSave = view?.findViewById<View>(R.id.btn_save_settings)
        val btnReset = view?.findViewById<View>(R.id.btn_reset_settings)

        // الحفظ: الإعدادات تُخزَّن فورياً عند كل تغيير عبر setters، لكن نقدم
        // للمستخدم تأكيداً واضحاً بأن إعداداته مأخوذة في مكانها.
        btnSave?.setOnClickListener {
            Toast.makeText(
                requireContext(),
                getString(R.string.saved_successfully),
                Toast.LENGTH_SHORT
            ).show()
            view?.findViewById<View>(R.id.btn_save_settings)
                ?.announceCompat(getString(R.string.saved_successfully))
        }

        // استعادة الافتراضيات: مسح كل الإعدادات ثم إعادة بناء الواجهة لتحميل
        // القيم الافتراضية (بدون إعادة إنشاء الـ Activity).
        btnReset?.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.reset_confirm_title)
                .setMessage(R.string.reset_confirm_message)
                .setPositiveButton(R.string.reset_done) { _, _ ->
                    runCatching { settings.resetAllToDefault() }
                    // **بند 7.1:** حذف ملف القاموس وحده لا يُفرّغ خريطة
                    // الذاكرة في SettingsViewModel — فتبقى الكلمات القديمة
                    // تُقرأ من الخريطة وتُعاد كتابتها للملف عند أول إضافة.
                    runCatching { pronunciationDict.clear() }
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.reset_done),
                        Toast.LENGTH_SHORT
                    ).show()
                    view?.findViewById<View>(R.id.btn_reset_settings)
                        ?.announceCompat(getString(R.string.reset_done))
                    // التحديث الكلي للواجهة يتم تلقائياً عبر StateFlow
                    // المراجعة (notifySettingsChanged) — يستمع له الفصيل
                    // فيعيد بناء كل الأقسام من القيم الافتراضية دون تكرار
                    // كتلة setup() يدوية.
                    vm.notifySettingsChanged()
                }
                .setNegativeButton(R.string.reset_cancel, null)
                .create().also(::trackDialog).show()
        }
    }

    // ===== النسخ الاحتياطي / الاستعادة =====
    private fun setupBackupRestoreButtons() {
        view?.findViewById<View>(R.id.btn_backup_settings)
            ?.setOnClickListener {
            // تحذير صريح قبل التصدير: الملف نص صريح قد يحوي بيانات شخصية
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.backup_export_warning_title)
                .setMessage(R.string.backup_export_warning_message)
                .setPositiveButton(R.string.backup_settings) { _, _ ->
                    runCatching {
                        createBackupLauncher.launch("nateq_backup.json")
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .create().also(::trackDialog).show()
        }
        view?.findViewById<View>(R.id.btn_restore_settings)
            ?.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.restore_confirm_title)
                .setMessage(R.string.restore_confirm_message)
                .setPositiveButton(R.string.restore_settings) { _, _ ->
                    runCatching {
                        openRestoreLauncher.launch(
                            arrayOf(
                                "application/json",
                                "application/octet-stream"
                            )
                        )
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .create().also(::trackDialog).show()
        }
    }

    /** إعادة تحميل كل قيم الواجهة بعد الاستعادة (دون إعادة إنشاء النشاط). */
    private fun refreshAllSettingsUi() {
        val v = requireView()
        // **بند 6.4:** المفاتيح الرئيسية التي تُبنى في setup() خارج أقسام
        // الأكورديون لم تكن تُحدَّث عند الاستعادة — فيقع تناقض كلي بين
        // ما يُعرض والمخزّن. نُعيد تعبئتها من الإعدادات هنا.
        switchAllAnnouncements.isChecked =
            runCatching { settings.isAllAnnouncementsEnabled() }
                .getOrDefault(true)
        switchLockScreenPrivacy.isChecked =
            runCatching { settings.isLockScreenPrivacyEnabled() }
                .getOrDefault(true)
        v.findViewById<SwitchMaterial>(R.id.switch_emoji_reading)?.isChecked =
            runCatching { settings.isEmojiPronunciationEnabled() }
                .getOrDefault(true)
        timeSection.setup(v)
        batterySection.setup(v)
        notificationSection.setup(v)
        callerSection.setup(v)
        smsSection.setup(v)
        generalSection.setup(v)
        numberSection.setup(v)
        deviceHealthSection.setup(v)
        textReadingSection.setup(v)
        instantSilenceSection.setup(v)
        categoryVoicePanel.reloadCurrent()
        refreshDictAdapter()
        engineSection.setupAutoConvertUI(v)
        accordion.updateSectionStatuses()
    }

}
