package com.aymankhattab.nateq.core.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.aymankhattab.nateq.core.common.AppDispatchers
import com.aymankhattab.nateq.util.NateqJson
import com.aymankhattab.nateq.util.optArray
import com.aymankhattab.nateq.util.optMember
import com.aymankhattab.nateq.util.optObject
import com.aymankhattab.nateq.util.optString
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * فحص التحديثات وتنزيل الـ APK الجديد من GitHub Releases.
 * يستخدم مستودع المشروع العام كخادم توزيع.
 */
object UpdateChecker {

    private const val REPO = "aymankhattab41/Nateq"
    private const val RELEASES_API =
        "https://api.github.com/repos/$REPO/releases/latest"
    private const val APK_NAME = "nateq.apk"

    /** مدة بقاء نتيجة الفحص المخزَّنة قبل إعادة الاتصال (6 ساعات). */
    internal const val CACHE_TTL_MS = 6L * 60 * 60 * 1000

    /** عدد محاولات الفحص (أوليّ + إعادة على خطأ شبكة عابر). */
    private const val RETRY_ATTEMPTS = 2

    /** مهلة الانتظار قبل إعادة المحاولة بعد خطأ شبكة. */
    private const val RETRY_DELAY_MS = 1500L

    /** نتيجة فحص محفوظة — لا يُضغط واجهة GitHub إلا عند انقضاء المهلة. */
    private class CheckedAt(
        val timeMs: Long,
        val versionChecked: String,
        val result: CheckResult
    )

    @Volatile
    private var checkCache: CheckedAt? = null

    /** مصدر الزمن — حقنة اختبار لتقادم الكاش. */
    internal var nowProvider: () -> Long = { System.currentTimeMillis() }

    /** حفظ نتيجة للحصاد لاحقاً — خطأ الشبكة لا يُخزَّن (عرضي). */
    internal fun rememberCheck(
        result: CheckResult,
        versionChecked: String,
        now: Long
    ) {
        if (result is CheckResult.NetworkError) return
        checkCache = CheckedAt(now, versionChecked, result)
    }

    /** استرجاع نتيجة الفحص المخزَّنة ضمن [CACHE_TTL_MS] ولنفس النسخة، فقط
     *  للفحوص التلقائية ([preferCache]) — الفحص اليدوي يلتفّ عليه دائماً. */
    internal fun cachedCheck(
        versionChecked: String,
        now: Long,
        preferCache: Boolean
    ): CheckResult? = checkCache?.let { cached ->
        if (preferCache &&
            cached.versionChecked == versionChecked &&
            now - cached.timeMs < CACHE_TTL_MS
        ) {
            cached.result
        } else {
            null
        }
    }

    /** يجرد بادئة إصدار واحدة (v/V) إن وُجدت — لا حاجة إلا لها. */
    private fun stripVersionPrefix(value: String): String {
        val s = value.trim()
        return if (s.isNotEmpty() &&
            (s.first() == 'v' || s.first() == 'V')) {
            s.drop(1)
        } else {
            s
        }
    }

    /** مكوّنات نسخة كأرقام بعد نزع البادئة (غير الرقمية تتساقط). */
    private fun components(value: String): List<Int> =
        stripVersionPrefix(value).split('.').mapNotNull { it.toIntOrNull() }

    /** خلال مرحلة 0.x يُقصَد بالوسم الأحادي «v6» الإصدار «0.6.0» (الرقم هو
     *  الجزء الأوسط) — بلا هذه التسوية يُحسب «v6» أحدثَ من «0.6.0» خطأً
     *  رغم تطابقهما في الواقع. خارج مرحلة الصفر تبقى المقارنة SemVer قياسية. */
    private fun alignZeroRelease(
        remote: List<Int>, current: List<Int>
    ): Pair<List<Int>, List<Int>> = when {
        remote.size == 1 && current.size >= 2 && current[0] == 0 ->
            listOf(0, remote[0]) to current
        remote.size >= 2 && current.size == 1 && remote[0] == 0 ->
            remote to listOf(0, current[0])
        else -> remote to current
    }

    /** مقارنة SemVer لعنصري إصدار («v0.4.1»/«0.4.1») بلا البادئة: يرجع true
     *  إذا كان [remote] أحدث فعلاً من [current]. مكوّنٌ مكوّن بالأرقام مع
     *  تسوية مرحلة الصفر أعلاه، والجزء غير الرقمي في مكوّن يُتجاهل، والمكوّن
     *  المنقوص يُكمَّل بصفر. وسمٌ بلا أي رقم (مثل «latest») ليس تحديثاً أبداً.
     *  منطق نقي قابل للاختبار بلا أندرويد. */
    fun isNewerVersion(remote: String, current: String): Boolean {
        val (rParts, cParts) = alignZeroRelease(
            components(remote), components(current)
        )
        if (rParts.isEmpty()) return false
        val maxLen = maxOf(rParts.size, cParts.size)
        for (i in 0 until maxLen) {
            val r = rParts.getOrElse(i) { 0 }
            val c = cParts.getOrElse(i) { 0 }
            if (r > c) return true
            if (r < c) return false
        }
        return false
    }

    /** اختيار مرفق الـ APK من أصول الإصدار: يفضّل الاسم المتوقع
     *  ([APK_NAME]) ثم أي مرفق ينتهي بـ `.apk` — فنسخة قديمة مثبّتة تبحث
     *  عن اسمٍ قديم لا ترى مرفقاً باسم `nateq.apk` فتعلن «محدّثاً»
     *  وهمياً. تُعيد null إن لم يوجد أي مرفق APK. منطق نقي قابل للاختبار. */
    internal fun <T> pickApkAsset(
        assets: List<T>,
        nameOf: (T) -> String
    ): T? {
        val apkAssets = assets.filter {
            nameOf(it).endsWith(".apk", ignoreCase = true)
        }
        return apkAssets.minWithOrNull(
            compareBy { nameOf(it) != APK_NAME }
        )
    }

    sealed class CheckResult {
        data class UpdateAvailable(
            val tag: String,
            val apkUrl: String,
            /** بصمة SHA-256 سداسية (بلا «sha256:») للـ APK المنشور، إن وردت
             *  في `assets[].digest` من GitHub — تُفحص قبل التثبيت (بند الأمان
             *  المتوسط). null عندما لا يوفّر GitHub digest فيُترك التثبيت بلا
             *  تحقق (تُحمَّل الـ HTTPS من GitHub على كل حال). */
            val expectedSha256Hex: String? = null
        ) : CheckResult()
        object UpToDate : CheckResult()
        object NetworkError : CheckResult()
    }

    suspend fun check(
        currentVersionName: String,
        preferCache: Boolean = false,
        githubPat: String? = null
    ): CheckResult {
        val now = nowProvider()
        cachedCheck(currentVersionName, now, preferCache)?.let {
            return it
        }
        var result: CheckResult = CheckResult.NetworkError
        var attempt = 0
        while (attempt < RETRY_ATTEMPTS) {
            result = checkOnce(currentVersionName, githubPat)
            if (result !is CheckResult.NetworkError) break
            attempt++
            if (attempt < RETRY_ATTEMPTS) delay(RETRY_DELAY_MS)
        }
        rememberCheck(result, currentVersionName, nowProvider())
        return result
    }

    private suspend fun checkOnce(
        currentVersionName: String,
        githubPat: String? = null
    ): CheckResult =
        withContext(AppDispatchers.io) {
            try {
                val conn = URL(RELEASES_API)
                    .openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 10_000
                    conn.readTimeout = 10_000
                    // GitHub يرفض الطلبات المجهولة (403 بتقييد المعدل): ترويسات
                    // هوية واضحة + Accept للنسخة الثالثة
                    // الحالية من واجهة Releases.
                    conn.setRequestProperty(
                        "User-Agent",
                        "Nateq/UpdateChecker"
                    )
                    conn.setRequestProperty(
                        "Accept",
                        "application/vnd.github.v3+json"
                    )
                    // GitHub PAT للمستودع الخاص — يضيف Authorization header
                    githubPat?.let { pat ->
                        if (pat.isNotBlank()) {
                            conn.setRequestProperty("Authorization", "Bearer $pat")
                        }
                    }
                    if (conn.responseCode != 200) {
                        return@withContext CheckResult.NetworkError
                    }
                    val body = conn.inputStream.bufferedReader()
                        .use { it.readText() }
                    // تجزئة استجابة GitHub عبر مظلة JSON الموحّدة (البند 3):
                    // استجابة فاسدة/غير كائنية تُعامل كخطأ شبكة
                    // كما كان JSONObject سابقاً.
                    val root = NateqJson.parseObject(body)
                        ?: return@withContext CheckResult.NetworkError
                    val tag = root.optString("tag_name")
                    // مقارنة SemVer مكوّن مكوّن (لا قراءةٌ حرفية للرقم
                    // الأول كما
                    // كان takeWhile الأمعور — كان يعلّق «v0.4.1» على الرقم 0
                    // فيُعطَّل التنبيه لكل اللهجات SemVer).
                    if (!isNewerVersion(tag, currentVersionName)) {
                        return@withContext CheckResult.UpToDate
                    }
                    val assets = root.optArray("assets")
                    val apkAssets = (0 until (assets?.size() ?: 0))
                        .mapNotNull { assets?.get(it)?.optObject() }
                    // الاسم المتوقع أولاً ثم أي مرفق APK — حتى لا يضيع التحديث
                    // لو غُيّر اسم المرفق (نسخة سابقة باسمٍ قديم
                    // لا ترى `nateq.apk` فكانت تُعلن تحديثاً وهمياً).
                    val apkAsset = pickApkAsset(apkAssets) {
                        it.optString("name")
                    }
                    // إصدار أحدث لكن منشوره بلا أي مرفق APK على الإطلاق
                    // → لا شيء ننزله.
                    if (apkAsset == null) {
                        return@withContext CheckResult.UpToDate
                    }
                    val urlEl = apkAsset.optMember("browser_download_url")
                    if (urlEl == null) {
                        return@withContext CheckResult.NetworkError
                    }
                    // بصمة الـ APK من `digest` الخاص بأصل GitHub: تُسجَّل
                    // ليُتحققَ منها بعد التنزيل وقبل فتح شاشة التثبيت.
                    // **بند 7.3:** GitHub لا يزوّد `assets[].digest` للـ APK
                    // (ميزة محجوزة لحاويات Docker) فكانت القيمة null دائماً
                    // ويتجاوز الفحص؛ نُكمل من سطر «SHA-256: …» في ملاحظات
                    // الإصدار الذي يدرجه سكربت النشر، أو بصمة من ملف
                    // SHA256SUMS مرفقٍ بالإصدار إن وُجد في نص الملاحظات.
                    val digestFromAsset = apkAsset.optMember("digest")
                        ?.optString()
                        ?.takeIf { it.startsWith("sha256:") }
                        ?.removePrefix("sha256:")
                    val expectedSha = digestFromAsset
                        ?: extractSha256FromReleaseNote(
                            root.optString("body")
                        )
                    CheckResult.UpdateAvailable(
                        tag, urlEl.optString(), expectedSha
                    )
                } finally {
                    conn.disconnect()
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                CheckResult.NetworkError
            }
        }

    /** مسار مجلد التخزين المحلي للتنزيلات.
     *  يستخدم التخزين الخارجي المُخصَّص للتطبيق (getExternalFilesDir) لأن
     *  DownloadManager على أندرويد 10+ يرفض الوجهات داخل app_internal
     *  (SecurityException: Unsupported path) ويقبل فقط مسارات
     *  التخزين الخارجي. قد يُعيد getExternalFilesDir null (تخزين مشفَّر
     *  أو ممتلئ) — نتداركه بمسار داخلي بدل انهيار File(null, …). */
    private fun downloadsDir(context: Context): File {
        val base = context.getExternalFilesDir(null)
            ?: context.filesDir
        return File(base, "downloads").apply {
            mkdirs()
        }
    }

    /** مسار ملف الـ APK المُنزَل. */
    fun downloadedApk(context: Context): File =
        File(downloadsDir(context), APK_NAME)

    sealed class DownloadResult {
        data class Success(val apkFile: File) : DownloadResult()
        object ChecksumMismatch : DownloadResult()
        data class Failed(val status: Int, val reason: Int) : DownloadResult()
    }

    /**
     * يبدأ تنزيل الـ APK عبر DownloadManager ويُعيد معرّف التنزيل.
     * المستدعي يسجّل مستمع ACTION_DOWNLOAD_COMPLETE ويتفقّد الملف عند اكتماله.
     *
     * التفضيل الافتراضي Wi-Fi حصراً ([allowMetered]=false) يحفظ بيانات
     * المستخدم — يمر عبر [allowMetered]=true فقط حين يقر المستخدم صراحةً
     * وهو على شبكة هاتف مدفوعة؛ ولا يُسمح بالتجوال أبداً.
     */
    fun enqueueDownload(
        context: Context,
        apkUrl: String,
        allowMetered: Boolean = false
    ): Long {
        val manager = context.getSystemService(
            Context.DOWNLOAD_SERVICE
        ) as DownloadManager
        val request = DownloadManager.Request(Uri.parse(apkUrl))
            .setTitle("Lord TTS update")
            .setAllowedOverMetered(allowMetered)
            .setAllowedOverRoaming(false)

        val hiddenSet = runCatching {
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_HIDDEN
            )
        }.isSuccess
        if (!hiddenSet) {
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE
            )
        }

        val publicOk = runCatching {
            request.setDestinationInExternalPublicDir(
                android.os.Environment.DIRECTORY_DOWNLOADS,
                APK_NAME
            )
        }.isSuccess

        if (!publicOk) {
            val extFiles = context.getExternalFilesDir(null)
            if (extFiles != null) {
                val destination = File(downloadsDir(context), APK_NAME)
                if (destination.exists()) destination.delete()
                runCatching {
                    request.setDestinationUri(Uri.fromFile(destination))
                }
            }
        }

        return manager.enqueue(request)
    }

    /**
     * معالجة التنزيل المكتمل: الاستعلام من DownloadManager والتأكد من
     * نجاح الحالة ونسخ المحتوى والتحقق من SHA-256.
     */
    fun processCompletedDownload(
        context: Context,
        downloadId: Long,
        expectedSha256Hex: String?
    ): DownloadResult {
        val dm = context.getSystemService(
            Context.DOWNLOAD_SERVICE
        ) as? DownloadManager ?: return DownloadResult.Failed(-1, -1)

        val cursor = dm.query(
            DownloadManager.Query().setFilterById(downloadId)
        ) ?: return DownloadResult.Failed(-1, -1)

        var status = -1
        var reason = -1
        var localUriStr: String? = null
        cursor.use { c ->
            if (c.moveToFirst()) {
                val sIdx = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                if (sIdx >= 0) status = c.getInt(sIdx)
                val rIdx = c.getColumnIndex(DownloadManager.COLUMN_REASON)
                if (rIdx >= 0) reason = c.getInt(rIdx)
                val uIdx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
                if (uIdx >= 0) localUriStr = c.getString(uIdx)
            }
        }

        if (status != DownloadManager.STATUS_SUCCESSFUL) {
            return DownloadResult.Failed(status, reason)
        }

        val targetApk = downloadedApk(context)
        val srcFile = localUriStr?.let { Uri.parse(it) }?.let { uri ->
            if (uri.scheme == "file") uri.path?.let { File(it) } else null
        }
        val isSameFile = srcFile != null &&
            runCatching {
                srcFile.canonicalPath == targetApk.canonicalPath
            }.getOrDefault(false)

        if (!isSameFile) {
            if (targetApk.exists()) targetApk.delete()
            val copied = copyDownloadToFile(
                context, dm, downloadId, localUriStr, targetApk
            )
            if (!copied || !targetApk.isFile || targetApk.length() == 0L) {
                runCatching { dm.remove(downloadId) }
                return DownloadResult.Failed(status, reason)
            }
        } else {
            if (!targetApk.isFile || targetApk.length() == 0L) {
                runCatching { dm.remove(downloadId) }
                return DownloadResult.Failed(status, reason)
            }
        }

        val matches = expectedSha256Hex == null ||
            verifyApkSha256(targetApk, expectedSha256Hex)

        if (!matches) {
            targetApk.delete()
            runCatching { dm.remove(downloadId) }
            return DownloadResult.ChecksumMismatch
        }

        if (!isSameFile) {
            runCatching { dm.remove(downloadId) }
        }
        return DownloadResult.Success(targetApk)
    }

    private fun copyDownloadToFile(
        context: Context,
        dm: DownloadManager,
        downloadId: Long,
        localUriStr: String?,
        targetFile: File
    ): Boolean {
        // المحاولة 1: عبر openDownloadedFile المعتمدة رسمياً
        val pfdSuccess = runCatching {
            dm.openDownloadedFile(downloadId)?.use { pfd ->
                java.io.FileInputStream(pfd.fileDescriptor).use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                true
            }
        }.getOrNull() ?: false

        if (pfdSuccess && targetFile.length() > 0L) return true

        // المحاولة 2: عبر مسار ملف محلي من COLUMN_LOCAL_URI
        if (!localUriStr.isNullOrBlank()) {
            val fileSuccess = runCatching {
                val uri = Uri.parse(localUriStr)
                val srcFile = if (uri.scheme == "file") {
                    uri.path?.let { File(it) }
                } else null
                if (srcFile != null && srcFile.isFile &&
                    srcFile.length() > 0L
                ) {
                    srcFile.inputStream().use { input ->
                        targetFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    true
                } else false
            }.getOrNull() ?: false
            if (fileSuccess && targetFile.length() > 0L) return true
        }

        // المحاولة 3: عبر ContentResolver إن كان المسار content://
        if (!localUriStr.isNullOrBlank()) {
            val contentSuccess = runCatching {
                val uri = Uri.parse(localUriStr)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                    true
                } ?: false
            }.getOrNull() ?: false
            if (contentSuccess && targetFile.length() > 0L) return true
        }

        return false
    }

    /** فتح شاشة تثبيت النظام لملف APK محلي عبر FileProvider. */
    fun promptInstall(context: Context, apkFile: File): Boolean {
        if (!apkFile.exists() || apkFile.length() == 0L) return false
        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** يتحقق أن بصمة SHA-256 للـ APK المُنزَّل تطابق [expectedHex] المتوقعة
     *  (من `digest` في واجهة Releases). يعود false عند أي ملف مفقود/فارغ/
     *  غير مقروء أو تطابقٍ غير متحقق — والمقارنة سداسية ثابتة الزمن لمنع
     *  استنتاج أجزاء البصمة بالقياس. منطق نقي (لا أندرويد) قابل للاختبار. */
    fun verifyApkSha256(apkFile: File, expectedHex: String): Boolean {
        val expected = expectedHex.trim().lowercase()
        if (expected.isEmpty()) return false
        if (!apkFile.isFile || apkFile.length() == 0L) return false
        val actual = try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            apkFile.inputStream().use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var read = input.read(buffer)
                while (read >= 0) {
                    if (read > 0) digest.update(buffer, 0, read)
                    read = input.read(buffer)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            return false
        }
        return constantTimeEquals(actual, expected)
    }

    /** استخراج بصمة SHA-256 سداسية (64 حرفاً) من نص ملاحظات الإصدار —
     *  GitHub لا يوفر `assets[].digest` للـ APK (خاص بحاويات Docker)؛
     *  سكربت النشر يُدرج إما سطر «SHA-256: …» أو محتوى ملف SHA256SUMS
     *  (سطر يبدأ بالبصمة ثم اسم الملف): يُقبل النمطان معاً. تُعاد null
     *  عند غياب بصمة صالحة. منطق نقي. */
    internal fun extractSha256FromReleaseNote(text: String?): String? {
        if (text.isNullOrBlank()) return null
        // تُقبل البصمة فقط حين ترتبط صراحةً بالهدف (بند 3.9): إما سطر
        // «SHA-256: …» (أو «SHA-256=»)، وإما تنسيق SHA256SUMS
        // («البصمة  nateq.apk»). هكذا لا تُلتقط بصمةٌ عشوائية من
        // الملاحظات — كملف المصدر أو mapping — فتثبيت فاشل.
        val prefixed = Regex(
            "(?im)^[ \\t`]*SHA-?256[ \\t`]*[:=][ \\t`]*" +
                "([0-9a-f]{64})(?![0-9a-f])"
        ).find(text)
        prefixed?.let { return it.groupValues[1].lowercase() }
        val sums = Regex(
            "(?im)^[ \\t`]*([0-9a-f]{64})[` \\t]+nateq\\.apk"
        ).find(text)
        return sums?.groupValues?.get(1)?.lowercase()
    }

    /** مقارنة سداسية ثابتة الزمن (لا تقطع عند أول اختلاف). */
    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) {
            diff = diff or (a[i].code xor b[i].code)
        }
        return diff == 0
    }
}