package com.aymankhattab.nateq.engine

import android.content.Context
import com.aymankhattab.nateq.core.engine.PunctuationLevels
import com.aymankhattab.nateq.core.engine.SynthesisConfig
import com.aymankhattab.nateq.engine.pipeline.AcronymStep
import com.aymankhattab.nateq.engine.pipeline.ArabicSlashStep
import com.aymankhattab.nateq.engine.pipeline.CleanupStep
import com.aymankhattab.nateq.engine.pipeline.CurrencyStep
import com.aymankhattab.nateq.engine.pipeline.DateStep
import com.aymankhattab.nateq.engine.pipeline.DictionaryStep
import com.aymankhattab.nateq.engine.pipeline.EmojiStripStep
import com.aymankhattab.nateq.engine.pipeline.FrancoArabicStep
import com.aymankhattab.nateq.engine.pipeline.IndicDigitsStep
import com.aymankhattab.nateq.engine.pipeline.NumberStep
import com.aymankhattab.nateq.engine.pipeline.NumberWordsConverter
import com.aymankhattab.nateq.engine.pipeline.PhoneNumberStep
import com.aymankhattab.nateq.engine.pipeline.PunctuationStep
import com.aymankhattab.nateq.engine.pipeline.RomanNumeralStep
import com.aymankhattab.nateq.engine.pipeline.SymbolStep
import com.aymankhattab.nateq.engine.pipeline.TashkeelStripStep
import com.aymankhattab.nateq.engine.pipeline.TextProcessingStep
import com.aymankhattab.nateq.engine.pipeline.TimeStep
import com.aymankhattab.nateq.engine.pipeline.UnitStep
import com.aymankhattab.nateq.engine.pipeline.UrlStep
import com.aymankhattab.nateq.util.LanguageCode
import java.text.Normalizer
import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * محركات الـ TTS المعروفة بفهمها النطقي للتشكيل العربي (الحركات/الشدة/
 * التنوين): تُحتفظ لهذه الفئة بالتشكيل في الناتج النهائي (عبر مسار الاستعادة —
 * [TextProcessor.process]]) فلا تُنطق الحركاتُ حروفاً غريبة ولا يُجرد نصٌّ
 * يجيد المحركُ قراءته. الباقية (غير المعروفة) تُسلك السلوكَ القائم: تجريد.
 */
internal val ARABIC_TASHKEEL_AWARE_ENGINES: Set<String> = setOf(
    "com.google.android.tts"
)

/**
 * هل نجرد التشكيل العربي من النص قبل تسليمه للمحرك [enginePackage]؟
 * الإفتراض: نعم (تجريد — أغلب المحركات لا تنطق الحركات بوضوح). محركٌ معروف
 * بفهمه التشكيل (انظر [ARABIC_TASHKEEL_AWARE_ENGINES]) وnull (غير معروف)
 * يُعالَجان بحذر: المعروف يُبقي التشكيل، وغير المعروف يُجرد (سلوك سابق).
 */
internal fun stripTashkeelFor(enginePackage: String?): Boolean =
    enginePackage !in ARABIC_TASHKEEL_AWARE_ENGINES

/**
 * معالج النصوص الذكي — يحول النصوص الخام إلى نصوص قابلة للنطق طبيعياً.
 *
 * منسّق لخط معالجة نمطي [TextProcessingStep]: يمثل الترقيم/الترتيب الأصلي
 * للتحويلات (روابط، تواريخ، أوقات، عملات، وحدات، أرقام رومانية، هواتف،
 * رموز، أرقام) في خطوات منفصلة تسهل اختبارها وترتيبها، مع بقاء الواجهة
 * العامة متطابقة ([process] و [numberToWords]).
 */
class TextProcessor(
    private val context: Context,
    /** المرجع المحقون عبر Hilt إن وُجد (يمرره NateqTtsService)، وإلا يُبنى
     *  محلياً لإعدادات النطق. */
    private val injectedSettings: SynthesisConfig? = null,
    /** القاموس المحقون عبر Hilt إن وُجد (يمرره NateqTtsService). */
    private val injectedDict: PronunciationDictionary? = null
) {

    /**
     * **الافتراضيُّ هو [PronunciationDictionary.shared] لا `new`.**
     *
     * كان الغيابُ يُنتج `PronunciationDictionary(context)` — نسخةً جديدةً
     * **فارغة** لكل معالِج — فتنعدم القاموسُ في مسار النطق بينما يراه
     * المستخدمُ في الإعدادات. والمعالجُ الذي لا يحقن قاموساً (بناءُ
     * AnnouncementSpeaker هو المثال) كان يصيبُ العطبَ كلَّه. فصار
     * الافتراضيُّ نفسَ الكائن، وبقي [PronunciationDictionary] المباشرُ
     * للاختبارات التي تحتاج عزلةً.
     */
    private val pronunciationDict =
        injectedDict ?: PronunciationDictionary.shared(context)

    /**
     * هل نطق أسماء الإيموجي مفعّل؟ بلا حقنة Settings
     * (الاختبارات) يُفترض مفعّل.
     */
    private val emojiEnabled: Boolean
        get() = injectedSettings?.isEmojiPronunciationEnabled() ?: true


    /**
     * حفظ تشكيل الكلمات العربية المُرسلة للمحرك (بند 1.7): التجريد
     * الداخلي للمطابقة يبقى كما هو، لكن الكلمات الأصلية غير المتحوّلة
     * تُعاد بكلماتها المشكولة — فينطق المحركُ العربيُّ الفاهم للتشكيل
     * الحركاتَ بوضوح. بلا حقنة Settings يُفترض معطّل (السلوك القائم).
     */
    private val tashkeelPreserved: Boolean
        get() = injectedSettings?.isTashkeelPreserved() ?: false

    /** خطوة نطق علامات الترقيم — تتبع مستوى «البعض/الكل» قراءةً لحظية. */
    private val punctuationStep = PunctuationStep {
        injectedSettings?.getPunctuationLevel() ?: PunctuationLevels.SOME
    }

    /** خطوة نطق الأرقام — تتبع إعداد لغة ونمط نطق الأرقام لحظياً. */
    private val numberStep = NumberStep(
        languageProvider = { injectedSettings?.getNumberReadingLanguage() },
        modeProvider = { injectedSettings?.getNumberReadingMode() ?: 1 }
    )

    /** خطوة نطق أرقام الهواتف — تتبع إعداد لغة ونمط نطق الأرقام لحظياً. */
    private val phoneNumberStep = PhoneNumberStep(
        languageProvider = { injectedSettings?.getNumberReadingLanguage() },
        modeProvider = { injectedSettings?.getNumberReadingMode() ?: 1 }
    )

    // خطوات التمهيد: تُنفَّذ قبل بوابة المسار السريع
    // (تطبيع/تشكيل/إيموجي/قاموس).
    // «إزالة الإيموجي» شرطية: تعمل فقط عند تعطيل نطقها (إلا تُعيد النص كما هو).
    // «تصحيحُ ألف التنوين» (مساءاً ← مَسَاءَنْ) ليس هنا: مِلكُه
    // ArabicSpeechNormalizer في :core:audio، ويُطبَّق على النص المنطوق بعد
    // المعالجة مباشرةً، فهو مِلكٌ واحدٌ لتلك الصيغ لا تكرارٌ في خطٍّ آخر.
    private val preamble: List<TextProcessingStep> = listOf(
        IndicDigitsStep,
        FrancoArabicStep(),
        TashkeelStripStep,
        EmojiStripStep { emojiEnabled },
        DictionaryStep(pronunciationDict)
    )

    // الخطوات الدلالية المبكرة: تُطبَّق على النص الكامل قبل تقسيم اللغة
    // (عبر processSemantics) حتى لا ينفصل رمزُ العملة/الوحدة (حروف لاتينية
    // مثل «USD») إلى مقطعٍ إنجليزي مستقل — فينقطع «1500 USD» إلى مبلغٍ عربي
    // ورمزٍ إنجليزي. ثم يكررها المسار الثقيل على المقطع العربي (ناتجُها
    // كلماتٌ عربية بلا أرقام فلا يطابقها نمطٌ مجدداً — سلوك مطابق).
    // **بند 2.7:** تطبيع الأرقام الشرقية/الفارسية/الهندية أولُها: بدونها
    // كانت processSemantics تُشاهد «١٥٠٠ USD» بلا تطبيع فتنشطر للمقاطع،
    // وأنماط العملات/الوحدات/الأوقات لا تعترف بأرقامٍ شرقية (أنماطها \d
    // غربية) — الخطوة مطابقة للهوية بعد مسار التمهيد فلا ضرر من تكرارها.
    private val baseSteps: List<TextProcessingStep> = listOf(
        IndicDigitsStep,
        UrlStep,
        DateStep(),
        TimeStep,
        CurrencyStep,
        UnitStep,
        AcronymStep,
        ArabicSlashStep
    )

    // الخطوات الثقيلة (تنطبق فقط إن فشل المسار السريع) — ترتيبها مُطابق تماماً
    // لترتيب معالجة النص الأصلي: روابط → تواريخ → أوقات → عملات → وحدات →
    // رومانية → هواتف → رموز → ترقيم → أرقام. تُعالَج الروابط أولاً حمايةً لها
    // من أي تشويه تلحقه خطوة لاحقة (تاريخ/وقت/عملة داخل الرابط مثل
    // 2026-03-09)، ويأتي نطق الترقيم بعد الحماية فترى الروابط/التواريخ/
    // الهواتف منقّاةً ولا يمس أجزاءها.
    private val heavySteps: List<TextProcessingStep> = baseSteps + listOf(
        RomanNumeralStep,
        phoneNumberStep,
        SymbolStep,
        punctuationStep,
        numberStep
    )

// المسار الإنجليزي (اللغة الثانية): نفس بنية الخطوات بمفردات إنجليزية.
// **القاموسُ مُطبَّق هنا أيضاً** (كان محجوباً عن الإنجليزية فمدخلاتُ
// المستخدم اللاتينية — «HTTP» و«AI» و«CEO» — لم تكن تُنطق أبداً)،
// والوحدات/الأوقات/المختصرات/الرومانية تبقى عربيةَ محضة فلا تُطبَّق.
// الروابط تُحجب مؤقتاً كي لا تشوّهها خطوة الترقيم.
private val englishPreamble: List<TextProcessingStep> = listOf(
    IndicDigitsStep,
    EmojiStripStep { emojiEnabled },
    DictionaryStep(pronunciationDict)
)

    // الدلالات المبكرة للإنجليزية: تطبيع الأرقام ثم التواريخ/العملات، فلا
    // ينفصل رمزُ العملة («USD») عن مبلغه عند تقسيم اللغة.
    private val englishBaseSteps: List<TextProcessingStep> = listOf(
        IndicDigitsStep,
        DateStep(),
        CurrencyStep
    )

    // ثقيل الإنجليزي: يواصل بعد الدلالات المبكرة بالهاتف فالرموز فالترقيم
    // ثم الأرقام.
    private val englishHeavySteps: List<TextProcessingStep> =
        englishBaseSteps + listOf(
            phoneNumberStep,
            SymbolStep,
            punctuationStep,
            numberStep
        )

    /**
     * معالجة نص كامل وتحويله لصيغة نطق طبيعية.
     * @param languageTag كود اللغة (مثلاً "ar"، "en"، "ar-EG")
     *                    — العربية لها مسارها، والإنجليزية مسارٌ موازٍ
     *                      بمفرداتها، وبقية اللغات تُعاد كما هي.
     * @param enginePackage حزمة المحرك الـ TTS المستخدم (بند التشكيل الشرطي):
     *                      بعض المحركات (مثل Google TTS) تفهم التشكيل العربي
     *                      فتُنطق الحركات بوضوح — يحتفظ بنص المشكولة في
     *                      الإخراج عبر [restoreTashkeel]. القيمة null تعني
     *                      السلوك القائم.
     */
    fun process(
        text: String,
        languageTag: String = LanguageCode.AR.tag,
        enginePackage: String? = null
    ): String {
        if (text.isBlank()) return text

        // توحيد الترميز إلى NFC عند المدخل: نصٌ مفكوك الترميز (حرفٌ منفصل
        // عن تشكيله/شدّته أو إيموجي مفكك المكونات) يُطوى إلى صورته المركّبة
        // قبل أي خطوة — فتعمل التشكيل/الأرقام/الإيموجي على صيغة متطابقة
        // بلا ازدواج بين شكلٍ مركّبٍ وشكلٍ مفكوكٍ يأتي من أي مصدر خارجي.
        var result = Normalizer.normalize(text, Normalizer.Form.NFC)

        // تفسير SSML المحدود (بند الأوامر د.3.7): يترجم <break> و<say-as>
        // والكيانات قبل كل الفروع (العربية والإنجليزية واللغات الأخرى) —
        // هويةٌ تامة على النص العادي فلا تكلف أثراً على المسارات السريعة.
        result = SsmlStep.apply(result)


        // نطق أسماء الإيموجي (بدل حذفها) قبل مسار العربية ليغطي الإنجليزية
        // واللغات الأخرى أيضاً — الناتج لا يُمرَّر لأي تحويل لاحق خارج العربية.
        val expanded =
            if (emojiEnabled) expandEmojis(result, languageTag) else null

        // الإنجليزية: مسار موازٍ بمفرداتها (لا تحويل أرقامٍ إنجليزية إلى
        // كلماتٍ عربية) — الأرقام/التواريخ/العملات/الهواتف/الرموز/الترقيم
        // تُنطق إنجليزية، مع حجب الروابط كي لا تشوّهها خطوةُ الترقيم.
        if (LanguageCode.isEnglish(languageTag)) {
            var out = expanded ?: result
            for (step in englishPreamble) out = step.applyEnglish(out)
            val urls = ArrayList<String>()
            out = maskUrls(out, urls)
            if (requiresEnglishPipeline(out)) {
                for (step in englishHeavySteps) out = step.applyEnglish(out)
            }
            out = unmaskUrls(out, urls)
            return CleanupStep.apply(out)
        }

        // اللغات الأخرى (fr/de/es…) تُعاد كما هي بعد توسيع الإيموجي فقط.
        if (!LanguageCode.isArabic(languageTag)) {
            if (expanded != null) return CleanupStep.apply(expanded)
            return result
        }

        // text قد يحوي إيموجي عُرضت أسماؤها (expanded) أو تُحذف لاحقاً
        if (expanded != null) result = expanded
        // بند 1.7: نسخة مشكولة من النص (بعد توسيع الإيموجي وقبل الجرد)
        // تُحفظ لاستعادة تشكيل الكلمات الأصلية غير المتحوّلة حين يفعّل
        // المستخدم الحفظ — وإلا تبقى null فتسلك المعالجةُ السلوكَ الحالي
        // نفسه (تجريد التشكيل وتسليم النص مجرداً للمحرك).
        // **بند التشكيل الشرطي:** المحركات التي تفهم التشكيل العربي
        // (مثل Google TTS) تحتفظ بالتشكيل في الإخراج تلقائياً — نفعّل لها
        // نفس مسار الاستعادة [restoreTashkeel] بلا اشتراط تفضيل المستخدم.
        val voweledSource = if (tashkeelPreserved ||
            !stripTashkeelFor(enginePackage)
        ) {
            result
        } else {
            null
        }
        val urls = ArrayList<String>()
        var out = maskUrls(result, urls)
        for (step in preamble) out = step.apply(out, languageTag)

        // المسار السريع (Fast-path): إن لم يحتوِ النص على أي محفِّز لأرقام
        // الرموز/الصيغ (أرقام، فواصل، رموز عملة، حروف رومانية...) — أي نص
        // عربي صافٍ بلا أرقام — نتخطى كل مراحل regex الثقيلة (التواريخ/
        // الأوقات/العملات/الروابط/الرومانية/الهواتف/الأرقام/الرموز) ونذهب
        // مباشرةً لتنظيف المسافات. يوفّر تريليونات المطابقات على كل إعلان.
        if (!requiresRegexPipeline(out)) {
            out = unmaskUrls(out, urls)
            return finalizeArabic(voweledSource, CleanupStep.apply(out))
        }

        for (step in heavySteps) out = step.apply(out)
        out = unmaskUrls(out, urls)
        return finalizeArabic(voweledSource, CleanupStep.apply(out))
    }

    /**
     * تُكمل الناتج العربي النهائي (بعد معالجته وتنظيفه) بأحد مسارين:
     * عند تعطيل حفظ التشكيل تُسلَّم مُنظّفة كما هي، وعند تفعيله تُمرَّر
     * عبر [restoreTashkeel] ليعود لكل كلمةٍ لم تحوّلها خطوةٌ تشكيلُها
     * الأصلي — بلا أي أثر على منطق التحويل نفسه (بند 1.7).
     */
    private fun finalizeArabic(
        voweledSource: String?,
        cleaned: String
    ): String =
        if (voweledSource != null) restoreTashkeel(voweledSource, cleaned)
        else cleaned

/**
     * يعيد تطعيم تشكيل الكلمات الأصلية غير المتحوّلة إلى الناتج النهائي
     * (بند 1.7): يقارن كل كلمةٍ في النتيجة بنظيرها في المصدر (المطابقة
     * على الصيغة المجردة — كلمةٌ بقيت كما هي تُستبدل بصيغتها المشكولة،
     * وكلمةٌ محوّلة (رقم→لفظ، تاريخ، عملة...) تعجز عن ملاقاةِ من
     * نظيرها فتبقى بصيغة التحويل). بلا أي أثر على منطق التحويل نفسه.
     */
    private fun restoreTashkeel(
        voweledSource: String,
        processed: String
    ): String {
        if (processed.isEmpty()) return processed
        // معجم المصدر: كل كلمة مشكولة مقابل مجردها — تتم المحاكاة بعد
        // تقسيمٍ متوازٍ، والمشكولةُ الأصلي تُؤخذ من المصدر مباشرة.
        val normalizedSource = voweledSource
            .replace(PATTERN_WHITESPACE, " ").trim()
        val stripped = TashkeelStripStep.apply(normalizedSource)
        val sourceStripped = stripped.split(' ')
        val sourceVoweled = normalizedSource.split(' ')
        if (sourceStripped.size != sourceVoweled.size) return processed
        if (sourceStripped.isEmpty()) return processed
        // مطابقة كلمة-بكلمة بترتيب «أقرب متاح غير مستهلك»: الكلمات
        // المتحوّلة لا تُستهلك نظيرها، فيبقى متاحاً للكلمة الصحيحة
        // التالية — مطابقة لطيفة لا تصطدم بالمتكررات.
        val consumed = BooleanArray(sourceStripped.size)
        val rebuilt = StringBuilder(processed.length)
        var added = false
        for (word in processed.split(' ')) {
            if (word.isEmpty()) continue
            if (added) rebuilt.append(' ')
            var matched = false
            for (i in sourceStripped.indices) {
                if (consumed[i] || sourceStripped[i] != word) continue
                rebuilt.append(sourceVoweled[i])
                consumed[i] = true
                matched = true
                break
            }
            if (!matched) rebuilt.append(word)
            added = true
        }
        return rebuilt.toString()
    }

    /**
     * معالجة دلالية مبكرة للنص الكامل — تُستدعى قبل تقسيم اللغة
     * في NateqTtsService حتى لا يقسم مقسّمُ اللغاتِ «1500 USD» إلى
     * [مبلغ عربي, رمز إنجليزي] فيفقد
     * [CurrencyStep] مبلغَه المكسورُ أو يُنطق «USD» حروفاً بمحركٍ إنجليزي.
     * لا تشمل الخطوات الثقيلة الباقية (رومانية/هواتف/رموز/أرقام) لأن
     * كلَ نصٍ مقطعي يعاد تمريره عبر [process] لاحقاً بكامل الخطوات، فلا
     * يُكرر تحويل الأرقام هنا ولا يُستخدم الناتج إلا لتهيئة التقسيم.
     * @param languageTag كود اللغة (مثل "ar"، "en") — المعالجة مخصصة للعربية
     *                    فقط كـ[process]؛ غير العربية تُعاد كما هي.
     */
    fun processSemantics(
        text: String,
        languageTag: String = LanguageCode.AR.tag
    ): String {
        if (text.isBlank()) return text
        // توحيد NFC عند المدخل مطابقاً لـ[process] — يبقى الإخراج مطابقاً
        // لنمط التقسيم المعدَّ مسبقاً على صيغة موحَّدة.
        val normalized = Normalizer.normalize(text, Normalizer.Form.NFC)
        if (LanguageCode.isEnglish(languageTag)) {
            val urls = ArrayList<String>()
            var english = maskUrls(normalized, urls)
            if (requiresEnglishPipeline(english)) {
                for (step in englishBaseSteps) {
                    english = step.applyEnglish(english)
                }
            }
            english = unmaskUrls(english, urls)
            return CleanupStep.apply(english)
        }
        if (!LanguageCode.isArabic(languageTag)) return normalized
        val urls = ArrayList<String>()
        var result = maskUrls(normalized, urls)
        if (!requiresRegexPipeline(result)) {
            result = unmaskUrls(result, urls)
            return CleanupStep.apply(result)
        }
        for (step in baseSteps) result = step.apply(result)
        result = unmaskUrls(result, urls)
        return result
    }

    /**
     * فحص سريع لكل الحروف: هل يحتوي النص أي محفِّز يستدعي مراحل regex الثقيلة؟
     * المحفِّزات هي: أي حرف/رقم لاتيني (أرقام/فواصل/رموز/حروف رومانية وعملات
     * ورسميات مثل USD/SAR)، رموز العملة (€¥₹…)، أي رمز حسابي/عام، وعلامات عربية
     * خاصة (٪، ﷼) — فإذا خلا النص منها (عربي خالص بلا أرقام) نتخطى كل المراحل
     * ونكتفي بالتنظيف، فيتسارع معالجة السنة/الرسائل/
     * الإشعارات العادية بشكل كبير.
     */
    private fun requiresRegexPipeline(text: String): Boolean {
        for (i in text.indices) {
            val code = text[i].code
            when {
                // أي حرف/رقم/علامة لاتينية (استثناء الفراغات كافةً —
                // مسافة/سطر/تبويب) — يشمل الأرقام والفواصل ورموز العمليات
                // و @ و # وحروف العملات والرومانية والرسمية، وعلامات مثل
                // ° × ÷ (كلها دون U+0600).
                code < 0x600 && !text[i].isWhitespace() -> return true
                // ٪ (عربي للمئة) — تُستبدل في SYMBOL_NAMES_GENERAL
                code == 0x66A -> return true
                // الفاصلة المنقوطة العربية (؛) — تُنطق اسمها بمستوى «الكل»
                code == 0x61B -> return true
                // الشرطتان الطويلتان (– و—) وعلامة النقاط (…) — تُنطق
                // أسماؤها بمستوى «الكل» (كلها فوق نطاق ASCII ولا يلتقطها
                // الشرط اللاتيني في HEAVY أصلاً)
                code in 0x2013..0x2014 || code == 0x2026 -> return true
                // رموز عملة خارج ASCII (€¥₹…)
                code in 0x20A0..0x20CF -> return true
                // رموز النظام الرياضية/المنطقية (≥≤≠≈∞√…)
                code in 0x2200..0x22FF -> return true
                // باي اليوناني (يُستبدل في SYMBOL_NAMES_GENERAL)
                code == 0x03C0 -> return true
                // ﷼ (ريال سعودي)
                code == 0xFDFC -> return true
            }
        }
        return false
    }

    /**
     * بوابة الإنجليزي السريعة: خطواتُ المسار الإنجليزي كلها لا تعمل إلا
     * بحضور رقمٍ أو رمز — فإذا كان النص حروفاً/فراغات/فاصلةً عليا فقط
     * (وهو الشائع في مقاطع الإنجليزية) تخطّينا الممرات الثقيلة.
     */
    private fun requiresEnglishPipeline(text: String): Boolean {
        for (c in text) {
            if (c.isLetter() || c == ' ' || c == '\'' || c == '’') {
                continue
            }
            return true
        }
        return false
    }

    /**
     * حجب الروابط مؤقتاً أثناء خطوات الإنجليزية: خطوة الترقيم تعتبر «/»
     * المعزولة كلمةً فتشوّه «https://…». تُستبدل الروابط بمحارف حجزٍ في
     * منطقة الاستخدام الخاص (U+E000+) — بلا أرقام فلا تلمسها خطوةُ الأرقام،
     * وبلا حروفٍ لا يمسّها نطقُ الترقيم — ثم تُستعاد كما كانت.
     */
    private fun maskUrls(text: String, store: MutableList<String>): String {
        val matcher = PATTERN_URL_EN.matcher(text)
        if (!matcher.find()) return text
        matcher.reset()
        val buffer = StringBuffer()
        while (matcher.find()) {
            store += matcher.group()
            val token = (URL_MASK_BASE + store.size - 1).toString()
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(token))
        }
        matcher.appendTail(buffer)
        return buffer.toString()
    }

    /** استرجاع الروابط التي حجبتها [maskUrls] إلى مواضع محارف الحجز. */
    private fun unmaskUrls(text: String, store: List<String>): String {
        if (store.isEmpty()) return text
        val sb = StringBuilder(text.length + store.sumOf { it.length })
        for (ch in text) {
            val idx = ch - URL_MASK_BASE
            if (idx in store.indices) {
                sb.append(store[idx])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * توسيع الإيموجي ورموز المشاعر إلى أسمائها القابلة للنطق (عربي/إنجليزي
     * حسب languageTag). يشمل: كودات Unicode الموثّقة في EmojiNames، الإيموجي
     * النصيّ (☺), رموز المشاعر النصية (":)", ":) ", "<3"…)، والأعلام (رمزا
     * منطقة متجاوران). الإيموجي غير الموثّق يُنطق بالكلمة العامة الثابتة.
     * تُسقط تعديلات ألوان البشرة ومؤشرات الأشكال بصمت؛ و ZWJ يُحفظ
     * خارج تسلسلات الإيموجي (الكونجونكتات الهندية) ويُدمج داخلها، ويُدمج
     * الإيموجي المركّب (عائلة/مهنة) باسم أول مكوّن. عند تعطيل المفتاح لا
     * تُستدعى هذه الدالة (تُستخدم خطوة الإزالة بدلها).
     */
    private fun expandEmojis(text: String, languageTag: String): String {
        val arabic = LanguageCode.isArabic(languageTag)
        val fallback = if (arabic) EmojiNames.AR_FALLBACK
            else EmojiNames.EN_FALLBACK
        val base = EmojiNames.applyAsciiEmoticons(text, arabic)
        val sb = StringBuilder(base.length)
        var i = 0
        val len = base.length
        // تجميع الإيموجي المتكرر المتطابق المتلاصق (مثل 😂😂😂) في اسمٍ واحدٍ
        // مسبوقٍ بالعدد («ثلاثة وجه يضحك بدموع») بدل تكرار الاسم نفسه مرات —
        // فلا يُنطق 5-6 مرات متتالية مزعجة للمستمع. يُدمج المتجاور المتطابق
        // فقط، وأي حرفِ نصٍّ يفصلها.
        var groupIdent: String? = null
        var groupName = ""
        var groupCount = 0

        fun flushGroup() {
            if (groupIdent != null) {
                appendEmojiName(
                    sb,
                    if (groupCount > 1) {
                        emojiCountWord(groupCount, arabic) + " " + groupName
                    } else {
                        groupName
                    }
                )
                groupIdent = null
                groupName = ""
                groupCount = 0
            }
        }

        /** يضمّ إيموجيًّا (باسمه وهويته الكاملة) لمجموعة التكرار،
         *  أو يفتتح مجموعةً جديدة. */
        fun absorb(name: String, ident: String) {
            if (groupIdent == ident) {
                groupCount++
            } else {
                flushGroup()
                groupIdent = ident
                groupName = name
                groupCount = 1
            }
        }

        while (i < len) {
            val cp = base.codePointAt(i)
            val chars = Character.charCount(cp)
            val startOfUnit = i
            when {
                EmojiNames.isEmojiModifier(cp) -> {
                    // تعديلات منفصلة (ألوان بشرة/مؤشرات أشكال/Keycap/وسوم
                    // أعلام) تُسقط بصمت؛ ZWJ خارج التسلسل يُحفظ (نصوص هندية)
                    i += chars
                }
                EmojiNames.isRegionalIndicator(cp) -> {
                    val nextIdx = i + chars
                    if (nextIdx < len) {
                        val next = base.codePointAt(nextIdx)
                        if (EmojiNames.isRegionalIndicator(next)) {
                            val ident = base.substring(
                                startOfUnit, nextIdx + Character.charCount(next)
                            )
                            absorb(
                                EmojiNames.flagReadingName(
                                    EmojiNames.buildCountryCode(cp, next),
                                    arabic
                                ),
                                ident
                            )
                            i = nextIdx + Character.charCount(next)
                            continue
                        }
                    }
                    // علم غير مكتمل (رمز واحد بلا قرين): نطق عام
                    absorb(
                        fallback,
                        base.substring(startOfUnit, startOfUnit + chars)
                    )
                    i += chars
                }
                EmojiNames.isEmojiBlockCp(cp) -> {
                    val name = if (arabic) EmojiNames.arName(cp)
                        else EmojiNames.enName(cp)
                    i += chars
                    // تجاوز بقية المجموعة: ألوان بشرة، مؤشرات أشكال، وعناصر
                    // ما بعد ZWJ (عائلة/مهنة) حتى لا تُنطق مقاطع متناثرة
                    var zwjSeen = false
                    while (i < len) {
                        val c2 = base.codePointAt(i)
                        val c2chars = Character.charCount(c2)
                        when {
                            c2 in 0x1F3FB..0x1F3FF ||
                                c2 in 0xFE0E..0xFE0F -> i += c2chars
                            c2 == 0x200D -> {
                                zwjSeen = true; i += c2chars
                            }
                            EmojiNames.isEmojiBlockCp(c2) && zwjSeen -> {
                                i += c2chars; zwjSeen = false
                            }
                            else -> break
                        }
                    }
                    absorb(name ?: fallback, base.substring(startOfUnit, i))
                }
                else -> {
                    flushGroup()
                    sb.append(base, i, i + chars)
                    i += chars
                }
            }
        }
        flushGroup()
        return Normalizer.normalize(sb.toString().trim(), Normalizer.Form.NFC)
    }

    /** عدد التكرار ككلمةٍ منطوقة بلغة تسمية الأسماء (ثلاثة/three). */
    private fun emojiCountWord(count: Int, arabic: Boolean): String =
        if (arabic) NumberWordsConverter.numberToWords(count)
        else NumberSpeech.toEnglishWords(count)

    /** يلحق اسم إيموجي يفصله عن جاره بمسافة من الجهتين: إن لصِق اسمُ
     *  الإيموجي بكلمةٍ تالية بلا مسافة («مرحباً😀مرحبا») كانت الكلمةُ
     *  تلتصق بالاسم — الناتج النهائي يمر عبر [CleanupStep] فيُضمّ
     *  المسافات المتكررة وتُزال الطرفية (مع [trim]). */
    private fun appendEmojiName(sb: StringBuilder, name: String) {
        if (sb.isNotEmpty() && sb[sb.length - 1] != ' ') sb.append(' ')
        sb.append(name).append(' ')
    }

    /** تحويل رقم لكلمات عربية (يدعم حتى التريليونات، والكسور العشرية) —
     *  يفوّض لمحرك الأعداد المشترك في خط المعالجة. */
    fun numberToWords(number: Number): String =
        NumberWordsConverter.numberToWords(number)

    private companion object {
        /** نمط الروابط المحجوبة (نفس نمط [UrlStep]). */
        private val PATTERN_URL_EN = Pattern.compile(
            """(?i)\b(?:https?://|www\.)[^\s<>"']+|""" +
                """\b[a-zA-Z0-9_.-]+\.[a-zA-Z]{2,}(?::\d+)?/[^\s<>"']*"""
        )

        /** أول محرف في منطقة الاستخدام الخاص يُستخدم لحجز الروابط. */
        private const val URL_MASK_BASE = '\uE000'

        /** نمط الفراغات الموحد المخبأ لتجنب تكرار الترجمة عند كل جملة. */
        private val PATTERN_WHITESPACE = Regex("""\s+""")
    }
}