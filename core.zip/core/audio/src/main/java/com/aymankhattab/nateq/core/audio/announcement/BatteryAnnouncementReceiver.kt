package com.aymankhattab.nateq.core.audio.announcement

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.annotation.VisibleForTesting
import com.aymankhattab.nateq.core.audio.R
import com.aymankhattab.nateq.core.audio.engine.SynthesisBudget
import com.aymankhattab.nateq.core.common.readStickyBattery
import com.aymankhattab.nateq.core.common.SystemTimeProvider
import com.aymankhattab.nateq.core.common.TimeProvider
import com.aymankhattab.nateq.engine.NumberSpeech
import com.aymankhattab.nateq.core.data.SettingsRepository
import com.aymankhattab.nateq.util.LocaleUtils
import com.aymankhattab.nateq.util.LanguageCode
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * مستقبل إعلانات البطارية والشحن.
 *
 * يسمع ACTION_BATTERY_CHANGED (بث مستمر) فيُعلن عند الوصول إلى مستوى مفعّل
 * وعند اكتمال الشحن 100%، ويسمع ACTION_POWER_CONNECTED / POWER_DISCONNECTED
 * فيُعلن توصيل الشاحن وفصله. جميع النطق خاضع للمفتاح الرئيسي والإعدادات.
 */
class BatteryAnnouncementReceiver(
    private val timeProvider: TimeProvider = SystemTimeProvider
) : BroadcastReceiver() {

    companion object {
        // آخر حالة عولجت من بث البطارية الدائم — يُفلتر بها التكرار في
        // الذاكرة قبل أي عمل لاتزامني أو قراءة من القرص (بند 16.1).
        // مفتاح الفلترة يشمل النسبة والحالة ومصدر التوصيل: إغفالُهما كان
        // يُجمّد شرط اكتمال الشحن بعد أول 100% متصلةٍ (الحالة تتحول من
        // CHARGING إلى FULL والنسبة ثابتة فكان الفلتر النسبيّ يمنع الفحص).
        @Volatile
        private var lastFilterKey: String? = null

        @Volatile
        private var lastPowerActionTime = 0L

        @Volatile
        private var lastPowerAction: String? = null

        // **بند 5.5 + إصلاح القصّ:** كان 6 ثوانٍ ثابتةً، فإعلانٌ أطول منها كان
        // `goAsync` ينتهي والنظام **يجمّد العملية** (Process Cgroup
        // Freezer) فيُبتَر الصوت بلا خطأ. السقفُ الآن مشتقٌّ من
        // [SynthesisBudget.unitsTimeoutMs] ومحصورٌ بسقف ANR، فإن طال
        // النطق استثنائياً سُلِّم إلى خدمةٍ أمامية تكمله خارج نافذة البث.
        private const val BROADCAST_HOLD_ANR_MS = 9_000L

        /** اسم بديل نسبة البطارية في نصوص الإعلانات. */
        private const val PERCENT_PLACEHOLDER = "{percent}"

        /** هل هذا البث يمثل حالةً لم تُعالج بعد؟ يحسب النسبة مثل معالجة
         *  handler نفسها دون أي I/O؛ وبلا بيانات صالحة يُمرَّر البث فتتجاهله
         *  المعالجة أصلاً. */
        @JvmStatic
        fun isNewLevel(intent: Intent): Boolean {
            val level =
                intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
            val scale =
                intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
            if (level < 0 || scale <= 0) return true
            val percent = (level * 100) / scale
            val status =
                intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
            val plugged =
                intent.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)
            val key = "$percent|$status|$plugged"
            if (key == lastFilterKey) return false
            lastFilterKey = key
            return true
        }

        /** تصفير الفلتر بين دورات الاختبار. */
        @JvmStatic
        internal fun resetLevelFilterForTesting() {
            lastFilterKey = null
            lastPowerAction = null
            lastPowerActionTime = 0L
        }
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action != Intent.ACTION_BATTERY_CHANGED &&
            action != Intent.ACTION_POWER_CONNECTED &&
            action != Intent.ACTION_POWER_DISCONNECTED
        ) {
            return
        }
        // منع تكرار أحداث الشاحن اللحظية المتطابقة خلال 1.5 ثانية
        if (action == Intent.ACTION_POWER_CONNECTED ||
            action == Intent.ACTION_POWER_DISCONNECTED
        ) {
            val now = timeProvider.currentTimeMillis()
            if (action == lastPowerAction &&
                (now - lastPowerActionTime) < 1500L
            ) {
                return
            }
            lastPowerAction = action
            lastPowerActionTime = now
        }
        // فلترة البث الدائم في الذاكرة (بند 16.1): يُعالج بث البطارية فقط عند
        // تغيّر النسبة أو حالة الشحن أو مصدر التوصيل، فلا تُطلق كورووتينات
        // ولا تُفتح SharedPreferences لعشرات البثات المتكررة بنفس الحالة
        // (حرارة/جهد/شحن). أحداث التوصيل والفصل أفعال منفصلة لا تمرّ
        // بالفلتر وتُعالج دائماً.
        // كبت إعلان البطارية إذا سبقه حدث توصيل/فصل شاحن خلال 1.5 ثانية
        // لمنع تصادم طلبات التركيز وتكرار الإعلانات اللحظية.
        if (action == Intent.ACTION_BATTERY_CHANGED) {
            val now = timeProvider.currentTimeMillis()
            if ((now - lastPowerActionTime) < 1500L) {
                return
            }
            if (!isNewLevel(intent!!)) {
                return
            }
        }
        // goAsync() يمنع Android من قتل المستقبل قبل انتهاء العمل اللاتزامني
        val pendingResult = goAsync()
        val appScope =
            (context.applicationContext as? AnnouncementAppContext)?.appScope
                ?: CoroutineScope(Dispatchers.Default)
        appScope.launch {
            // **بند 3.9 (إبقاء المعالج مستيقظاً أثناء النطق):** نمطُ
            // TimeAlarmReceiver الموحَّد — WakeLockٌ جزئيٌّ عابرٌ (6 ثوانٍ =
            // نافذة البث، تحريرٌ ذاتيٌّ بمهلة الاقتناء بلا إفراجٍ يدويٍّ)
            // فلا ينامُ الجهازُ فيُقتطعَ إعلانُ البطاريةِ في منتصفه، ولا
            // تعارضَ مسارٍ (نفسُ المعرّفِ والطريقةِ وليس نسخةً مكررةً).
            var wakeLock: android.os.PowerManager.WakeLock? = null
            // حارس إنهاء وحيد لدورة البث — ذرّيٌ ليتحمل وصولَ الإنهاء من
            // خيطي البث واكتمال النطق معاً (finishٌ مكررٌ تحذير بلا لزوم).
            val finishedBroadcast = AtomicBoolean(false)
            fun finishOnce() {
                if (finishedBroadcast.compareAndSet(false, true)) {
                    pendingResult.finish()
                }
            }
            // إشارة انتهاء النطق — تُكملها خطاف الاكتمال فتُطلق الكوروتين
            // فوراً (بند 2.14: كان delay(6s) يظل معلقاً حتى بعد انتهاء النطق).
            val speechDone = CompletableDeferred<Unit>()
            var completionListener: (() -> Unit)? = null
            try {
                // **بند 5.5:** finish() الفوري قبل تمام التوليف كان يترك
                // أندرويد 14+ يجمد العملية عبر Process Cgroup Freezer
                // فيُبتر صوت البطارية في منتصف الجملة. إن نطق معالجٌ فعلاً
                // نُبقي النافذة حيّةً حتى يُتمَّ النطق (بسقفٍ آمن ~6 ثوانٍ
                // فلا ANR رغم تعليق المحرك)،
                // وإلا نُنهي فوراً.
                val speaker = AnnouncementSpeaker.getInstance(context)
                completionListener = { speechDone.complete(Unit) }
                speaker.addCompletionListener(completionListener!!)
                if (handle(
                        context, intent, action,
                        onCueDone = { speechDone.complete(Unit) }
                    )
                ) {
                    wakeLock = TimeAlarmReceiver.acquireShortWakeLock(context)
                    val holdMs = minOf(
                        SynthesisBudget.unitsTimeoutMs(listOf(60)),
                        BROADCAST_HOLD_ANR_MS
                    )
                    withTimeoutOrNull(holdMs) {
                        speechDone.await()
                    }
                    if (!speechDone.isCompleted) {
                        AnnouncementSchedulerService
                            .startForSpeech(context)
                    }
                    finishOnce()
                } else {
                    finishOnce()
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) {
                    throw t
                }
                android.util.Log.e("NATEQ_TTS", "battery announce failed", t)
            } finally {
                runCatching {
                    if (wakeLock?.isHeld == true) wakeLock.release()
                }
                completionListener?.let { listener ->
                    runCatching {
                        AnnouncementSpeaker.getInstance(context)
                            .removeCompletionListener(listener)
                    }
                }
                finishOnce()
            }
        }
    }

    /** يُنطق الإعلان إن لم يُمنع حرج؛ يُرجع true إذا صدر نطقٌ فعلي
     *  (أو مؤثرٌ صامت) يقتضي الإبقاء على نافذة goAsync حتى تمامه.
     *  يُسجَّل هذا المستقبل يدوياً من AnnouncementSchedulerService (لا عبر
     *  Hilt)، فيُفضَّل الحقل المحقون من التطبيق وإلا يُبنى محلياً. */
    private fun handle(
        context: Context,
        intent: Intent,
        action: String?,
        onCueDone: (() -> Unit)? = null
    ): Boolean {
        val appContext = context.applicationContext
        val settings =
            (appContext as? AnnouncementAppContext)?.settingsRepository
            ?: SettingsRepository.create(context)
        // المفتاح الرئيسي يُوقف كل الإعلانات دفعة واحدة.
        if (!settings.isAllAnnouncementsEnabled()) return false

        // بند 4.1: صوت البطارية المخصص إن وُجد؛ وإلا صوتُ اللغة المختارة
        // للنطق — فصوتٌ غير محفوظٍ لم يُسقط الإعلانَ بالإنجليزية
        // على مستخدمٍ عربيٍّ بعد اليوم.
        val voiceId = settings.getPreferredVoiceIdForCategory(
            SettingsRepository.VOICE_CATEGORY_BATTERY
        ) ?: batteryFallbackVoice(settings)
        // لغة الصوت المحددة في الشاشة التدريجية تتصدر حسم
        // العربية/الإنجليزية — ثم يُستنتج من تسمية الصوت كسند
        // تاريخي للقيم القديمة.
        val savedLanguage = runCatching {
            settings.getLanguageForCategory(
                SettingsRepository.VOICE_CATEGORY_BATTERY
            )
        }.getOrNull()
        // بند 4.3: أي تسمية عربية (ar، ar-XX، arabic…) تُعد عربيةً — كان
        // القصرُ على قائمة صيغ محددة (ar-local/ar-EG/nateq-ar) يسقط
        // لهجةً/صيغةً صوتية أخرى (ar-SA/ar-AE…) فيقرأ إعلان البطارية
        // بالإنجليزية خطأً على مستخدم عربي.
        val isArabic = when (savedLanguage) {
            LanguageCode.EN.tag -> false
            LanguageCode.AR.tag -> true
            // لغة محفوظة غير عربية/إنجليزية (مكتشفة خارج النطاق
            // الداعم لنصوص البطارية): يُرجع الحسم لتسمية الصوت
            // كالسلوك السابق تماماً.
            else -> voiceId?.let {
                it.startsWith("ar", ignoreCase = true) ||
                    it.contains("arabic", ignoreCase = true)
            } == true
        }
        val locale =
            if (isArabic) Locale.forLanguageTag(LanguageCode.AR.tag)
            else Locale.forLanguageTag(LanguageCode.EN.tag)

        var spoke = false
        when (action) {
            Intent.ACTION_POWER_CONNECTED -> {
                if (!settings.isChargingCompleteAnnouncementEnabled()) {
                    return false
                }
                val text = LocaleUtils.stringForSpeech(
                    context, if (isArabic) LanguageCode.AR.tag
                    else LanguageCode.EN.tag,
                    R.string.battery_connected, R.string.battery_connected
                ).withBatteryPercent(readStickyBattery(context), isArabic)
                spoke = speak(
                    context, settings, text, locale, voiceId,
                    CueType.BATTERY_CHARGING, onCueDone
                )
            }

            Intent.ACTION_POWER_DISCONNECTED -> {
                if (!settings.isChargingDisconnectAnnouncementEnabled()) {
                    return false
                }
                val text = LocaleUtils.stringForSpeech(
                    context, if (isArabic) LanguageCode.AR.tag
                    else LanguageCode.EN.tag,
                    R.string.battery_disconnected, R.string.battery_disconnected
                ).withBatteryPercent(readStickyBattery(context), isArabic)
                spoke = speak(
                    context, settings, text, locale, voiceId,
                    CueType.BATTERY_DISCONNECTED, onCueDone
                )
            }

            else -> {
                val enabledLevels = settings.getBatteryAnnouncementLevels()
                    .mapNotNull { it.toIntOrNull() }
                if (!settings.isBatteryAnnouncementEnabled() &&
                    enabledLevels.isEmpty()
                ) {
                    return false
                }

                val percentage = batteryPercent(intent) ?: return false
                val status =
                    intent.getIntExtra(
                        android.os.BatteryManager.EXTRA_STATUS, -1
                    )
                val plugged =
                    status == android.os.BatteryManager
                        .BATTERY_STATUS_CHARGING ||
                    status == android.os.BatteryManager.BATTERY_STATUS_FULL

                // اكتمال الشحن (100% ومتصل): إعلان مستقل يُنطق
                // مرة واحدة في الجلسة، ولا يُكرَّر إذا كان مستوى 100
                // مفعّلاً أصلاً (يُغطيه إعلان المستوى).
                if (percentage == 100 && plugged &&
                    settings.isChargingCompleteAnnouncementEnabled()
                ) {
                    val allowFullAnnounce = !enabledLevels.contains(100)
                    if (allowFullAnnounce &&
                        !announcedRecently(context, "full")
                    ) {
                        markAnnounced(context, "full")
                        val fullText = LocaleUtils.stringForSpeech(
                            context, if (isArabic) LanguageCode.AR.tag
                            else LanguageCode.EN.tag,
                            R.string.battery_full_unplug,
                            R.string.battery_full_unplug
                        )
                        spoke = speak(
                            context, settings, fullText, locale, voiceId,
                            CueType.BATTERY_FULL, onCueDone
                        )
                    }
                } else {
                    // توضيح متعمد: اكتمالُ الشحن ممكَّنٌ ولم يُعلن (إما أن
                    // المستوى 100 مفعّل أصلاً فيُغطيه إعلان المستوى، أو
                    // أُعلن حديثاً خلال نافذة المنع) — نستمر إلى فحص مستوى
                    // البطارية التالي أدناه، وأي نطقٍ منه يرفع `spoke`.
                }

                if (percentage !in enabledLevels) return spoke
                if (announcedRecently(context, "%$percentage")) return spoke
                markAnnounced(context, "%$percentage")

                val text = buildLevelText(context, percentage, isArabic)
                val levelCue = if (percentage <= 10) {
                    CueType.BATTERY_LOW
                } else {
                    null
                }
                spoke = spoke || speak(
                    context, settings, text, locale, voiceId, levelCue,
                    onCueDone
                )
            }
        }
        return spoke
    }

    /** نسبة البطارية من نَسَب extras، أو null إن غابت/فسدت. */
    private fun batteryPercent(intent: Intent?): Int? {
        if (intent == null) return null
        val level = intent.getIntExtra(
            android.os.BatteryManager.EXTRA_LEVEL, -1
        )
        val scale = intent.getIntExtra(
            android.os.BatteryManager.EXTRA_SCALE, -1
        )
        if (level < 0 || scale <= 0) return null
        return (level * 100) / scale
    }

    /**
     * يملأ `{percent}` في نص إعلان توصيل/فصل الشاحن بنسبة البطارية
     * بصيغة لفظية (ContentResolver.getString مع بديل، لا
     * resources.getString(int, Object) لأنها تتطلب Locale في هذا المسار).
     *
     * أحداث التوصيل والفصل لا تحمل EXTRA_LEVEL ولا EXTRA_SCALE (بثّان
     * منفصلان)، فنقرأ البث اللاصق للبطارية عبر [readStickyBattery] ونمرّره
     * هنا — وبلا نسبة صالحة يبقى النص كما هو (بلا نسبة) بدل إعلانٍ يحمل
     * البديلَ الحرفي.
     */
    @VisibleForTesting
    internal fun String.withBatteryPercent(
        batteryIntent: Intent?,
        isArabic: Boolean
    ): String {
        if (!contains(PERCENT_PLACEHOLDER)) return this
        val percent = batteryPercent(batteryIntent) ?: return this
        val words = if (isArabic) {
            NumberSpeech.toArabicWords(percent)
        } else {
            NumberSpeech.toEnglishWords(percent)
        }
        return replace(PERCENT_PLACEHOLDER, words)
    }

    private fun buildLevelText(
        context: Context,
        percentage: Int,
        isArabic: Boolean
    ): String {
        val lang = if (isArabic) LanguageCode.AR.tag else LanguageCode.EN.tag
        val percentWords = if (isArabic)
            NumberSpeech.toArabicWords(percentage)
        else
            NumberSpeech.toEnglishWords(percentage)
        return when (percentage) {
            100 -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_full, R.string.battery_full
            )
            50 -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_level_50,
                R.string.battery_level_50
            )
            20 -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_level_20,
                R.string.battery_level_20
            )
            10 -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_level_10,
                R.string.battery_level_10
            )
            in 0..9 -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_reached,
                R.string.battery_reached
            ).replace("{percent}", percentWords)
            else -> LocaleUtils.stringForSpeech(
                context, lang, R.string.battery_at, R.string.battery_at
            ).replace("{percent}", percentWords)
        }
    }

    private fun speak(
        context: Context,
        settings: SettingsRepository,
        text: String,
        locale: Locale,
        voiceId: String?,
        cueType: CueType?
    ): Boolean = speak(context, settings, text, locale, voiceId, cueType, null)

    private fun speak(
        context: Context,
        settings: SettingsRepository,
        text: String,
        locale: Locale,
        voiceId: String?,
        cueType: CueType?,
        onCueDone: (() -> Unit)?
    ): Boolean {
        val speechRate = settings.getSpeechRateForCategory(
            SettingsRepository.VOICE_CATEGORY_BATTERY
        )
        val volume = settings.getVolumeForCategory(
            SettingsRepository.VOICE_CATEGORY_BATTERY
        )
        val cueVolume = runCatching { settings.getBatteryCueVolume() }
            .getOrDefault(0.8f)
        val mode = runCatching { settings.getBatterySoundCueMode() }
            .getOrDefault(0)
        if (mode == 2 && cueType != null) {
            // «مؤثر فقط»: لا نطق، نغمة فقط (بدون تركيز — طويلة قصيرة
            // ضمن مسار الإتاحة).
            AudioCuePlayer.getInstance(context).play(
                AudioCue(type = cueType, volume = cueVolume)
            ) {
                onCueDone?.invoke()
            }
            return true
        }
        val speaker = AnnouncementSpeaker.getInstance(context)
        // إعادة ضبط صوت البطارية قبل كل نطق (بند [1]): صوتُ الإعلان كان
        // يعلق على صوت فئةٍ سابقة (متصل/إشعار/رسالة) فيُقرأ نص البطارية
        // بالصوت الخطأ — نفس نمط المتصل/الرسائل.
        speaker.resetVoice(voiceId)
        val cue = if (mode == 0 && cueType != null) {
            AudioCue(type = cueType, volume = cueVolume)
        } else {
            null
        }
        // بند 2.2: نبرةُ «نطق البطارية» المستقلة إن ضُبطت، أو نبرةُ نطق
        // اللغة بديلاً.
        val pitch = settings.getPitchForCategory(
            SettingsRepository.VOICE_CATEGORY_BATTERY
        )
        speaker.speak(
            text, locale, speechRate, pitch, volume,
            engineOverride = settings.getEngineForCategory(
                SettingsRepository.VOICE_CATEGORY_BATTERY
            ),
            cue = cue,
            category = SettingsRepository.VOICE_CATEGORY_BATTERY
        )
        return true
    }

    /** بند 4.1: صوتُ اللغة المختارة للنطق حين لا صوت بطارية مخصص. */
    private fun batteryFallbackVoice(
        settings: SettingsRepository
    ): String? = runCatching {
        val lang = settings.getAppLanguage()
        if (lang.isNullOrBlank()) return@runCatching null
        settings.getPreferredVoiceId(lang)
    }.getOrNull()

    /** منع تكرار نفس الإعلان خلال 5 دقائق (دورة شحن كاملة يمر الزمن كافياً).
     *  تُرجع true إذا نطق هذا المفتاح فعلاً خلال 5 دقائق مضت. التوقيت بالجدار
     *  الزمني (System.currentTimeMillis) لا بعداد الإقلاع: بعد إعادة تشغيل
     *  الهاتف يبدأ elapsedRealtime من الصفر فتصير الفروق مع الختوم القديمة
     *  سالبة ويتجمد إعلان المستوى حتى تنقضي المدة القديمة كاملة. */
    internal fun announcedRecently(
        context: Context,
        key: String,
        now: Long = timeProvider.currentTimeMillis()
    ): Boolean {
        val prefs =
            context.getSharedPreferences(
                "nateq_battery_state", Context.MODE_PRIVATE
            )
        val last = prefs.getLong("battery_last_announced_$key", -1L)
        return now - last < 5 * 60 * 1000L
    }

    internal fun markAnnounced(context: Context, key: String) {
        context.getSharedPreferences(
            "nateq_battery_state", Context.MODE_PRIVATE
        )
            .edit().putLong(
                "battery_last_announced_$key",
                timeProvider.currentTimeMillis()
            )
            .apply()
    }
}