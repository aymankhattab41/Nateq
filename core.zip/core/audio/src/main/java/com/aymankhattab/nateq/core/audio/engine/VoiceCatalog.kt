package com.aymankhattab.nateq.core.audio.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import com.aymankhattab.nateq.core.audio.providers.EnginePicker
import com.aymankhattab.nateq.core.audio.providers.VoiceDescriptor
import com.aymankhattab.nateq.core.audio.providers.VoiceProvider
import com.aymankhattab.nateq.util.LanguageCode
import com.aymankhattab.nateq.util.LocaleUtils
import com.aymankhattab.nateq.util.VoiceIdContract
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

/** محرك TTS يوفّر لغةً محددة، مع الأصوات المتاحة له داخلها. */
data class EngineWithVoices(
    val enginePackage: String,
    val engineLabel: String,
    /** الأصوات (android.speech.tts.Voice) التي يقدّمها هذا
     *  المحرك لهذه اللغة. */
    val voices: List<Voice>
)

/**
 * يجمّع كل الأصوات المتاحة من كل المزودين (النشطين/المُهيّئين فقط)
 * في قائمة واحدة موحّدة، كما يدير اكتشاف اللغات المتاحة فعلياً عبر
 * كل محركات TTS المثبتة (ديناميكياً بدل قائمة ar/en الثابتة). يُعتمد
 * في الاكتشاف حصرياً على نتيجة [TextToSpeech.getVoices] الفعلية لكل
 * محرك — فلا تُعرض لغةُ لم تُرجعها getVoices حتى لو أعلن المحرك دعمها
 * نظرياً — مع فحص إضافي isLanguageAvailable يستبعد لغات البيانات غير
 * المثبتة ([TextToSpeech.LANG_MISSING_DATA]).
 */
class VoiceCatalog(private val providers: List<VoiceProvider>) {

    companion object {
        private const val TAG = "NATEQ_TTS"

        /** مهلة استجابة المحرك الواحد أثناء الاكتشاف (ثوانٍ) —
         *  بعض المحركات تعلّق. خُفّضت إلى 5 ث للحد من تأثير المحركات البطيئة. */
        private const val ENGINE_PROBE_TIMEOUT_MS = 5_000L

        /**
         * القائمة السوداء للمحركات التي فشلت تهيئتها —
         *  تُحدّث ديناميكياً وتتجاوزها في محاولات الاكتشاف اللاحقة.
         *  مفتاح: packageName، قيمة: timestamp آخر فشل (لإمكانية إعادة المحاولة مستقبلاً).
         */
        @Volatile
        private var engineBlacklist: Map<String, Long> = emptyMap()

        private const val BLACKLIST_TTL_MS = 24 * 60 * 60 * 1000L // 24 ساعة

        private fun isBlacklisted(pkg: String): Boolean {
            val stamp = engineBlacklist[pkg]
            return stamp != null && (System.currentTimeMillis() - stamp < BLACKLIST_TTL_MS)
        }

        private fun blacklistEngine(pkg: String) {
            engineBlacklist = engineBlacklist + (pkg to System.currentTimeMillis())
        }

        /**
         * يكتشف فعلياً كل اللغات المتاحة عبر كل محركات TTS المثبتة في النظام:
         * يبني لكل محرك نسخة مؤقتة من [TextToSpeech] ويسألها [getVoices]، ثم
         * يغلقه فوراً ([shutdown]) مهما كانت النتيجة حتى لا تُسرّب موارد.
         * لكل لغة مرشّحة يفحص [TextToSpeech.isLanguageAvailable] فيستبعد أي
         * لغة تعود [TextToSpeech.LANG_MISSING_DATA] (بيانات غير مثبتة).
         *
         * النتيجة: languageTag -> قائمة المحركات التي توفّر اللغة، وكل محرك
         * يحمل أصواته لهذه اللغة مجمّعةً تحت اللسان نفسه (بلا تكرار محركات).
         */
        suspend fun discoverAllLanguagesAcrossEngines(
            context: Context
        ): Map<String, List<EngineWithVoices>> {
            // نستبعد قارئات الشاشة (TalkBack/Jieshuo/Talkman…)
            // من مساهمة اللغات: يسجّلون أنفسهم محركات TTS لكن
            // قرارهم (getVoices/isLanguageAvailable) يعلن لغات
            // نظريةً (eSpeak مثلاً) بلا بيانات مثبتة فعلياً
            // على الجهاز، فتظهر في القائمة لغاتٌ لا تُنطق.
            // يبقى الاختيار اليدوي صريحاً لهم.
            val engines = EnginePicker.installedEngines(context)
                .filterNot { EnginePicker.isScreenReader(it.packageName) }
                .filterNot { isBlacklisted(it.packageName) }
            // الفحص بالتوازي (كل محرك في مهمة IO مستقلة): كان متتابعاً فتبلغ
            // مدة الفحص N×10 ث بعشرة محركات بطيئة، الآن أقصى انتظار كحدود
            // المحرك الأبطأ نفسه (~10 ث) فتنفتح شاشة المحول بسرعة.
            val voicesByEngine = try {
                coroutineScope {
                    engines
                        .map { engine ->
                            async(Dispatchers.IO) {
                                engine.packageName to probeEngineVoices(
                                    context, engine.packageName
                                )
                            }
                        }
                        .awaitAll()
                        .toMap()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // إلغاء تعاوني (onStop/استباق): لا نصطاده مع بقية الأخطاء.
                throw e
            } catch (_: Throwable) {
                emptyMap<String, List<Voice>>()
            }
            return groupVoicesByLanguage(
                engines.map { it.packageName to it.label },
                voicesByEngine
            )
        }

        /**
         * يبني خريطة (languageTag -> المحركات التي توفرها) من أصوات المحركات
         * الفعلية فقط (بعد فلترة [filterVoicesWithInstalledData]) — أي لغة لم
         * تُرجعها getVoices لا تُدرج إطلاقاً حتى لو أعلن المحرك دعمها نظرياً.
         * دالة نقية قابلة للاختبار الآلي.
         */
        fun groupVoicesByLanguage(
            engineLabels: List<Pair<String, String>>,
            voicesByEngine: Map<String, List<Voice>>
        ): Map<String, List<EngineWithVoices>> {
            // lang -> engine -> voices
            val grouped = mutableMapOf<
            String, MutableMap<String, MutableList<Voice>>
        >()
            for ((pkg, voices) in voicesByEngine) {
                for (voice in voices) {
val lang = LocaleUtils.normalizeLanguageCode(
                        voice.locale?.language
                    )
                    if (lang.isBlank()) continue
                    grouped.getOrPut(lang) { LinkedHashMap() }
                        .getOrPut(pkg) { mutableListOf() }
                        .add(voice)
                }
            }
            val labelByPkg = engineLabels.toMap()
            return grouped.mapValues { (_, byEngine) ->
                byEngine.map { (pkg, engineVoices) ->
                    EngineWithVoices(
                        pkg,
                        labelByPkg[pkg] ?: pkg,
                        engineVoices.toList()
                    )
                }
            }
        }

        /**
         * فحص إضافي صريح لتوفر البيانات الصوتية: يستبعد أي أصواتٍ لغتُها تعود
         * من دالة التوفر (عادةً [TextToSpeech.isLanguageAvailable]) بنتيجة
         * [TextToSpeech.LANG_MISSING_DATA] — بياناتُها غير مثبتة على الجهاز
         * بعد — ويستبعد أيضاً أي صوتَ غير جاهز محلياً: صوته يحمل ميزة
         * [TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED] (لم يُنزَّل بعد)
         * أو صوته يتطلب اتصالَ شبكة ([Voice.isNetworkConnectionRequired]):
         * بعض المحركات (جوجل خاصةً) تُعلن اللسانَ متاحاً في التوفر لكن صوتَها
         * المطابق يُخلَّق عبر الشبكة لا من ملفات محلية مثبّتة، فيُستظهر في
         * القائمة لغةٌ لا تُنطق (توزّع "متاح" وليس جاهزاً للعمل الفعلي).
         * المعايير الثلاثة معاً تحجب اللغة من واجهة الاختيار تماماً (لا
         * تُعرض حتى معطّلة/رمادية) مع بقاء صندوق المحركات اليدوي كما هو.
         * دالة نقية قابلة للاختبار الآلي.
         */
        fun filterVoicesWithInstalledData(
            voices: List<Voice>,
            languageAvailability: (Locale) -> Int
        ): List<Voice> {
            val missingLangs = voices
                .mapNotNull { voice ->
                    LocaleUtils.normalizeLanguageCode(voice.locale?.language)
                        .takeIf { it.isNotBlank() }
                }
                .distinct()
                .filter { lang ->
                    val voicesForLang = voices.filter { v ->
                        LocaleUtils.normalizeLanguageCode(
                            v.locale?.language
                        ) == lang
                    }
                    val anyVoiceAvailable = voicesForLang.any { v ->
                        val loc = v.locale ?: return@any false
                        languageAvailability(loc) >=
                            TextToSpeech.LANG_AVAILABLE
                    }
                    if (anyVoiceAvailable) {
                        false
                    } else {
                        val availability = languageAvailability(
                            Locale.forLanguageTag(lang)
                        )
                        availability == TextToSpeech.LANG_MISSING_DATA
                    }
                }
                .toSet()
            val isNotInstalled = { voice: Voice ->
                voice.features.orEmpty().contains(
                    TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED
                ) ||
                    voice.isNetworkConnectionRequired
            }
            if (missingLangs.isEmpty() && voices.none(isNotInstalled)) {
                return voices
            }
            return voices.filter { voice ->
                val lang = LocaleUtils.normalizeLanguageCode(
                    voice.locale?.language
                )
                lang !in missingLangs && !isNotInstalled(voice)
            }
        }

        /**
         * يسبر محركاً واحداً: نسخة مؤقتة تُربط بالمحرك المعيّن مباشرةً
         * (منشئ ثلاثي المعاملات) ثم استعلام الأصوات ثم إغلاق إجباري.
         *
         * الربط المباشر ضروري: الربط عبر المُنشئ الافتراضي ثم
         * `setEngineByPackageName` ملحوظ كـ Deprecated وغير موثوق على كل
         * الأجهزة — خصوصاً حين يكون محرك النطق الافتراضي هو حزمة LORD نفسها
         * (التطبيق محرك TTS أصلياً)، إذ كان الاكتشاف يعود بأصوات المحرك
         * الافتراضي (فارغة) بدل المحرك المقصود فيتسرب غيابُ لغات.
         */
        @Suppress("DEPRECATION")
        private suspend fun probeEngineVoices(
            context: Context,
            enginePackage: String
        ): List<Voice> {
            val result: List<Voice>? = withTimeoutOrNull(
                ENGINE_PROBE_TIMEOUT_MS
            ) {
                suspendCancellableCoroutine<List<Voice>> { cont ->
                    @Suppress("DEPRECATION")
                    var probe: TextToSpeech? = null
                    val finished = AtomicBoolean(false)
                    val mainHandler = Handler(Looper.getMainLooper())
                    val created = runCatching {
                        probe = TextToSpeech(context, { status ->
                            mainHandler.post {
                                if (finished.getAndSet(true)) {
                                    runCatching { probe?.shutdown() }
                                    return@post
                                }
                                try {
                                    if (status != TextToSpeech.SUCCESS) {
                                        // وضع المحرك في القائمة السوداء لتجنّب إعادة المحاولة
                                        blacklistEngine(enginePackage)
                                        Log.w(TAG, "محرك $enginePackage فشل في التهيئة (status=$status) — أُضيف للقائمة السوداء")
                                        if (cont.isActive) {
                                            cont.resume(emptyList())
                                        }
                                    } else {
                                        if (cont.isActive) {
                                            cont.resume(
                                                probeInstalledVoices(probe)
                                            )
                                        }
                                    }
                                } catch (_: Throwable) {
                                    if (cont.isActive) cont.resume(emptyList())
                                } finally {
                                    runCatching { probe?.shutdown() }
                                }
                            }
                        }, enginePackage)
                    }
                    if (created.isFailure) {
                        // محرك غير قابل للربط (حزمة غير صالحة
                        // أو منزوعة): لا أصوات.
                        blacklistEngine(enginePackage)
                        cont.resume(emptyList())
                    }
                    // إن أُغلق الاكتشاف (مهلة/إلغاء) نغلق النسخة المعلقة.
                    cont.invokeOnCancellation {
                        if (finished.getAndSet(true)) {
                            return@invokeOnCancellation
                        }
                        runCatching { probe?.shutdown() }
                    }
                }
            }
            val voices = result ?: run {
                // مهلة أو إلغاء: أضف المحرك للقائمة السوداء
                blacklistEngine(enginePackage)
                Log.w(TAG, "محرك $enginePackage تجاوز المهلة (${ENGINE_PROBE_TIMEOUT_MS}ms) — أُضيف للقائمة السوداء")
                emptyList<Voice>()
            }
            return voices
        }

        /**
         * الأصوات المثبتة فعلياً لنسخة السبر: يقرأ [getVoices] ثم يفلترها
         * عبر [filterVoicesWithInstalledData] (بيانات غير مثبتة تُحجب).
         * مستخرجة خارج عمق لامبدا [TextToSpeech] لتقليل التعشيش والتزاماً
         * بحدود الطول (80 حرفاً لكل سطر).
         */
        @Suppress("DEPRECATION")
        private fun probeInstalledVoices(probe: TextToSpeech?): List<Voice> {
            // الاعتماد على النتيجة الفعلية لـ getVoices فقط،
            // مع فحص صريح لكل لغة: البيانات غير المثبتة
            // (LANG_MISSING_DATA) تُحجب من القائمة النهائية.
            val voices = runCatching { probe?.getVoices().orEmpty() }
                .getOrDefault(emptySet())
            return filterVoicesWithInstalledData(
                voices.toList()
            ) { locale ->
                val availability = runCatching {
                    probe?.isLanguageAvailable(locale)
                }.getOrNull()
                availability ?: TextToSpeech.LANG_NOT_SUPPORTED
            }
        }

        /**
         * أصواتُ اللغاتِ المُعلَنة الثابتة (tts_engine.xml) ككائناتِ Voice
         * جاهزةً — بنفس خصائص [supportedVoices] (جودة عالية/تأخير منخفض/
         * محلية بالكامل بلا شبكة) ليفحصها فحصُ النظام CHECK_TTS_DATA عبر
         * [filterVoicesWithInstalledData] دون مدخلاتٍ من سياقِ النشاط.
         */
        @Suppress("DEPRECATION")
        fun declaredVoices(): List<Voice> =
            VoiceIdContract.declaredVoiceNames().map { name ->
                val language = name.substringBefore('-')
                Voice(
                    name,
                    localeWithCountryFor(language),
                    Voice.QUALITY_HIGH,
                    Voice.LATENCY_LOW,
                    false, // requiresNetworkConnection = false (محلي بالكامل)
                    offlineFeature
                )
            }

        /**
         * ميزة التخليق المدمج (offline): تُعلن للأصوات في القائمتين
         * المضمونة والمكتشفة — الثابت مُهمَل في المنصة الحديثة لكن
         * إزالته تفاقم تصفية سامسونج لقائمة الأصوات، فيُبقى مع كتم
         * تحذير الإهمال. موجودة هنا (companion) لتتقاسمها supportedVoices
         * وdeclaredVoices من غير تكرار.
         */
        @Suppress("DEPRECATION")
        private val offlineFeature = setOf(
            TextToSpeech.Engine.KEY_FEATURE_EMBEDDED_SYNTHESIS
        )

        /**
         * يبني رمزَ اللغةِ بالبلدِ للغتينِ المضمونتين (ar → ar-EG و en →
         * en-US) ليطابقا الأصواتَ المعلنةَ في tts_engine.xml؛ فيُجيبُ
         * التحققُ من اللغةِ بـ LANG_COUNTRY_AVAILABLE بدلَ LANG_AVAILABLE
         * فتعرفُ المحركاتُ (سامسونج خاصةً) صوتَ البلدِ الصحيحَ. اللغاتُ
         * المكتشفةُ ديناميكياً (fr/de/…) تُبنى بحرفِها كما هي —
         * أصواتُها بأسمائها الصالحةِ كـ Locale (fr/de/…) بلا ضمانِ بلدٍ.
         */
        private fun localeWithCountryFor(language: String): Locale =
            when (language) {
                LanguageCode.AR.tag -> Locale.forLanguageTag("ar-EG")
                LanguageCode.EN.tag -> Locale.forLanguageTag("en-US")
                else -> Locale.forLanguageTag(language)
            }
    }

    /**
     * ذاكرة الاكتشاف داخل عملية المحرك (:tts) — تُبنى خلفياً عند إنشاء الخدمة
     * ومرة كل عهد فتح قوائم الأصوات، وحين تكون فارغة تعود القوائم للحد الأدنى
     * المضمون (العربية/الإنجليزية) فتبقى الخدمة تعمل دائماً.
     */
    @Volatile
    private var discoveredByLanguage:
        Map<String, List<EngineWithVoices>>? = null

    @Volatile
    private var lastDiscoveryAtMs = 0L

    /** يُحدّث ذاكرة الاكتشاف (يستدعيها المتصل بعد اكتشاف خلفي). */
    fun applyDiscovery(map: Map<String, List<EngineWithVoices>>) {
        discoveredByLanguage = map
        lastDiscoveryAtMs = System.currentTimeMillis()
    }

    /** هل الاكتشاف مُعدَم أو انتهت صلاحيته (بعد مرور ttlMs)؟ */
    fun needsRefresh(ttlMs: Long): Boolean =
        lastDiscoveryAtMs == 0L ||
            System.currentTimeMillis() - lastDiscoveryAtMs > ttlMs

    /**
     * يُبطل نتيجة الاكتشاف الحالية (بند 6.5): يُستدعى من مستقبلٍ يراقب
     * تثبيت/إزالة/تحديث محركات TTS الجاهزة في الحزم — فيتجدَّد الاكتشاف
     * عند المطالبة التالية فوراً بدل انتظار انقضاء فترة الصلاحية السابقة
     * (كان المحركُ المثبَّت حديثاً لا يظهر إلا بعد ساعة).
     */
    fun invalidateDiscovery() {
        lastDiscoveryAtMs = 0L
    }

    /**
     * محركات TTS المثبّتة المكتشفة التي توفّر لغةً معيّنة فعلياً، أو null
     * إن لم يكتمل الاكتشاف بعد. تُستخدم في بناء سلسلة التراجع لكل لغة
     * ([SystemVoiceProvider]) فلا يُحاوَل محركٌ لا ينطق اللغة أصلاً؛ لما
     * تبقى الذاكرة فارغة يعود null فيتراجع المتصل لقائمة المثبّتة كلها.
     * تطبيع اللغة بنفس قاعدة الاكتشاف (ISO-2) ليطابق مفتاح الخريطة.
     */
    fun discoveredEnginePackagesFor(languageTag: String): List<String>? {
        val lang = LocaleUtils.normalizeLanguageCode(languageTag)
        return discoveredByLanguage?.get(lang)?.map { it.enginePackage }
    }

    suspend fun allAvailableVoices(locale: Locale): List<VoiceDescriptor> =
        providers
            .filter { it.isConfigured() }
            .flatMap { it.listVoices(locale) }

    fun findProvider(providerId: String): VoiceProvider? =
        providers.find { it.providerId == providerId }

    /** إغلاق نهائي لكل المزودين (الاتصالات الخارجية لمن يحتاجها) — يُستدعى من
     *  [NateqTtsService.onDestroy] حتى لا تبقى روابط Binder IPC معلقة بعد تدمير
     *  الخدمة. استدعاءات لاحقة لا أثر لها (كل مزود يضمن التسامح). */
    fun shutdown() {
        providers.forEach { provider ->
            runCatching { provider.shutdown() }
        }
    }

    /**
     * اللغات المدعومة إجمالاً (تُستخدم في onIsLanguageAvailable).
     * تُبنى ديناميكياً من نتيجة الاكتشاف عبر كل المحركات، مع بقاء لغات
     * الإعلان الثابت في tts_engine.xml (ar/en/fr/de/es من
     * [VoiceIdContract.declaredVoiceNames]) حداً أدنى مضموناً دائماً
     * حتى لو لم يُكتشف أي محرك إضافي — فيتطابق onGetVoices مع أسماء
     * الملف حرفاً بحرف (اتساق CHECK_TTS_DATA).
     */
    fun supportedLocales(): List<Locale> {
        val languages = LinkedHashSet<String>()
        discoveredByLanguage?.keys?.forEach { languages.add(it) }
        VoiceIdContract.declaredVoiceNames().forEach { name ->
            languages.add(name.substringBefore('-'))
        }
        return languages
            .map { localeWithCountryFor(it) }
            .sortedBy { it.language }
    }

    /**
     * قائمة الأصوات (android.speech.tts.Voice) المُعلنة للنظام.
     * هذا هو المصدر الوحيد الذي يقرأ منه النظام في شاشة
     * "تعيين الصوت الخاص بلغة النص المنطوق" (onGetVoices).
     * تُشتق من اللغات المدعومة فعلياً حتى لا تظهر أصوات لا تُنطق.
     *
     * ملاحظة مهمة (سامسونج/بعض المَشغلين): الأصوات يجب أن تُعلن صراحةً
     * بـ KEY_FEATURE_EMBEDDED_SYNTHESIS (offline) وإلا تُصفَّى وتُهمَل من
     * قائمة اللغات. ولا يُضاف KEY_FEATURE_NOT_INSTALLED أبداً. (الثابت
     * offlineFeature في الـ companion ليشاركه declaredVoices أيضاً.)
     */
    private fun voiceNameFor(locale: Locale): String {
        // أسماء الأصوات المعلنة في tts_engine.xml هي "ar-EG"/"en-US" للغتين
        // الأساسيتين، وهي نفسها المعرّفات التي يخزنها تطبيقنا في الإعدادات
        // (بطارية/رسائل/متصل/فئات) والمعرّفات التي يُنتجها SystemVoiceProvider.
        // للّغات المكتشفة حديثاً (fr/de/zh/…) نُصدِر اسمَ اللغة نفسِه (مثل
        // "fr") كصوت موحّد صالح كـ Locale — سامسونج تفتت أسماء الأصوات عبر
        // Locale.forLanguageTag فتنهار على صيغة "<lang>-local" القديمة؛ النطق
        // الفعلي يذهب إلى المحرك الطرفي عبر خريطة التحويل
        // (desiredVoiceName/engine). الصيغة كلها مولّدة من عقد واحد
        // ([VoiceIdContract]) يشارك المزوّد في استخدامه فلا تنحرف الأسماء
        // المعلنة عن معرّفات الواصفات مجدداً.
        return VoiceIdContract.createId(locale.language)
    }

    fun supportedVoices(): List<Voice> =
        supportedLocales().map { locale ->
            Voice(
                voiceNameFor(locale),
                locale,
                Voice.QUALITY_HIGH,
                Voice.LATENCY_LOW,
                false, // requiresNetworkConnection = false (محلي بالكامل)
                offlineFeature
            )
        }

    /** معرّف الصوت الافتراضي للغة (يُطابق أسماء supportedVoices) */
    fun defaultVoiceNameForLanguage(language: String): String? =
        supportedLocales()
            .firstOrNull { it.language == language }
            ?.let { voiceNameFor(it) }
}