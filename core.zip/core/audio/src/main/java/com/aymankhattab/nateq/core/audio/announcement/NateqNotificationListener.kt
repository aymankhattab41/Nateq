package com.aymankhattab.nateq.core.audio.announcement

import android.Manifest
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat
import com.aymankhattab.nateq.core.audio.R
import com.aymankhattab.nateq.core.data.SettingsRepository
import com.aymankhattab.nateq.util.LocaleUtils
import com.aymankhattab.nateq.util.LanguageCode
import dagger.hilt.android.AndroidEntryPoint
import java.util.Collections
import java.util.LinkedHashMap
import java.util.Locale
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * خدمة الاستماع للإشعارات — تقرأ إشعارات التطبيقات المهمة
 * (واتساب، تلجرام، إلخ) بالصوت.
 * يجب منح الإذن يدوياً من: الإعدادات ← التطبيقات الخاصة ← الوصول للإشعارات.
 */
@AndroidEntryPoint
class NateqNotificationListener : NotificationListenerService() {

    companion object {
        private const val TAG = "NATEQ_NOTIF"

        // سقفُ عدد الحزم المتتبَّعة في نافذة منع التكرار (بند [10]) — كل إصدار
        // يتحدث قائمة الحزم الشائعة، والحزم الجديدة تتسرب القديمة (LRU).
        private const val MAX_TRACKED_NOTIF_PACKAGES = 64

        /** التحقق مما إذا كان التطبيق لديه إذن الاستماع للإشعارات. */
        fun isPermissionGranted(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            val cn = ComponentName(
                context, NateqNotificationListener::class.java
            )
            return flat.contains(cn.flattenToString())
        }

        /** مفتاحُ هوية مكالمة الإشعار: حزمةُ التطبيق + الرقم + الاسم — به
         *  تُميَّز مكالمةٌ عن تحديثٍ لإشعار المكالمة ذاتها. خالص. */
        fun notificationCallKey(
            pkg: String?,
            number: String?,
            name: String?
        ): String = "${pkg.orEmpty()}|${number.orEmpty()}|" +
            "${name.orEmpty()}"

        /** هل يحوي عنوان/نص الإشعار رمز تحقق سري ينبغي حجبه؟ يُطبَّق فقط مع
         * تفعيل حماية الخصوصية — نفس منطق فلتر OTP الخاص بالرسائل النصية. */
        fun shouldMaskOtp(
            privacyEnabled: Boolean,
            title: String?,
            text: String?
        ): Boolean = privacyEnabled && LocaleUtils.containsOtp(
            "${title.orEmpty()} ${text.orEmpty()}".trim()
        )

        /** استخراج نص الإشعار بترتيب سقوط: EXTRA_TEXT ثم نصّ الموسّع
         *  EXTRA_BIG_TEXT (إشعارات واتساب/أميل متعددة الأسطر) ثم أسطر
         *  EXTRA_TEXT_LINES مربوطة — حتى لا تُفقد رسالة طويلة النص
         *  (تحسين [بند 26]). */
        fun notificationBodyText(extras: android.os.Bundle): String? {
            val bigText = extras.getCharSequence(
                Notification.EXTRA_BIG_TEXT
            )?.toString()?.trim()
            val textLines = extras.getCharSequenceArray(
                Notification.EXTRA_TEXT_LINES
            )?.filterNotNull()?.joinToString("\n")
            return extras.getCharSequence(Notification.EXTRA_TEXT)
                ?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                ?: bigText?.takeIf { it.isNotEmpty() }
                ?: textLines?.takeIf { it.isNotEmpty() }
        }
    }

    /** مصدر الإعدادات المحقون — نفس كائن عملية المحرك المُدار من Hilt. */
    @Inject
    lateinit var settingsRepository: SettingsRepository

    private val minIntervalMs = 3000L // الحد الأدنى لإشعارات نفس التطبيق

    // الحد الزمني يُطبَّق لكل حزمة على حدة (بند [10]): إشعاران من تطبيقين
    // مختلفين خلال 3 ثوانٍ لا يُسقط أحدهما الآخر (كان حدّاً عاماً واحداً
    // يُفقد إشعاراً مهماً تصادفَ بعد أي إشعارٍ آخر). متزمِّنة للأمان،
    // LRU (accessOrder=true) لسقفِ الحزم المتتالية.
    private val lastNotifTimes = Collections.synchronizedMap(
        object : LinkedHashMap<String, Long>(32, 0.75f, true) {
            override fun removeEldestEntry(
                eldest: MutableMap.MutableEntry<String, Long>
            ): Boolean = size > MAX_TRACKED_NOTIF_PACKAGES
        }
    )

    /** هل الإشعار من هذه الحزمة مسقطُ الشفرة (وصل إشعارٌ سابق خلال
     *  [minIntervalMs])؟ فحصٌ والتحديث معاً تحت نفس القفل — القابلية
     *  للاختبار بحقن خريطة (بند [10]). */
    internal fun isNotificationRateLimited(
        pkg: String,
        now: Long,
        times: MutableMap<String, Long> = lastNotifTimes
    ): Boolean {
        return synchronized(times) {
            val last = times[pkg]
            if (last == null) {
                // أول إشعار من هذه الحزمة: مسموح دوماً ويُسجَّل وقتُه.
                times[pkg] = now
                false
            } else {
                val limited = (now - last) < minIntervalMs
                if (!limited) times[pkg] = now
                limited
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // كل المعالجة (قراءات الإعدادات، استعلام تطبيق الرسائل الافتراضي،
        // إطارات الواجهة Keyguard، فحص الاستثناءات، النطق) تُنفَّذ على
        // appScope (Io) — استدعاء NLS يأتي على خيط الخدمة الرئيسي وكانت
        // عمليات قرص و IPC متزامنة عليه تسبب إسقاط إطارات مع وصول كثيف.
        val scope = (applicationContext as? AnnouncementAppContext)?.appScope
            ?: CoroutineScope(Dispatchers.Default)
        scope.launch {
            try {
                onNotificationPostedWorker(sbn)
            } catch (t: Throwable) {
                Log.e(TAG, "onNotificationPosted failed", t)
            }
        }
    }

    private fun onNotificationPostedWorker(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName ?: return

            // إشعارُ الهاتف يُفحص **قبل كل البوابات** لا بعدها: هو أسرع
            // مصدرٍ للهوية، وملفُّه مستقلٌّ عن قائمة التطبيقات التي اختارها
            // المستخدم — فمنعُ إشعار تطبيق الهاتف ليس رفضاً لإعلان هوية
            // المتصل. فلو فحصناه بعد `isNotificationReadingEnabled`
            // وقائمة التطبيقات لبقي الهاتفُ خارج المسارِ دائماً.
            //
            // **لكن** بوّابة الإذن تبقى للمصادقة: إذنُ الاستماع أذنه
            // المستخدم لمنحِ إشعاراتِ تطبيقاتِ **مختارة**، ولا يُقرأ
            // كلُّ إشعارٍ لمجرّد أنه يُقرأ تطبيقُ الهاتف. فمسارُ هوية
            // المتصل محصورٌ في `CATEGORY_CALL` وحده ولا ينفتح إلا
            // بتفعيل إعلان المتصل (وإلا صار إشعارُ الهاتف قناةً
            // لقراءة إشعارات لم يطلبها).
            val notification = sbn.notification
            if (notification != null &&
                notification.category == Notification.CATEGORY_CALL
            ) {
                if (settingsRepository.isCallerAnnouncementEnabled()) {
                    val extras = notification.extras
                    val rawTitle = extras.getCharSequence(
                        Notification.EXTRA_TITLE
                    )?.toString()?.trim()
                    val rawText = notificationBodyText(extras)
                    val rawSubText = extras.getCharSequence(
                        Notification.EXTRA_SUB_TEXT
                    )?.toString()?.trim()
                    val (callNumber, callName) =
                        RingCallerIdentity.extractFromCallNotification(
                            rawTitle, rawText, rawSubText
                        )
                    Log.w(
                        TAG,
                        "CALL-IDENTITY pkg=$pkg num=${callNumber ?: "?"}" +
                            " name=${callName ?: "?"}"
                    )
                    // **رفعُ عَلَم «انتهى الرنين» قبل كل البوابات**
                    // (بند 5.6 معكوس): إن كان الجوابُ قد وقع فالموضوعُ
                    // ليس إعلاناً جديداً بل **وقفُ تكرارٍ جارٍ** — وهو
                    // يَحتاج أن يُعلَم حتى حين يُكبَح الإعلانُ نفسه أدناه.
                    // والإثباتُ بالإيجاب فقط ([isAnsweredCallPhrase]) فلا
                    // يُمسّ إعلانُ مكالمةٍ ما زالت ترنّ (Meet الوارد مثلاً).
                    if (notificationCallPhrases(notification).any {
                            RingCallerIdentity.isAnsweredCallPhrase(it)
                        }
                    ) {
                        Log.w(
                            TAG,
                            "CALL ANSWERED pkg=$pkg — أُوقف تكرارُ " +
                                "إعلان المتصل"
                        )
                        CallerAnnouncementReceiver.markCallAnswered()
                    }
                    // ===== بند 1 و4: إثباتُ الورود ثم حسمُ المسار =====
                    //
                    // **لا نطقَ إلا بدليلِ ورودٍ إيجابي.** فكان الحارسُ
                    // القديم ينطق ما لم يجد دليلَ صدور، فيُعلَن الصادرةُ
                    // واردةً. والأدلّةُ تُقرأ من النظام مباشرةً: نوعُ
                    // المكالمة، ونافذةُ ملءِ الشاشة، وإجراءُ الردّ، ورنينُ
                    // الخطّ — والاستنتاجُ كلُّه في دالةٍ خالصةٍ مفحوصة.
                    //
                    // **وحالُ الخطّ تُقرأ لا من عَلَمٍ في الذاكرة:** فموتُ
                    // العملية بين `OFFHOOK` والإشعار يُنسي العَلَمَ ولا
                    // يُنسي النظامَ — وهذا ما يجعل حارسَ موتِ العملية
                    // حقيقياً.
                    val callState = telephonyCallState()
                    val positivelyIncoming = isPositivelyIncoming(
                        notification, callState
                    )
                    val isDefaultDialer =
                        CallerAnnouncementReceiver.isDefaultDialerPackage(
                            pkg, defaultDialerPackage()
                        )
                    val route = CallerAnnouncementReceiver
                        .decideCallNotificationRoute(
                            isDefaultDialer = isDefaultDialer,
                            telephonyCallState = callState,
                            positiveIncoming = positivelyIncoming
                        )
                    when (route) {
                        CallerAnnouncementReceiver.CallNotificationRoute
                            .SILENT -> {
                            Log.w(
                                TAG,
                                "CALL no proof of incoming pkg=$pkg" +
                                    " state=$callState dialer=$isDefaultDialer"
                            )
                            return
                        }
                        CallerAnnouncementReceiver.CallNotificationRoute
                            .PUBLISH_IDENTITY_ONLY -> {
                            // **بند 4:** حزمةُ الافتراضي لا تنطق أبداً —
                            // `PHONE_STATE` وحده ناطِقُ مكالمات الشبكة.
                            // وإشعارُها أسرعُ مصدرٍ لاسم المتصل فننشرُه
                            // فقط، فينطقه البثُّ مع الرقم.
                            RingCallerIdentity.publish(callNumber, callName)
                            Log.w(
                                TAG,
                                "CALL identity from dialer pkg=$pkg" +
                                    " num=${callNumber ?: "?"}" +
                                    " name=${callName ?: "?"}"
                            )
                            return
                        }
                        else -> Unit
                    }
                    // **حارس الاتجاه (الاسماء الصادرة والمنتهية):** إشعارُ
                    // `CATEGORY_CALL` وحده لا يميّز الواردةَ من الصادرة
                    // ولا المنتهية — فكان يُنطق «اتصال وارد من فلان» لمن
                    // *هو* المتصل، وأحياناً بعد انتهاء المكالمة. الحارسُ
                    // نقيٌّ في [CallerAnnouncementReceiver] ومفحوصٌ هناك.
                    if (!shouldAnnounceCallNotification(
                            notification = notification,
                            number = callNumber,
                            name = callName
                    )
                    ) {
                        Log.w(
                            TAG,
                            "CALL-IDENTITY skipped pkg=$pkg" +
                                " num=${callNumber ?: "?"}"
                        )
                        return
                    }
                    // **نُطلق ولا ننطق — والنطقُ وحيدٌ في
                    // [CallerAnnouncementReceiver].** مكالماتُ التطبيقات
                    // (واتساب/تلجرام/ميسنجر) VoIPُ بحتٌ فلا يصدر لها بثّ
                    // `PHONE_STATE` أبداً — فلو اكتفينا بنشر الهوية لبقيت
                    // بلا نطقٍ واحد. فنستدعي مسارَ الرنين مباشرةً داخل
                    // العملية (بند 7: لا بثَّ إلى المستقبل المصدَّر)
                    // فينفّذ تكراراتٍ وفواصلَ وحرّاسَ ازدواجٍ بلا مضاعفةٍ
                    // مع مكالمات الشبكة.
                    if (callNumber != null || callName != null) {
                        CallerAnnouncementReceiver.announceNotificationCall(
                            context = applicationContext,
                            settings = settingsRepository,
                            number = callNumber,
                            name = callName,
                            key = notificationCallKey(
                                pkg, callNumber, callName
                            )
                        )
                    }
                }
                return
            }

            val settings = settingsRepository
            if (!settings.isNotificationReadingEnabled()) return
            // المفتاح الرئيسي يُوقف كل الإعلانات دفعة واحدة.
            if (!settings.isAllAnnouncementsEnabled()) return

            // إشعار من تطبيق الرسائل النصية مع قراءة SMS مفعّلة:
            // يُعالج بمسار SMS المستقل (قبل فحص قائمة تطبيقات قراءة الإشعارات
            // العادية) لأنه ميزة منفصلة لها إعداداتها الخاصة.
            // - إن كان RECEIVE_SMS ممنوحاً فسيَنطقه SmsReadingReceiver
            //   مباشرة (نتجنب هنا).
            // - إن لم يكن ممنوحاً نقرأ الرسالة عبر خدمة الاستماع
            //   للإشعارات (NLS) بإعدادات SMS المتخصصة
            //   (الصوت/السرعة/الخصوصية/فلتر OTP) بدل الإذن المقيّد.
            val defaultSmsApp = runCatching {
                android.provider.Telephony.Sms
                    .getDefaultSmsPackage(applicationContext)
            }.getOrNull()
            val isSmsApp = pkg == defaultSmsApp
            val smsMode = settings.getSmsReadingMode()
            if (isSmsApp && smsMode != SmsReadingReceiver.MODE_OFF) {
                val hasSmsPermission = ContextCompat.checkSelfPermission(
                    applicationContext, Manifest.permission.RECEIVE_SMS
                ) == PackageManager.PERMISSION_GRANTED
                if (hasSmsPermission) return
                handleSmsNotification(sbn, settings, smsMode)
                return
            }

            // قراءة التطبيقات المختارة فقط (للمستخدم حرية اختيار قائمتها).
            if (!settings.shouldReadNotificationApp(pkg)) return

            // تجنب إسقاط الإشعارات المتتالية بشكل سريع — لكل حزمة حدُّها
            // المستقل (بند [10]) فلا يُسقط إشعارُ تطبيقٍ إشعارَ تطبيقٍ آخر.
            if (isNotificationRateLimited(pkg, System.currentTimeMillis())) {
                return
            }

            val extras = sbn.notification?.extras ?: return

            val title = extras.getCharSequence(Notification.EXTRA_TITLE)
                ?.toString()?.trim()
            val text = notificationBodyText(extras)

            if (title.isNullOrBlank() && text.isNullOrBlank()) return

            val appName = getAppName(pkg)
            // خصوصية قفل الشاشة: عند القفل يُنطق اسم التطبيق فقط دون العنوان
            // والنص (حماية لكلمات تحقق OTP وغيرها من الحساسيات في الإشعارات).
            val privacyEnabled = settings.isLockScreenPrivacyEnabled()
            val privacyLocked =
                privacyEnabled && settings.isDeviceScreenLocked()
            // فلتر OTP الشامل (حماية الخصوصية مفعّلة): كلُّ الإشعارات لا مسار
            // تطبيق الرسائل فقط — واتساب/تلجرام/البنوك تُرسل رموز تحقق تُنطق
            // علناً دون حجب. يُنطق بدل الرمز عبارة آمنة عامة (نمط حماية SMS).
            val isOtp = shouldMaskOtp(
                privacyEnabled, title, text
            )
            val speechText = if (isOtp) {
                val appLang = if (LocaleUtils.containsArabic(appName)) {
                    LanguageCode.AR.tag
                } else {
                    LanguageCode.EN.tag
                }
                LocaleUtils.stringForSpeech(
                    applicationContext, appLang,
                    R.string.notif_otp_safe, R.string.notif_otp_safe
                ).replace("{app}", appName)
            } else {
                buildSpeechText(appName, title, text, privacyLocked)
            }
            val isArabic = LocaleUtils.containsArabic(speechText)
            val locale = if (isArabic) {
                Locale.forLanguageTag(LanguageCode.AR.tag)
            } else {
                Locale.forLanguageTag(LanguageCode.EN.tag)
            }

            // سجلّ مجرّد من مضمون الإشعار (قد يحوي OTP/حساسيات)
            // — الطول والحزمة فقط.
            Log.d(TAG, "Notification from $pkg: ${speechText.length} chars")

            // احترام إعدادات فئة "صوت الإشعارات"
            // (سرعته/نبرته/مستواه) بدل ثوابت 1.0
            val speechRate = settings.getSpeechRateForCategory(
                SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
            )
            val pitch = settings.getPitchForCategory(
                SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
            )
            val volume = settings.getVolumeForCategory(
                SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
            )
            // بند 1.5: محرك فئة الإشعارات (إن ضُبط) بدل التلاؤم الصامت
            // مع المحرك العام. **بند 2.2:** يُعاد ضبط صوتِ الفئة قبل
            // النطق (مثل بقية الإعلانات) — كان النطق يعلق على صوت
            // فئةٍ سابقة (متصل/رسائل) فيُقرأ الإشعار بالصوت الخطأ.
            val speaker = AnnouncementSpeaker.getInstance(applicationContext)
            speaker.resetVoice(
                settings.getPreferredVoiceIdForCategory(
                    SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
                )
            )
            speaker.speak(
                speechText, locale, speechRate, pitch, volume,
                engineOverride = settings.getEngineForCategory(
                    SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
                ),
                category = SettingsRepository.VOICE_CATEGORY_NOTIFICATIONS
            )

        } catch (t: Throwable) {
            Log.e(TAG, "onNotificationPosted failed", t)
        }
    }

    /**
     * هل يستحقّ إشعارُ مكالمةٍ إعلانَ «اتصال وارد»؟ يفوّض القرارَ كلَّه
     * إلى [CallerAnnouncementReceiver.shouldAnnounceCallNotification] ليبقى
     * الحارسُ نقيّاً مختبراً في مكانٍ واحد، ويجلب له الدلائلَ الثلاثة من
     * النظام: جريانُ الإشعار، وحالةُ خطّ الهاتف، وآخرُ مكالمةٍ انتهيناها.
     */
    private fun shouldAnnounceCallNotification(
        notification: Notification,
        number: String?,
        name: String?
    ): Boolean {
        val ongoing = (notification.flags and
            Notification.FLAG_ONGOING_EVENT) != 0
        // **الاتجاهُ من النصّ لا من العَلَم:** جوجل ميت يُعلِّم إشعارَ
        // مكالمته الواردة `ongoing` من لحظة الرنّ، فرفضُ كلِّ `ongoing`
        // (سلوك v1.6.20) أسقط إعلانَه بالكامل. فالدليلُ على الصغرى
        // أن يكون النصُّ «calling…» أو «جاري الاتصال».
        val outgoing = notificationCallPhrases(notification)
            .any { RingCallerIdentity.isOutgoingCallPhrase(it) }
        // حالةُ خطّ الهاتف تُقرأ مباشرةً من النظام لا من عَلَم المستقبل:
        // بثّ `OFFHOOK` يُعالَج في coroutineٍ قد يتأخّر، والإشعارُ يصل
        // بعده مباشرةً — فمن يقرأ العَلَمَ يظنّ المكالمةَ غيرَ قائمة.
        //
        // **و`callState` مُهمَلٌ رسمياً — مع ذلك نقرأه:** بديلُه
        // `TelecomManager.isInCall()` لا يميّز رنيناً من مشغولٍ بل يُرجع
        // `true` لكلِّ مكالمةٍ قائمة — بما فيها مكالمةُ تطبيقٍ مُدارةٍ عبر
        // Telecom، فيُكبِت إعلانُ مكالمةٍ **واردة** زائفةً. فهو أسوأُ من
        // `callState` في هذا الحارس. ولهذا نمرّ على [telephonyCallState]
        // لا على قراءةٍ مباشرة، فيبقى لكلِّ الأدلّة مصدرٌ واحد.
        val callInProgress =
            CallerAnnouncementReceiver.isOutgoingNetworkCallState(
                telephonyCallState()
            )
        val endedAt = CallerAnnouncementReceiver.lastPhoneIdleAt
        val sameEnded = CallerAnnouncementReceiver.matchesLastNetworkCall(
            lastNumber = CallerAnnouncementReceiver.lastNetworkCallNumber,
            lastName = CallerAnnouncementReceiver.lastNetworkCallName,
            number = number,
            name = name
        )
        return CallerAnnouncementReceiver.shouldAnnounceCallNotification(
            isOngoing = ongoing,
            networkCallInProgress = callInProgress,
            endedCallAt = endedAt,
            sameEndedIdentity = sameEnded,
            now = System.currentTimeMillis(),
            outgoing = outgoing
        )
    }

    /** نصوصُ إشعار المكالمة الثلاثة كما نراها خاماً (العنوان والنصّ
     *  والورقة) — تُقرأ مرةً واحدة هنا وتُستخدم للحارس وللاستخراج. */
    private fun notificationCallPhrases(
        notification: Notification
    ): List<String> {
        val extras = notification.extras
        return listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
            notificationBodyText(extras),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).map { it.trim() }.filter { it.isNotEmpty() }
    }

    /**
     * **هل إشعارُ المكالمة يُثبت ورودَها بالإيجاب؟** — واجهةُ الاستدعاء
     * التي يستدعيها المسارُ الحقيقيُّ بتوقيعها المطلوب.
     *
     * **وهي غلافٌ رقيقٌ يُحيلُ إلى نواةٍ نقيّة:** تستخرج الأدلّةَ من
     * `Notification` وتُمرّرها إلى
     * [CallerAnnouncementReceiver.isPositivelyIncoming] — وهي الدالةُ
     * الخالصةُ التي تحمل العقدَ كلَّه وتُفحَص ببنودها.
     *
     * **ولماذا الغلافُ هنا لا هناك؟** لأنّ استخراج دليلين يحتاج `Context`:
     *  - عنوانُ إجراء الردّ يُقارَن بكلمةِ «ردّ» **المترجَمةِ من مواردنا**،
     *    فالمصدرُ مواردُ لا قائمةُ كلماتٍ ثابتة؛
     *  - تسميةُ اللغة الفعلية عبر [LocaleUtils].
     *
     *فالسياقُ لازمٌ لهذه الغلاف، **وليس للنواة**. ولذلك تبقى النواةُ بلا
     * `Context` قابلةً للاختبار، وتبقى الواجهةُ بتوقيع
     * `isPositivelyIncoming(notification, telephonyCallState)` كما طُلبت
     * بالضبط.
     */
    private fun isPositivelyIncoming(
        notification: Notification,
        telephonyCallState: Int
    ): Boolean = CallerAnnouncementReceiver.isPositivelyIncoming(
        callTypeExtra = callTypeOf(notification),
        hasFullScreenIntent = notification.fullScreenIntent != null,
        hasAnswerAction = hasAnswerAction(notification),
        telephonyCallState = telephonyCallState,
        sdkInt = Build.VERSION.SDK_INT,
        legacyIncomingPhrase = legacyIncomingPhrase(notification)
    )

    // ===== جمعُ أدلّة الورود (بند 1) — impure، والاستنتاجُ نقيٌّ =====

    /**
     * حالةُ خطّ الهاتف **من النظام مباشرةً** لا من عَلَمٍ في الذاكرة.
     *
     * **ولهذا يُقرأ في كلِّ إشعار:** عَلَمُ «مكالمةٌ صادرة» يُضبط عند
     * معالجة بثّ `OFFHOOK` في coroutineٍ قد يتأخّر أو تُفقد بموتِ
     * العملية، فمن يقرأ العَلَمَ يظنّ المكالمةَ غيرَ قائمة بعد موته.
     */
    private fun telephonyCallState(): Int = runCatching {
        @Suppress("DEPRECATION")
        (applicationContext.getSystemService(
            Context.TELEPHONY_SERVICE
        ) as? TelephonyManager)?.callState
            ?: TelephonyManager.CALL_STATE_IDLE
    }.getOrDefault(TelephonyManager.CALL_STATE_IDLE)

    /**
     * نوعُ المكالمة الذي أعلنَه التطبيقُ (`EXTRA_CALL_TYPE`)، أو `null`
     * إن لم يذكره.
     *
     * **و`null` يعني «لا معلومة» لا «مجهول»:** فالتطبيقُ القديم لا يضع
     * المفتاحَ أصلاً، فلا يجوز أن يُقرأ صفراً. والمجهولُ صراحةً يبقى
     * صفراً فيقرأه الحارسُ على حقيقته ولا يسودُ على بقية الأدلّة.
     */
    private fun callTypeOf(notification: Notification): Int? {
        val extras = notification.extras ?: return null
        if (!extras.containsKey(Notification.EXTRA_CALL_TYPE)) return null
        return extras.getInt(
            Notification.EXTRA_CALL_TYPE,
            CallerAnnouncementReceiver.CALL_TYPE_UNKNOWN
        )
    }

    /**
     * هل في الإشعار **إجراءُ ردّ**؟ بالدلالي الرسميّ أو بنصٍّ **مُترجَمٍ من
     * الحزمة الناشرِّة** — لا بقائمة عربي/إنجليزي ثابتة.
     *
     * **ومصدرُ النصّ هو موارد التطبيق نفسه:** المنصّة تُصفّ عنوانَ الإجراء
     * في `Notification.Action.title` بعد ترجمته من موارد التطبيق الناشر
     * (لا واصفٌ عامّ في `android.jar` — فتُقرأ الترجمةُ جاهزةً ولا نحتاج
     * `PackageManager`). ثم نُقابلها بكلمةِ «ردّ» **المترجَمةِ من مواردنا**
     * إلى اللغتين المدعومتين، فتأتي المقارنةُ بين نصَّين من مواردَين لا
     * بين نصٍّ وقائمةٍ مكتوبة.
     *
     * **وقائمةُ كلماتٍ ثابتة مستبعدةٌ عمداً:** نصوصُ التطبيقات تختلف
     * باللهجة والإصدار (`رد` / `رد الآن` / `إجابة` / `Answer call`).
     *
     * ولا زرَّ ردٍّ على مكالمةٍ أنتَ من بدأتها — فهذا دليلُ ورودٍ قاطع.
     */
    private fun hasAnswerAction(notification: Notification): Boolean {
        val actions = notification.actions
        if (actions.isNullOrEmpty()) return false
        val words = answerWordsFromOurResources()
        return actions.any { action ->
            action.semanticAction ==
                Notification.Action.SEMANTIC_ACTION_CALL ||
                isAnswerLabel(action.title?.toString(), words)
        }
    }

    /**
     * كلماتُ الردّ من **مواردنا** للغتين المدعومتين — فالمصدرُ مواردٌ لا
     * جدولٌ مكتوبٌ في الكود.
     */
    private fun answerWordsFromOurResources(): List<String> {
        val words = ArrayList<String>(2)
        for (tag in listOf(LanguageCode.AR.tag, LanguageCode.EN.tag)) {
            val normalized = RingCallerIdentity.normalizeCallPhrase(
                LocaleUtils.stringForSpeech(
                    applicationContext, tag,
                    R.string.caller_answer, R.string.caller_answer
                )
            )
            if (normalized.isNotEmpty() && !words.contains(normalized)) {
                words.add(normalized)
            }
        }
        return words
    }

    /**
     * هل عنوانُ الإجراء كلمةُ ردّ؟ بـ`startsWith` بعد التطبيع ليقبل
     * «رد» و«رد الآن» و«Answer call» معاً.
     */
    private fun isAnswerLabel(title: String?, words: List<String>): Boolean {
        if (title.isNullOrBlank()) return false
        val normalized = RingCallerIdentity.normalizeCallPhrase(title)
        if (normalized.isEmpty()) return false
        return words.any { word -> normalized.startsWith(word) }
    }

    /**
     * الطبقةُ النصّيةُ الثانوية: هل في نصوص الإشعار عبارةُ ورودٍ صريحة؟
     *
     * **وتركيبُ حدِّ النظام داخلَ الدالةِ الخالصة** ([isPositivelyIncoming])
     * لا هنا — فمصدرُ الحقيقةِ واحد. فلا تُهمَلُ على كلِّ الحالات،
     * والحاسمةُ هي الدالةُ النقيّة.
     */
    private fun legacyIncomingPhrase(notification: Notification): Boolean =
        notificationCallPhrases(notification)
            .any { RingCallerIdentity.isIncomingCallPhrase(it) }

    /** حزمةُ مُشغِّلِ الهاتف الافتراضي، أو `null` إن لم يُعرف. */
    private fun defaultDialerPackage(): String? = runCatching {
        (applicationContext.getSystemService(
            Context.TELECOM_SERVICE
        ) as? TelecomManager)?.defaultDialerPackage
    }.getOrNull()

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        // حذفُ إشعار المكالمة = انتهاؤها (أو ردٌّ يُخفيه التطبيق). وهو
        // **الحدثُ الوحيد الذي ينهي مكالمة VoIP** فلا يُصدره النظام بثّاً،
        // فبلاه يُكبح النطقُ كلُّ مكالماتِ نفس المتصل التالية بمفتاحه.
        // والإجراءُ نفسه يتحقق من الحزمة فلا يختلُّ شيءٌ لحذفِ إشعارِ
        // مكالمةِ شبكةٍ أثناءَ جولةِ إشعارٍ جارية.
        if (sbn.notification?.category != Notification.CATEGORY_CALL) return
        CallerAnnouncementReceiver.endNotificationCall(
            applicationContext, sbn.packageName
        )
    }

    /**
     * **إعادةُ بناء مفتاح المكالمة الجارية عند ربط المستمع من جديد.**
     *
     * **والعيبُ الذي يسدّده:** مفتاحُ جلسة مكالمة الإشعار في ذاكرة
     * العملية ([CallerAnnouncementReceiver.notificationCallKey]). فتموت
     * العمليةُ في وسط رنينٍ فيُنسى المفتاح، ثم يردُّ التطبيقُ تحديثَ
     * مكالمته فيحسبه [CallerAnnouncementReceiver] إعلاناً جديداً
     * فيُنطق الاسمُ ثانيةً فوق مكالمةٍ جارية — مع جدولِ تكراراته.
     *
     * **والمخرجُ الذي يُبنى منه هو النظامُ نفسُه** — لا ساعةٌ ولا
     * تخزينٌ جديد: `activeNotifications` تُرجع إشعارَ المكالمة التي
     * كانت ترنّ قبل الموت، فنُنبِئُ الحارسَ بها فيرفض تحديثَها.
     *
     * **ولماذا هنا وحده:** الربطُ حدثٌ لا يتكرّر فيُفسد شيئاً. أمّا
     * `onNotificationPosted` فلا يصلح للتبنّي من فيه لأن الإشعار
     * الحالي داخلَ القائمة دائماً فيبدو سابقاً لموتنا — فلا يُميَّز
     * عن حيٍّ. أمّا هنا فالمقروءُ قائمةٌ من لحظتِه لا لحظتِ إشعارٍ
     * قادم.
     *
     * **وتُرتَّب المفاتيحُ بـ`postTime`** فينتقي
     * [CallerAnnouncementReceiver.pickNewestLiveCallKey] أحدثَها: وهي
     * التي رنَّت الآن، والأقدمُ تُركتُ بلا مفتاحٍ فتُعلَن لو وحدَها
     * حدثت.
     *
     * **ويُستثنى مُشغِّلُ الهاتف الافتراضي:** مسارُه
     * `PUBLISH_IDENTITY_ONLY` لا يلمس المفتاح أصلاً (بند 4)، فتبنّيُ
     * مفتاحٍ منه يحجبُ مفتاحَ مكالمةٍ تطبيقٍ حقيقيةٍ أحدثُ منه.
     *
     * **والعملُ كلُّه على `appScope`** كمسار `onNotificationPosted`:
     * `activeNotifications` قراءةُ IPC على خيط الربط، و`postTime`
     * و`extras` قراءاتُ نظامٍ لا يصحّ أن تُحسَب على خيط الربط.
     */
    override fun onListenerConnected() {
        super.onListenerConnected()
        val scope = (applicationContext as? AnnouncementAppContext)?.appScope
            ?: CoroutineScope(Dispatchers.Default)
        scope.launch {
            try {
                adoptLiveCallNotifications()
            } catch (t: Throwable) {
                Log.e(TAG, "adoptLiveCallNotifications failed", t)
            }
        }
    }

    private fun adoptLiveCallNotifications() {
        val live = runCatching { activeNotifications }
            .getOrNull()
            .orEmpty()
        if (live.isEmpty()) return
        if (!settingsRepository.isCallerAnnouncementEnabled()) return
        val dialer = defaultDialerPackage()
        val candidates = live.mapNotNull { sbn ->
            val notification = sbn.notification ?: return@mapNotNull null
            if (notification.category != Notification.CATEGORY_CALL) {
                return@mapNotNull null
            }
            val pkg = sbn.packageName ?: return@mapNotNull null
            if (CallerAnnouncementReceiver.isDefaultDialerPackage(
                    pkg, dialer
                )
            ) {
                return@mapNotNull null
            }
            val extras = notification.extras
            val (number, name) = RingCallerIdentity
                .extractFromCallNotification(
                    title = extras.getCharSequence(
                        Notification.EXTRA_TITLE
                    )?.toString()?.trim(),
                    text = notificationBodyText(extras),
                    subText = extras.getCharSequence(
                        Notification.EXTRA_SUB_TEXT
                    )?.toString()?.trim()
                )
            if (number == null && name == null) return@mapNotNull null
            sbn.postTime to notificationCallKey(pkg, number, name)
        }
        val adopted = CallerAnnouncementReceiver
            .pickNewestLiveCallKey(candidates)
        if (adopted == null) return
        Log.w(TAG, "CALL rebind saw ${candidates.size} live call(s)")
        CallerAnnouncementReceiver.adoptLiveNotificationCall(adopted)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        AnnouncementSpeaker.getInstance(applicationContext).stop()
        Log.w(TAG, "NotificationListener disconnected — محاولة إعادة الربط")
        // إعادة الربط التلقائي بعد فصل النظام (توفير الطاقة/إيقاف مؤقت)
        // حتى لا تتوقف قراءة الإشعارات دون تدخل المستخدم.
        try {
            requestRebind(
                ComponentName(this, NateqNotificationListener::class.java)
            )
        } catch (t: Throwable) {
            Log.e(TAG, "requestRebind failed", t)
        }
    }

    /** قراءة الرسائل النصية الواردة عبر إشعار تطبيق الرسائل
     * (بديل NLS بدل إذن RECEIVE_SMS). */
    private fun handleSmsNotification(
        sbn: StatusBarNotification,
        settings: SettingsRepository,
        smsMode: String
    ) {
        val notification = sbn.notification ?: return
        val extras = notification.extras

        // في إشعارات تطبيقات الرسائل: العنوان يحمل اسم/رقم المرسل
        // عادةً والنص المحتوى.
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)
            ?.toString()?.trim()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)
            ?.toString()?.trim()
        if (sender.isNullOrBlank() && body.isNullOrBlank()) return

        val displayAddress = sender ?: getString(R.string.sms_unknown_sender)
        val voiceId = settings.getSmsReadingVoiceId()
        val speechRate = settings.getSmsReadingRate()
        val volume = settings.getSmsReadingVolume()

        val content = (body ?: "").trim()
            .take(SmsReadingReceiver.MAX_SMS_CONTENT_LENGTH)
        // خصوصية قفل الشاشة: عند القفل يُنطق المصدر فقط
        // دون المحتوى (حماية OTP).
        val privacyLocked = settings.isLockScreenPrivacyEnabled()
                && settings.isDeviceScreenLocked()
        val effectiveMode =
            if (privacyLocked) SmsReadingReceiver.MODE_SOURCE else smsMode

        val dynamicText = "$displayAddress $content"
        val useArabicVoice = !dynamicText.any { it.isLetter() } ||
            LocaleUtils.containsArabic(dynamicText)

        val template = settings.getSmsAnnouncementTemplate()
        // فلتر رمز التحقق (OTP): لا يُنطق الرمز نفسه في الأماكن العامة.
        val isOtp = LocaleUtils.containsOtp(content)
        val smsFrom = LocaleUtils.stringForSpeech(
            applicationContext,
            if (useArabicVoice) LanguageCode.AR.tag else LanguageCode.EN.tag,
            R.string.sms_from,
            R.string.sms_from
        ).replace("{name}", displayAddress)

        val text = when {
            privacyLocked -> smsFrom
            isOtp -> LocaleUtils.stringForSpeech(
                applicationContext,
                if (useArabicVoice) LanguageCode.AR.tag
                else LanguageCode.EN.tag,
                R.string.sms_otp_safe,
                R.string.sms_otp_safe
            ).replace("{name}", displayAddress)
            template.isNotBlank() -> template
                .replace("{name}", displayAddress)
                .replace("{message}", content.ifBlank { displayAddress })
            content.isBlank() -> smsFrom
            effectiveMode == SmsReadingReceiver.MODE_SOURCE -> smsFrom
            else -> "$smsFrom، $content"
        }

        val isArabic = LocaleUtils.containsArabic(text)
        val locale =
            if (isArabic) Locale.forLanguageTag(LanguageCode.AR.tag)
            else Locale.forLanguageTag(LanguageCode.EN.tag)

        Log.d(TAG, "SMS via NLS: ${text.length} chars")

        val speech = AnnouncementSpeaker.getInstance(applicationContext)
        speech.resetVoice(voiceId)
        // **بند 2.2:** نبرةُ «نطق الرسائل» المستقلة إن ضُبطت، أو نبرةُ
        // نطق اللغة بديلاً + محرك فئة الرسائل — لا الثابت 1.0.
        val pitch = settings.getSmsReadingPitchOrDefault(locale.language)
        speech.speak(
            text, locale, speechRate, pitch, volume,
            engineOverride = settings.getEngineForCategory(
                SettingsRepository.ANNOUNCE_CATEGORY_SMS
            ),
            category = SettingsRepository.ANNOUNCE_CATEGORY_SMS
        )
    }

    private fun buildSpeechText(
        appName: String,
        title: String?,
        text: String?,
        privacyLocked: Boolean
    ): String {
        // لغة النطق من محتوى الإشعار (اسم التطبيق/العنوان/النص)
        // لا من لغة الواجهة
        val dynamicText = "$appName ${title.orEmpty()} ${text.orEmpty()}"
        val isArabic = !dynamicText.any { it.isLetter() } ||
            LocaleUtils.containsArabic(dynamicText)
        val lang = if (isArabic) LanguageCode.AR.tag else LanguageCode.EN.tag
        // عند قفل الشاشة نكتفي باسم التطبيق دون أي مضمون.
        if (privacyLocked) {
            return LocaleUtils.stringForSpeech(
                applicationContext, lang, R.string.notif_new, R.string.notif_new
            ).replace("{app}", appName)
        }
        return when {
            !title.isNullOrBlank() && !text.isNullOrBlank() ->
                LocaleUtils.stringForSpeech(
                    applicationContext, lang,
                    R.string.notif_from_title_text,
                    R.string.notif_from_title_text
                ).replace("{app}", appName)
                .replace("{title}", title)
                .replace("{text}", text)
            !title.isNullOrBlank() -> LocaleUtils.stringForSpeech(
                applicationContext, lang,
                R.string.notif_from_title,
                R.string.notif_from_title
            ).replace("{app}", appName).replace("{title}", title)
            !text.isNullOrBlank() -> LocaleUtils.stringForSpeech(
                applicationContext, lang,
                R.string.notif_from_text,
                R.string.notif_from_text
            ).replace("{app}", appName).replace("{text}", text)
            else -> LocaleUtils.stringForSpeech(
                applicationContext, lang, R.string.notif_new, R.string.notif_new
            ).replace("{app}", appName)
        }
    }

    private fun getAppName(packageName: String): String {
        return when (packageName) {
            "com.whatsapp" -> getString(R.string.app_whatsapp)
            "com.whatsapp.w4b" -> getString(R.string.app_whatsapp_business)
            "org.telegram.messenger",
            "org.telegram.messenger.web" -> getString(R.string.app_telegram)
            "com.facebook.orca" -> getString(R.string.app_messenger)
            "com.instagram.android" -> getString(R.string.app_instagram)
            else -> packageName.substringAfterLast('.')
        }
    }
}
