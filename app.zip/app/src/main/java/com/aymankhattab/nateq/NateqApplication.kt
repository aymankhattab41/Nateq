package com.aymankhattab.nateq

import android.app.AlarmManager
import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import com.aymankhattab.nateq.core.audio.announcement.AnnouncementAppContext
import com.aymankhattab.nateq.core.audio.announcement.TimeAnnouncementManager
import com.aymankhattab.nateq.core.audio.providers.EnginePicker
import com.aymankhattab.nateq.core.common.AppDispatchers
import com.aymankhattab.nateq.core.data.SettingsRepository
import com.aymankhattab.nateq.core.data.StartupTempSweeper
import com.aymankhattab.nateq.nav.SettingsOpenRegistry
import com.aymankhattab.nateq.settings.SettingsActivity
import com.aymankhattab.nateq.util.ProcessUtils
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * نقطة الدخول العامة للتطبيق.
 * يطبّق هنا لغة التطبيق المختارة يدوياً (إن حددها المستخدم) قبل أي Activity،
 * حتى تنعكس اللغة على الواجهة فوراً عند أول عُرض.
 *
 * تعدد العمليات: يعمل في عمليتين —
 *  1) العملية الرئيسية (الواجهة + الخدمة الأمامية للإعلانات الدورية) و
 *  2) عملية المحرك `:tts` (NateqTtsService فقط).
 * كائن SettingsRepository يُنشأ في كل عملية على حدة، لذا يُستدعى
 * SettingsRepository.reload() في الخدمات بعد أي كتابة من العملية الأخرى
 * حتى لا تُقرأ قيم قديمة مخزنة مؤقتاً.
 */
@HiltAndroidApp
class NateqApplication : Application(), AnnouncementAppContext {

    /** مصدر الإعدادات الوحيد المحقون — ينشئه Hilt مرة واحدة في كل عملية. */
    @Inject
    override lateinit var settingsRepository: SettingsRepository

    /** نطاق عام يعيش مع التطبيق — بديل GlobalScope للمستقبلات اللاحقة.
     *  يُرفق معالج أخطاء عام يمنع إسقاط العملية عند أي استثناء لا يُلتقط
     *  داخل كوروتينات المستقبلات، ويسجّله في اللوج بدلاً من ذلك. */
    private val appCoroutineExceptionHandler =
        CoroutineExceptionHandler { _, t ->
            Log.e("NATEQ_APP", "استثناء غير مُلتقط في النطاق العام", t)
        }

    override val appScope = CoroutineScope(
        SupervisorJob() + AppDispatchers.io + appCoroutineExceptionHandler
    )

    override fun onCreate() {
        super.onCreate()

        // ===== التحقق من سلامة التطبيق (Anti-tamper / Anti-debug / Play Integrity) =====
        // يعمل غير حاصر — الفشل يسجّل خطأ ويقرر السلوك لاحقاً (لا يُسقط الإقلاع صامتاً).
        // في بناء Release حقيقي: EXPECTED_SIGNATURE_SHA256 تُستبدل بالقيمة الفعلية.
        verifyAppIntegrity(this) { ok ->
            if (!ok) {
                Log.e("NATEQ_APP", "App integrity check FAILED — بيئة غير موثوقة")
                // هنا يمكن: إيقاف الميزات الحساسة، إظهار تحذير، إغلاق التطبيق، إلخ.
                // حالياً: تسجّل الخطأ وتستمر لتفادي false-positive على أجهزة نادرة.
            }
        }

        // وجهة إشعار خدمة الإعلانات: تُسجَّل من هنا (المطبق الذي يعرف
        // شاشة الإعدادات) بدل تسميتها نصياً في core:audio.
        SettingsOpenRegistry.register { ctx ->
            Intent(ctx, SettingsActivity::class.java)
        }

        // كاش محركات TTS يُلغى عند تثبيت/إزالة/استبدال أي حزمة حتى يلتقط
        // المسحُ التالي محركاً جديداً فورياً (بلا انتظار انتهاء الخمس دقائق).
        ContextCompat.registerReceiver(
            this,
            object : BroadcastReceiver() {
                override fun onReceive(
                    context: Context?,
                    intent: Intent?
                ) {
                    EnginePicker.invalidateCache()
                }
            },
            IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addDataScheme("package")
            },
            ContextCompat.RECEIVER_EXPORTED
        )

        // **بند 2.19 (تغيّر إذن المنبهات الدقيقة):** مستقبلُ بثٍّ ديناميكيٌّ
        // (في التطبيق — صاحبُ سياقِ العمليةِ الرئيسيةِ) يستمعُ إلى بثِّ
        // النظامِ ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED (إذنٌ
        // محميٌّ بامتيازاتِ النظامِ) فيعيدُ [TimeAnnouncementManager] بناءَ
        // منبهِ الوقتِ التالي فوراً عبرَ onExactAlarmPermissionChanged ليلتقطَ
        // الصيغةَ الدقيقةَ الجديدةَ في منحِ الإذنِ أو سحبِه دونَ انتظارِ دورةِ
        // الجدولةِ الطبيعيةِ. مسجَّلٌ بـ RECEIVER_NOT_EXPORTED (لا واجهةَ
        // مُصدَّرةً لتطبيقاتٍ خارجيةٍ).
        if (ProcessUtils.isMainProcess(this)) {
            val exactAlarmPermissionChanged =
                AlarmManager
                    .ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED
            ContextCompat.registerReceiver(
                this,
                object : BroadcastReceiver() {
                    override fun onReceive(
                        context: Context?,
                        intent: Intent?
                    ) {
                        if (
                            intent?.action == exactAlarmPermissionChanged
                        ) {
                            TimeAnnouncementManager.shared(applicationContext)
                                .onExactAlarmPermissionChanged()
                        }
                    }
                },
                IntentFilter(exactAlarmPermissionChanged),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }

        // تنظيف الملفات المؤقتة اليتيمة عند الإقلاع (بند 19.2) — غير حاصر،
        // على النطاق العام خلفي فلا يؤخر بدء التطبيق ولا يعطّل إقلاع الخدمات.
        // يُنفَّذ **في العملية الرئيسية حصراً** لتفادي حذف ملف
        // nateq_tts_session.wav أثناء توليده في خدمة :tts العاملة في عملية
        // منفصلة — تغيير ذلك يسبب توقف الصوت.
        // **بند 7.1:** تُميَّز العملية عبر [ProcessUtils] الموحَّد —
        // المقارنة في main حصراً لتفادي حذف صوت جلسة :tts الجاري توليده.
        if (ProcessUtils.isMainProcess(this)) {
            appScope.launch {
                runCatching {
                    StartupTempSweeper(applicationContext).sweep()
                }
            }
        }

        // تطبيق لغة الواجهة المختارة يدوياً؛ في حال لم تُحدَّد تتبع
        // الواجهة لغة النظام تلقائياً.
        // الحقل محقون من Hilt لكن نُبقي الحماية: أي فشل تهيئة
        // (Keystore قديم مثلاً) لا يجوز أن يُسقط العملية قبل أي شاشة —
        // التراجع الصامت إلى لغة النظام آمن.
        val appLang = runCatching {
            settingsRepository.getAppLanguage()
        }.getOrNull()
        // AppCompatDelegate يحتفظ بآخر لغة محددة يدوياً حتى لو أُزيل الاختيار؛
        // القائمة الفارغة تُعيد الواجهة إلى لغة النظام صراحةً (كان غياب
        // الاستدعاء يُبقي التطبيق على آخر لغة يدوية ولو اختار المستخدم «حسب
        // النظام»). لا يُستدعى إلا عند اختيار يدوي بلا قيمة (فلا إعادة بناء
        // نشاط بلا حاجة في كل إقلاع).
        if (appLang.isNullOrBlank()) {
            AppCompatDelegate.setApplicationLocales(
                LocaleListCompat.getEmptyLocaleList()
            )
        } else {
            AppCompatDelegate.setApplicationLocales(
                LocaleListCompat.forLanguageTags(appLang)
            )
        }
    }
}