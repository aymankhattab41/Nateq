package com.aymankhattab.nateq.engine

import com.aymankhattab.nateq.core.audio.engine.PcmResampler
import kotlin.math.min
import org.junit.Assert.assertEquals
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * اختبارات معيد أخذ العينات وخافض القنوات (بند 17.1) — منطق نقي
 * بلا Android. التوقيع الجديد يستقبل (offset, length) فلا تُعالج
 * إلا نافذة البيانات الصالحة من مسبحٍ مُعاد استخدامه.
 */
class PcmResamplerTest {

    private fun encode(vararg values: Int): ByteArray {
        val out = ByteArray(values.size * 2)
        values.forEachIndexed { i, v ->
            val clamped = v.coerceIn(
                Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()
            )
            out[i * 2] = (clamped and 0xFF).toByte()
            out[i * 2 + 1] = (clamped shr 8).toByte()
        }
        return out
    }

    private fun decode(pcm: ByteArray): IntArray {
        val out = IntArray(pcm.size / 2)
        for (i in out.indices) {
            out[i] = (pcm[i * 2].toInt() and 0xFF or
            (pcm[i * 2 + 1].toInt() shl 8))
            .toShort().toInt()
        }
        return out
    }

    @Test
    fun emptyOrZeroLength_returnsEmpty() {
        val empty = ByteArray(0)
        assertEqualsPcm(ByteArray(0), PcmResampler.convert(
            empty, 0, 0, 22050, 1, 44100
        ))
        // طول صفري على مخزن غير فارغ = لا بيانات صالحة.
        val pcm = encode(100, 200)
        assertEqualsPcm(ByteArray(0), PcmResampler.convert(
            pcm, 0, 0, 22050, 1, 22050
        ))
    }

    @Test
    fun sameRateMono_returnsOnlyValidWindow() {
        // مخزن مسبح بحجم أكبر وأمامه/خلفه بيانات متبقية: لا تُعالج
        // إلا نافذة [offset, offset+length) — انحدار الخلل الأصلي
        // (كان يُعالج المخزن كاملاً فيُبثّ الضجيج الزاوي).
        val pcm = encode(100, -200, 300, -400, 9999, 9999, 9999, 9999)
        val result = PcmResampler.convert(pcm, 0, 8, 22050, 1, 22050)
        assertEquals(4, result.size / 2)
        assertArrayEquals(
            "النافذة الصالحة فقط بلا بقايا مسبح",
            intArrayOf(100, -200, 300, -400),
            decode(result)
        )
    }

    @Test
    fun nonZeroOffset_slicesMidBuffer() {
        // نافذة صالحة في وسط المخزن (إزاحة لاحقة): تُستخرج وحدها.
        val pcm = encode(1, 1000, 2000, 3000, 9)
        val result = PcmResampler.convert(pcm, 2, 6, 22050, 1, 22050)
        assertArrayEquals(
            intArrayOf(1000, 2000, 3000),
            decode(result)
        )
    }

    @Test
    fun constantSignal_downsampleByHalf_preservesValue() {
        val pcm = encode(*IntArray(200) { 1200 })
        val result = PcmResampler.convert(pcm, 0, pcm.size, 44100, 1, 22050)
        assertEquals("الطول نصف الفريمات", 100, result.size / 2)
        assertTrue("قيم ثابتة محفوظة", decode(result).all { it == 1200 })
    }

    @Test
    fun constantSignal_upsampleByDouble_preservesValue() {
        // فريم واحد ثابت: الاستيفاء يبقيه ثابتاً في كل العينات المولّدة.
        val pcm = encode(900)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 1, 44100)
        assertEquals("الطول مضاعف الفريمات", 2, result.size / 2)
        assertEquals(".أول عينة مطابقة للمدخل", 900, decode(result)[0])
        assertArrayEquals(intArrayOf(900, 900), decode(result))
    }

    @Test
    fun ramp_downsample_interpolates() {
        // رامب [0,1000,2000,3000] بمعدل 44100 → نصف العينات (22050):
        // فريم 0 ← عينة 0 (0)، فريم 1 ← عينة 2 (2000).
        val pcm = encode(0, 1000, 2000, 3000)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 44100, 1, 22050)
        assertEquals(2, result.size / 2)
        val decoded = decode(result)
        assertEquals(0, decoded[0])
        assertEquals(2000, decoded[1])
    }

    @Test
    fun fractionalInterpolation_approximatesMidpoint() {
        // رامب [0,1000] بمعدل 22050 → رفعه للضعف: مواضع 0.0/0.5/1.0/1.5
        // تنتج [0, 500, 1000, 1000] — الاستيفاء عند المنتصف بالضبط.
        val pcm = encode(0, 1000)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 1, 44100)
        assertEquals(4, result.size / 2)
        val decoded = decode(result)
        assertEquals(0, decoded[0])
        assertEquals("المنتصف يُستوفى خطياً", 500, decoded[1])
        assertEquals(1000, decoded[2])
        assertEquals(1000, decoded[3])
    }

    @Test
    fun stereo_downmix_averagesChannelsThenPasses() {
        // فريمان: (1000,2000) ثم (4000,-2000) → مونو [1500, 1000]
        val pcm = encode(1000, 2000, 4000, -2000)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 2, 22050)
        assertEquals(2, result.size / 2)
        assertArrayEquals(intArrayOf(1500, 1000), decode(result))
    }

    @Test
    fun stereoDownmix_negativeEvenPair_noDcBias() {
        // انحدار انحياز DC: الزوج السالب المطابق (-1,-1) كانت الـ (+1)/2
        // تُفسده إلى 0 (إسكات الطقطقة الخفيفة) — الإزاحة shr 1 تعطيه -1 الصحيح.
        val pcm = encode(-1, -1, -3, -3, 1, 1, 3, 3)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 2, 22050)
        assertArrayEquals(intArrayOf(-1, -3, 1, 3), decode(result))
    }

    @Test
    fun stereoDownmix_oddPairs_symmetricAroundZero() {
        // القيم الفردية: جزءٌ بعيدٌ عن الصفر بالتناوب (1.5 → 2 و -1.5 → -2)
        // فيسقط شدّا الانحياز كليهما ولا ينزاح المركز عن الصفر.
        val pcm = encode(2, 1, -2, -1)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 2, 22050)
        val decoded = decode(result)
        assertEquals(2, decoded[0])
        assertEquals(-2, decoded[1])
    }

    @Test
    fun threeChannels_negativeSum_balancedAverage() {
        // قنوات ثلاث بمجاميع سالبة: مسار القنوات ≥3 متوازن
        // لا يُفسد (-2)+(-2)+(-2).
        val pcm = encode(-2, -2, -2)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 3, 22050)
        assertArrayEquals(intArrayOf(-2), decode(result))
    }

    @Test
    fun resample_nonPowerRatio_constantPreserved() {
        // نسبة كسرية (44100 → 48000): الفاصلة الثابتة تبقّي القيمة الثابتة
        // (المشترك في الاستيفاء) بلا انحراف DC ولا انزياح للمواضع.
        val pcm = encode(*IntArray(300) { -7000 })
        val result = PcmResampler.convert(pcm, 0, pcm.size, 44100, 1, 48000)
        assertEquals((300L * 48000 / 44100).toInt(), result.size / 2)
        assertTrue(decode(result).all { it == -7000 })
    }

    @Test
    fun resample_rampOddRatio_staysInRangeAndMonotonic() {
        // رامب صاعد 44100 → 48000: المخرجات داخل مدى الرامب ومتزايدة رغم
        // كسور المواضع التراكمية في الـ 16.16 (بلا قفز خارج الحدود).
        val ramp = IntArray(500) { it * 10 }
        val pcm = encode(*ramp)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 44100, 1, 48000)
        val decoded = decode(result)
        assertEquals((500L * 48000 / 44100).toInt(), decoded.size)
        var previous = decoded[0]
        for (i in 1 until decoded.size) {
            assertTrue(
                "عند الفهرس $i: ${decoded[i]} قبل $previous",
                decoded[i] >= previous
            )
            previous = decoded[i]
        }
        assertTrue(decoded.first() >= 0)
        assertTrue(decoded.last() <= ramp.last())
    }

    @Test
    fun resample_upsampleHalfPosition_interpolates_16_16() {
        // مطابقة الـ 16.16 لصيغة الـ roundToInt السابقة: [0,1000] عند 22050
        // إلى 44100 → [0,500,1000,1000] حرفياً (نفس توقعات الاختبار القديم).
        val pcm = encode(0, 1000)
        val result = PcmResampler.convert(pcm, 0, pcm.size, 22050, 1, 44100)
        assertArrayEquals(intArrayOf(0, 500, 1000, 1000), decode(result))
    }

    @Test
    fun invalidRatesOrChannels_returnEmpty() {
        // على خلاف السلوك السابق (تمرير المخزن كما هو) يُسكَت الإخراج:
        // أصحّ من بثّ قمامة عند معاملات غير صالحة.
        val pcm = encode(1, 2)
        assertEqualsPcm(ByteArray(0), PcmResampler.convert(
            pcm, 0, pcm.size, 0, 1, 22050
        ))
        assertEqualsPcm(ByteArray(0), PcmResampler.convert(
            pcm, 0, pcm.size, 22050, 1, -1
        ))
        assertEqualsPcm(ByteArray(0), PcmResampler.convert(
            pcm, 0, pcm.size, 22050, 0, 22050
        ))
    }

    @Test
    fun stereoDownmix_respectsValidWindow() {
        // خافض القنوات يعالج النافذة الصالحة فقط: مخزن به بقايا بعد
        // الزوجين الصالحين لا تُؤثر في المخرج.
        val pcm = encode(1000, 2000, -1000, -2000, 7777, 7777)
        val result = PcmResampler.convert(pcm, 0, 8, 22050, 2, 22050)
        assertArrayEquals(intArrayOf(1500, -1500), decode(result))
    }

    @Test
    fun convertInto_sameRateMono_writesWindowAndReturnsLength() {
        // مخزن مسبح بحجم أكبر وراءه بقايا: يُكتب في out المضبوط مسبقاً
        // (مسبح المرسل) نافذةُ البيانات الصالحة فقط ويعود طولها.
        val pcm = encode(100, -200, 300, -400, 9999, 9999)
        val out = ByteArray(16)
        val written = PcmResampler.convertInto(
            pcm, 0, 8, 22050, 1, 22050, out, 0
        )
        assertEquals(8, written)
        assertArrayEquals(
            intArrayOf(100, -200, 300, -400),
            decode(out.copyOf(written))
        )
    }

    @Test
    fun convertInto_outTooSmall_truncatesWithoutOverflow() {
        // مخزن أقصر من المطلوب: لا تجاوز حدود أبداً — تُكتب البيانات التي
        // تتسع ويُعاد الطول المكتوب (نهاية نطق مبتورة، لا استثناء يقتل البث).
        val pcm = encode(100, -200, 300, -400)
        val out = ByteArray(4)
        val written = PcmResampler.convertInto(
            pcm, 0, 8, 22050, 1, 22050, out, 0
        )
        assertEquals(4, written)
        assertArrayEquals(intArrayOf(100, -200), decode(out))
    }

    @Test
    fun convertInto_offsetWritesAtGivenSlot() {
        // الكتابة تبدأ من outOffset وتتقدم ضمنه — إطاران كاملان في فتحة
        // منتصفة من مخزنٍ أوسع (سعة كافية بعد الإزاحة).
        val pcm = encode(1, 1000, 2000, 3000)
        val out = ByteArray(6)
        val written = PcmResampler.convertInto(
            pcm, 2, 6, 22050, 1, 22050, out, 2
        )
        assertEquals(4, written)
        assertArrayEquals(
            intArrayOf(1000, 2000),
            decode(out.copyOfRange(2, 6))
        )
    }

    @Test
    fun convertInto_matchesConvert_forVariedRatiosAndChannels() {
        // المعيار الحاسم: بلا تغيير ناتج PCM — مقارنة convertInto بمخزن كافٍ
        // مع convert القديمة على نفس النوافذ لكل النسب (رفع/خفض، استريو/مونو).
        val inputs = listOf(
            encode(0, 1000) to longArrayOf(2, 22050, 1, 44100),
            encode(0, 1000, 2000, 3000) to longArrayOf(4, 44100, 1, 22050),
            encode(1000, 2000, 4000, -2000) to longArrayOf(4, 22050, 2, 22050),
            encode(1000, 2000, 4000, -2000, 1, 1) to
            longArrayOf(6, 22050, 2, 48000),
            encode(*IntArray(200) { 1200 }) to longArrayOf(200, 44100, 1, 48000)
        )
        for ((pcm, spec) in inputs) {
            val len = spec[0].toInt()
            val inRate = spec[1].toInt()
            val channels = spec[2].toInt()
            val outRate = spec[3].toInt()
            val expected = PcmResampler.convert(
                pcm, 0, len, inRate, channels, outRate
            )
            val required = PcmResampler.convertedByteCount(
                pcm, 0, len, inRate, channels, outRate
            )
            assertEquals(expected.size, required)
            val out = ByteArray(required)
            val written = PcmResampler.convertInto(
                pcm, 0, len, inRate, channels, outRate, out, 0
            )
            assertEquals(required, written)
            assertArrayEquals(expected, out)
        }
    }

    @Test
    fun convertedByteCount_zeroForEmptyOrInvalid() {
        val pcm = encode(1, 2)
        assertEquals(
            0, PcmResampler.convertedByteCount(pcm, 0, 0, 22050, 1, 44100)
        )
        assertEquals(
            0, PcmResampler.convertedByteCount(pcm, 4, 2, 0, 1, 44100)
        )
        assertEquals(
            0, PcmResampler.convertedByteCount(pcm, 0, 4, 22050, 0, 44100)
        )
        assertEquals(
            0, PcmResampler.convertedByteCount(
                ByteArray(0), 0, 0, 22050, 1, 44100
            )
        )
    }

    @Test
    fun convertInto_windowedMonoDownsample_matchesConvert() {
        // إعادة عينات من نافذة إزاحةٍ غير صفريةٍ في مونو — المسار المباشر
        // الجديد يقرأ [pcm] بإزاحته بلا نسخ نافذة وسيطة، فيجب أن يطابق
        // convert الحرفَ للفريم.
        val pcm = encode(0, 0, 100, 200, 300, 400, 0, 0)
        val expected = PcmResampler.convert(pcm, 4, 4, 22050, 1, 16000)
        val out = ByteArray(expected.size)
        val written = PcmResampler.convertInto(
            pcm, 4, 4, 22050, 1, 16000, out, 0
        )
        assertEquals(expected.size, written)
        assertArrayEquals(expected, out)
    }

    @Test
    fun convertInto_equalRateStereo_matchesDownmixAtOffset() {
        // معدلٌ واحد مع قنوات متعددة: المسار الجديد يخفض القنوات مباشرةً
        // في مخزن المرسل عند فتحة غير صفرية — مطابقٌ حرفياً لـ downmix ثم نقل.
        val pcm = encode(1000, 2000, -1000, 2000, 3000, 7000)
        val expected = PcmResampler.downmixToMono(pcm, 2, 4, 2)
        val outSlot = 4
        val out = ByteArray(outSlot + expected.size)
        val written = PcmResampler.convertInto(
            pcm, 2, 4, 22050, 2, 22050, out, outSlot
        )
        assertEquals(expected.size, written)
        assertArrayEquals(
            expected, out.copyOfRange(outSlot, outSlot + expected.size)
        )
    }

    @Test
    fun convertInto_directCopy_alignsToEvenFrameCount() {
        // بند 2.6 المحاذاة الزوجية: المسار المباشر (معدل واحد + مونو) بنافذة
        // طولها فردي (فريم ناقص) كان ينسخ البايت الفردي زائماً فيخالف تقدير
        // convertedByteCount ويعبث بالفريمات — الآن يُقصّ إلى الفريمات الكاملة
        // ويتطابق المكتوب مع المعَدَّد.
        val pcm = encode(1000, 2000, 3000, 0xFF)
        val offset = 2
        val oddLength = 3 // يغطي فريماً كاملاً (2000) ونصفاً من 3000
        val required = PcmResampler.convertedByteCount(
            pcm, offset, oddLength, 22050, 1, 22050
        )
        val out = ByteArray(required)
        val written = PcmResampler.convertInto(
            pcm, offset, oddLength, 22050, 1, 22050, out, 0
        )
        assertEquals(required, written)
        assertEquals(2, written) // بايتان فقط = فريم واحد كامل
        assertArrayEquals(
            encode(2000), out.copyOf(written)
        )
    }

    @Test
    fun convertInto_phaseContinuity_splitMatchesSingleChunk() {
        // **بند 2.7:** الدفعاتُ المتتالية على القطعة نفسها بطورٍ مشترك
        // (LongArray(2)) لا تُعيد البدء من الصفر عند حدود الدفعات —
        // لا قفزات كبيرة (تقبّط مسموع) في الانتقالات.
        // الفرق الأقصى بين النداء الواحد وال-Shards هو فريم واحد
        // لكل انتقال بسبب تقريب convertedByteCount (أثر تحت العينة).
        val spec = listOf(
            intArrayOf(370, 22050, 48000),
            intArrayOf(501, 44100, 16000),
            intArrayOf(180, 8000, 22050)
        )
        for ((frames, inRate, outRate) in spec) {
            val pcm = encode(*IntArray(frames) { it * 3 - 400 })
            val totalRequired = PcmResampler.convertedByteCount(
                pcm, 0, pcm.size, inRate, 1, outRate
            )
            val single = ByteArray(totalRequired + 2)
            val singleWritten = PcmResampler.convertInto(
                pcm, 0, pcm.size, inRate, 1, outRate,
                single, 0, LongArray(2)
            )
            val phase = LongArray(2)
            val chunkBytes = 102
            val chunks = ArrayList<ByteArray>()
            var offset = 0
            while (offset < pcm.size) {
                val len = min(chunkBytes, pcm.size - offset)
                val required = PcmResampler.convertedByteCount(
                    pcm, offset, len, inRate, 1, outRate
                )
                val out = ByteArray(required + 2)
                val written = PcmResampler.convertInto(
                    pcm, offset, len, inRate, 1, outRate,
                    out, 0, phase
                )
                chunks.add(out.copyOf(written))
                offset += len
            }
            val joined = chunks.reduce { a, b -> a + b }
            val label = "$frames فريماً @ $inRate→$outRate"
            // الفرق ≤ فريم واحد لكل انتقال (تقريب مقطّع).
            assertTrue(
                "فرق الحجم ≤ 2 بايت — $label",
                kotlin.math.abs(singleWritten - joined.size) <= 2
            )
            val commonFrames = minOf(singleWritten, joined.size) / 2
            if (commonFrames > 0) {
                // الدفعاتُ المتتالية تُجري استيفاءً من موضعِ قصةٍ محسوبة
                // (تقريب 16.16) فعند حدود الدفعة يقع فرق تحت العينة قد
                // يصل وحدتين/ثلاثاً من قيمة PCM — أثر كمّي طبيعي لا يُسمع
                // بخلاف القفزة الكبيرة (التقبّط) التي كانت تتجاوز المئات.
                for (i in 0 until commonFrames) {
                    val a = (single[i * 2].toInt() and 0xFF) or
                        (single[i * 2 + 1].toInt() shl 8)
                    val b = (joined[i * 2].toInt() and 0xFF) or
                        (joined[i * 2 + 1].toInt() shl 8)
                    assertTrue(
                        "عينة $i ≤ 8 PCM — $label: $a ≠ $b",
                        kotlin.math.abs(
                            a.toShort() - b.toShort()
                        ) <= 8
                    )
                }
            }
        }
    }

    @Test
    fun convertInto_freshPhaseEachChunk_restartsLikeSingle() {
        // **بند 2.7 (تعليل التوثيق):** نسخة [convertInto] الجاهزة بطورٍ طازج
        // في كل نداءٍ تبقى مطابقةً للسلوك السابق حرفياً — كما لو كانت كل
        // دفعة نافذةً مستقلةً (لا استمرار طورٍ بين الدفعات).
        val pcm = encode(*IntArray(300) { it * 2 - 500 })
        for (chunk in intArrayOf(120, 90, 60)) {
            var offset = 0
            val phase = LongArray(2)
            while (offset < pcm.size) {
                val len = min(chunk, pcm.size - offset)
                val required = PcmResampler.convertedByteCount(
                    pcm, offset, len, 22050, 1, 48000
                )
                val out = ByteArray(required)
                val written = PcmResampler.convertInto(
                    pcm, offset, len, 22050, 1, 48000, out, 0, phase
                )
                assertEquals("مكتوب = كافٍ في دورة مستقلة", required, written)
                offset += len
            }
        }
    }

    private fun assertEqualsPcm(expected: ByteArray, actual: ByteArray) {
        assertArrayEquals("مطابقة PCM", expected, actual)
    }
}