# ============================================================
#  قواعد تشفير وتحصين كود Lord TTS ضد الهندسة العكسية
#  (ProGuard / R8) — تُستخدم في كل build من نوع release
# ============================================================

# ضغط أكواد الأصناف وربطها (هل يجب)، الاحتفاظ بمعلومات السطر/الملف
-keepattributes Signature
-keepattributes *Annotation*
# بعد: أرقام الأسطر نامية مفيدة لتتبع تقارير الانهيار الواردة من المستخدمين
# (مع mapping.txt يُفكّك أي خطأ). اسم الملف يُستبدل بثابت قصير حفاظاً على سمة
# الإبهار دون إضاعة مكانية stack trace.
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile

# لا تُعدد الأصناف المطلوب لمفتاحها أبداً؛ فهذا يزيد صعوبة الفهم
-allowaccessmodification
# ملحوظة: أُزيلت «-mergeinterfacesaggressively» لأنها بند متقادم في R8 يدمج
# الواجهات ذات التنفيذ الواحد (مثل AnnouncementAppContext في NateqApplication)
# فيكسّر التحويل الصريح (as) المستخدم في المستقبلات بـ ClassCastException
# في نسخة release — بقاعدة النشر القائلة: لا قواعد R8 جائرة على حقن Hilt.

# إعادة العناصر إلى حزمة مسطحة فلتردد أسماء أقصر وأقل دلالة (تحسين إعاقه الفهم)
-repackageclasses ''

# ============================================================
#  قواعد keep الضرورية (كي لا ينكسر التطبيق أو اتصالات النظام)
# ============================================================

# مكونات النظام المدرجة في Manifest يجب أن تبقى بأسمائها كما هي،
# لأن النظام ينشئها بهذه الأسماء (بقية الأصناف تُشفّر وتُعبّب بحرية).
# (يضيف AGP الـ keep تلقائياً لمكونات الـ Manifest؛ هذه صراحة وقايةً مستقبلية)
-keep public class com.aymankhattab.nateq.NateqApplication
-keep public class com.aymankhattab.nateq.core.audio.engine.NateqTtsService
-keep public class com.aymankhattab.nateq.settings.SettingsActivity
-keep public class com.aymankhattab.nateq.settings.CheckTtsDataActivity
-keep public class com.aymankhattab.nateq.settings.GetSampleTextActivity
-keep public class com.aymankhattab.nateq.settings.FirstRunSetupActivity
# مكونات الإعلانات (انتقلت من receivers إلى :core:audio.announcement في 5ب)
-keep public class com.aymankhattab.nateq.core.audio.announcement.AnnouncementBootReceiver
-keep public class com.aymankhattab.nateq.core.audio.announcement.AnnouncementSchedulerService
-keep public class com.aymankhattab.nateq.core.audio.announcement.TimeAlarmReceiver
-keep public class com.aymankhattab.nateq.core.audio.announcement.SmsReadingReceiver
-keep public class com.aymankhattab.nateq.core.audio.announcement.CallerAnnouncementReceiver
-keep public class com.aymankhattab.nateq.core.audio.announcement.NateqNotificationListener

# المكونات المنشأة خارج حزمة receivers — مذكورة في Manifest (أداة/بلاطة/خدمة جدولة/إقلاع)
-keep public class com.aymankhattab.nateq.settings.AnnouncementTileService

# خدمة المحرك TTS (مذكورة في Manifest) + الأنواع التي يطلبها النظام عبر TTS Service
# (قواعد الأصناف المذكورة في الـ Manifest يضيفها AGP تلقائياً؛ هذه صراحة وقايةً مستقبلية)
-keep class com.aymankhattab.nateq.core.audio.engine.NateqTtsService { *; }
# ملاحظة (بند الأوامر د.2): أُزيلت القواعد السابقة الخاصة بأصناف إطار
# android.speech.tts.* (TextToSpeechService/UtteranceProgressListener) لأنها
# ليست في الـ dex قيد التشفير أصلاً — قواعد ·*` كانت بلا أثر في كل البناءات.

# المستقبلات (receiver) التي تسجّلها بأسمائها في Manifest — الآن في :core:audio.
# طبقة الإعلانات كاملة تُحفظ (المتحدث/الجدولة/المستقبلات) كما حُفظت receiver سابقاً
-keep class com.aymankhattab.nateq.core.audio.announcement.** { *; }

# الوصول عبر انعكاس من أطراف المساعدة (AccessibilityService)
-keep class * extends android.accessibilityservice.AccessibilityService { *; }

# حافظ على أصناف تمثل جافا الثوابت/Parcelable/native للسلامة
-keep class * implements android.os.Parcelable { *; }
-keepclassmembers class * implements java.io.Serializable { *; }
-keepclassmembers enum * { *; }

# Gson: يجب الحفاظ على التوقيعات العامة (generic) لأن R8 يزيلها
# فيفقد TypeToken وسم_TYPE ويرمي IllegalStateException عند استعادة الحالة
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken { *; }
-keepclassmembers class * extends com.google.gson.reflect.TypeToken { *; }

# GsonTypes: البنّاء اليدوي لكائنات ParameterizedType (Map<String, X>) —
# يعتمد Gson عليها انعكاسياً (getRawType/getActualTypeArguments)، فلو شُفّر
# اسمها أو أعضاؤها فشل فكّ JSON وفسدت التفضيلات المحفوظة على الجاهز.
-keep class com.aymankhattab.nateq.core.common.json.GsonTypes { *; }
-keep class com.aymankhattab.nateq.core.common.json.ParameterizedTypes { *; }

# ============================================================
#  Hilt / Dagger — المكوّنات والأصناف المولّدة لا تُعاد تسميتها
# ============================================================
# Hilt يجمع المكوّنات (Components) عند الإقلاع عبر انعكاس على أسماء
# الأصناف المولّدة (Dagger*_HiltComponents_*). إعادة التسمية تكسر الحقن
# وتفشل الشاشات/الخدمات بلا رسالة واضحة.
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.internal.GeneratedComponent { *; }
-keep class * extends dagger.hilt.internal.GeneratedComponentManager { *; }
# أصناف Hilt_* المولّدة (Hilt_NateqTtsService, Hilt_SettingsActivity …)
# هي ما يرثه كل صنف مزيّن بـ @AndroidEntryPoint؛ أسماءها تُحلّ انعكاسياً
-keep class com.aymankhattab.nateq.Hilt_* { *; }
-keep class com.aymankhattab.nateq.**.Hilt_* { *; }
# أصناف Dagger المولّدة (Dagger*_HiltComponents_*): تُبنى عبر Hilt من كود
# النشاط/الخدمة مباشرة؛ حفظها يضمن ثبات تسلسل بناية المكوّنات في كل إصدار
-keep class com.aymankhattab.nateq.**Dagger*_HiltComponents_* { *; }
-keepclassmembers class * {
    @dagger.hilt.android.scopes.* <methods>;
}

# تفضيلات التحويل لكل لغة (LanguageSpeechPrefs): تتسلسل/تتجزأ عبر Gson انعكاسياً
# من SharedPreferences، فلو شُفّر اسمها أو حقولها انكسرت JSON المحفوظة (قراءة فارغة).
# ثبّتها كما هي: الحقول (engine/voiceName/rate/pitch/volume) هي مفاتيح JSON ذاتها.
-keep class com.aymankhattab.nateq.engine.LanguageSpeechPrefs { *; }

# بند الأوامر د.2: قاموس النطق يسلسل كل بياناته عبر مظلة JSON الموحدة (NateqJson)
# كخريطة Map<String,String> بلا أصناف نماذج بذاتها (مفاتيح القاموس نصوص مستخدمين)
# — تُثبَّت المظلة وبنّايات الأنواع المركّبة لئلا يفقدهما R8 فتُصدر/تُستورد
# القاموس مشوهاً في release: (الأنواع المركّبة تُحفظ أعلاه — GsonTypes/ParameterizedTypes)
-keep class com.aymankhattab.nateq.util.NateqJson { *; }

# بند الأوامر د.2: أُزيلت «-keepattributes XmlAttribute» (سمة غير قياسية
# عديمة الأثر لدى R8) — بقيت XmlAttribute قياسية في `XmlPullParser` وحدها.

# مكتبة security-crypto (مفاتيح) قد تستخدم انعكاساً لا يدعمه R8
-keep class com.google.android.gms.security.** { *; }

# androidx.security.crypto (EncryptedSharedPreferences/MasterKey): واجهة الـ API
# نفسها + كل ما يعتمد عليه MasterKey.holder (حاويات/فورمات Keystore) — تحفظ
# كما هي حتى لا ينكسر فك تشفير التفضيلات/القاموس في أول تشغيل release على جهاز
-keep class androidx.security.crypto.** { *; }

# Tink (تشغّل EncryptedSharedPreferences/Keystore): يتعامل مع تنسيقات مفاتيح
# ومواد مشفّرة عبر انعكاس/تسلسل يسقط مع R8 — إبقاؤه كما هو ضروري لئلا يفقد
# LORD قدرته على فك تشفير تفضيلاته بعد أي تحديث
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.crypto.tink.**
-dontwarn org.conscrypt.**

# ============================================================
#  إزالة تحذيرات لا فائدة منها
# ============================================================
-dontwarn com.google.android.gms.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**

# ============================================================
#  إزالة سجلات التشخيص (Log) من نسخة release —
#  تُزال v/d/i بالكامل؛ w/e تبقى للأخطاء الفعلية فقط (بلا نصوص محتوى)
# ============================================================
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# ============================================================
#  حماية كوروتينات Kotlin (الحد الأدنى الدفاعي)
# ============================================================
# Dispatchers.Main على أندرويد يُحمَّل عبر ServiceLoader بالبحث في
# META-INF/services عن مزوّد MainDispatcherFactory. لو شفّر R8 أسماء
# هذه الفئات، عاد Dispatchers.Main null أو فشل التحميل وسقطت كل مهام
# الخلفية. يُحفظ المزوّدون وأصناف الـ Dispatchers الحرجية بأسمائها
# (لا يُحفظ كل الكوروتينات — فالقواعد الرسمية المضمّنة تفي بالباقي).
-keep class kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keep class kotlinx.coroutines.android.HandlerContext { *; }
-keep class * implements kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keepnames class kotlinx.coroutines.CoroutineDispatcher { *; }

# يمكنك إضافة -keep لأي مزود صوت جديد تضيفه مستقبلاً هنا

# ============================================================
#  حماية Play Integrity
# ============================================================
-keep class com.google.android.play.integrity.** { *; }
-dontwarn com.google.android.play.integrity.**

# ============================================================
#  حماية AppIntegrity (السلاسل/الثوابت/الأسماء)
# ============================================================
-keep class com.aymankhattab.nateq.AppIntegrity { *; }

# ============================================================
#  تشفير إضافي للسلاسل الحساسة (اختياري، عبر R8 string encryption)
# ============================================================
# ملاحظة: R8 لا يدعم تشفير السلاسل مدمجاً — يعتمد على ProGuard commercial.
# البديل المجاني: تشفير يدوي (xor/base64) في الكود (AppIntegrity يفعل ذلك).

# ============================================================
#  إزالة StackTrace من النسخ غير release — لا يُنشر
# ============================================================
# (يُطبق فقط عند بناء Release — القواعد أعلاه تعمل دائماً)

# يمكنك إضافة -keep لأي مزود صوت جديد تضيفه مستقبلاً هنا